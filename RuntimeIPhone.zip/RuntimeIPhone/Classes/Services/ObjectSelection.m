#import "ObjectSelection.h"

#import "CRunApp.h"
#import "CEvents.h"
#import "CEventProgram.h"
#import "CRun.h"
#import "CObjInfo.h"
#import "CQualToOiList.h"
#import "CObject.h"

@implementation ObjectSelection

/*
 CRunApp* rhPtr;
 CObject** ObjectList;
 CObjInfo** OiList;
 CQualToOiList** QualToOiList; 
*/

-(id)initWithRunHeader:(CRunApp*)runApp
{
	if(self = [super init])
	{
		rhPtr = runApp;
		run = rhPtr->run;
		eventProgram = rhPtr->events;
		
		ObjectList =run->rhObjectList;				//get a pointer to the mmf object list
		OiList = run->rhOiList;						//get a pointer to the mmf object info list
		QualToOiList = eventProgram->qualToOiList;	//get a pointer to the mmf qualifier to Oi list
	}
	return self;
}

//Selects *all* objects of the given object-type
-(void)selectAll:(short)Oi
{
	CObjInfo* pObjectInfo = OiList[Oi];
	pObjectInfo->oilNumOfSelected = pObjectInfo->oilNObjects;
	pObjectInfo->oilListSelected = pObjectInfo->oilObject;
	pObjectInfo->oilEventCount = eventProgram->rh2EventCount;

	int i = pObjectInfo->oilObject;
	while(i >= 0)
	{
		CObject* pObject = ObjectList[i];
		pObject->hoNextSelected = pObject->hoNumNext;
		i = pObject->hoNumNext;
	}
}

//Resets all objects of the given object-type
-(void)selectNone:(short)Oi
{
	CObjInfo* pObjectInfo = OiList[Oi];

	pObjectInfo->oilNumOfSelected = 0;
	pObjectInfo->oilListSelected = -1;
	pObjectInfo->oilEventCount = eventProgram->rh2EventCount;
}

//Resets the SOL and inserts only one given object
-(void)selectOneObject:(CObject*)object
{
	CObjInfo* pObjectInfo = OiList[object->hoOi];

	pObjectInfo->oilNumOfSelected = 1;
	pObjectInfo->oilEventCount = eventProgram->rh2EventCount;
	pObjectInfo->oilListSelected = object->hoNumber;
	ObjectList[object->hoNumber]->hoNextSelected = -1;
}

//Resets the SOL and inserts the given list of objects
-(void)selectObjects:(short)Oi withObjects:(CObject**)objects andCount:(int)count
{
	if(count <= 0)
		return;

	CObjInfo* pObjectInfo = OiList[Oi];

	pObjectInfo->oilNumOfSelected = count;
	pObjectInfo->oilEventCount = eventProgram->rh2EventCount;
	
	short prevNumber = objects[0]->hoNumber;
	pObjectInfo->oilListSelected = prevNumber;
	
	for(int i=1; i<count; i++)
	{
		short currentNumber = objects[i]->hoNumber;
		ObjectList[prevNumber]->hoNextSelected = currentNumber;
		prevNumber = currentNumber;
	}
	ObjectList[prevNumber]->hoNextSelected = -1;
}


//Run a custom filter on the SOL (via function callback)
-(BOOL)filterObjects:(CObject*)rdPtr andOi:(short)Oi andNegate:(BOOL)negate andFilterFunction:(FilterFunction)filter;
{
	if(Oi & 0x8000)
		return [self filterQualifierObjects:rdPtr andOi:Oi & 0x7FFF andNegate:negate andFilterFunction:filter] ^ negate;
	else
		return [self filterNonQualifierObjects:rdPtr andOi:Oi & 0x7FFF andNegate:negate andFilterFunction:filter] ^ negate;
}


//Filter qualifier objects
-(BOOL)filterQualifierObjects:(CObject*)rdPtr andOi:(short)Oi andNegate:(BOOL)negate andFilterFunction:(FilterFunction)filter
{
	CQualToOiList* CurrentQualToOiStart = QualToOiList[Oi];
	CQualToOiList* CurrentQualToOi = CurrentQualToOiStart;

	BOOL hasSelected = NO;
	int i = 0;

	while(CurrentQualToOi->qoiList[1] >= 0)
	{
		CObjInfo* CurrentOi = OiList[CurrentQualToOi->qoiList[1]];
		hasSelected |= [self filterNonQualifierObjects:rdPtr andOi:CurrentOi->oilOi andNegate:negate andFilterFunction:filter];
		CurrentQualToOi = QualToOiList[Oi+i];
		++i;
	}
	return hasSelected;
}

//Filter normal objects
-(BOOL)filterNonQualifierObjects:(CObject*)rdPtr andOi:(short)Oi andNegate:(BOOL)negate andFilterFunction:(FilterFunction)filter
{
	CObjInfo* pObjectInfo = OiList[Oi];
	BOOL hasSelected = NO;

	if(pObjectInfo->oilEventCount != eventProgram->rh2EventCount)
		[self selectAll:Oi];	//The SOL is invalid, must reset.

	//If SOL is empty
	if(pObjectInfo->oilNumOfSelected <= 0)
		return false;

	int firstSelected = -1;
	int count = 0;
	int current = pObjectInfo->oilListSelected;
	CObject* previous = NULL;

	while(current >= 0)
	{
		CObject* pObject = ObjectList[current];
		BOOL useObject = filter(rdPtr, pObject) ^ negate;
		hasSelected |= useObject;

		if(useObject)
		{
			if(firstSelected == -1)
				firstSelected = current;

			if(previous != NULL)
				previous->hoNextSelected = current;
			
			previous = pObject;
			count++;
		}
		current = pObject->hoNextSelected;
	}
	if(previous != NULL)
		previous->hoNextSelected = -1;

	pObjectInfo->oilListSelected = firstSelected;
	pObjectInfo->oilNumOfSelected = count;

	return hasSelected;
}


//Return the number of selected objects for the given object-type
-(int)getNumberOfSelected:(short)Oi
{
	if(Oi & 0x8000)
	{
		Oi &= 0x7FFF;	//Mask out the qualifier part
		int numberSelected = 0;

		CQualToOiList* CurrentQualToOiStart = QualToOiList[Oi];
		CQualToOiList* CurrentQualToOi = CurrentQualToOiStart;

		int i=0;
		while(CurrentQualToOi->qoiList[1] >= 0)
		{
			CObjInfo* CurrentOi = OiList[CurrentQualToOi->qoiList[1]];
			numberSelected += CurrentOi->oilNumOfSelected;
			CurrentQualToOi = QualToOiList[Oi+i];
			++i;
		}
		return numberSelected;
	}
	else
	{
		CObjInfo* pObjectInfo = OiList[Oi];
		return pObjectInfo->oilNumOfSelected;
	}
}

-(BOOL)objectIsOfType:(CObject*)obj type:(short)Oi
{
	if(Oi & 0x8000)
	{
		Oi &= 0x7FFF;	//Mask out the qualifier part
		CQualToOiList* CurrentQualToOiStart = QualToOiList[Oi];
		CQualToOiList* CurrentQualToOi = CurrentQualToOiStart;

		int i=0;
		while(CurrentQualToOi->qoiList[1] >= 0)
		{
			CObjInfo* CurrentOi = OiList[CurrentQualToOi->qoiList[1]];
			if(CurrentOi->oilOi == obj->hoOi)
				return YES;
			CurrentQualToOi = QualToOiList[Oi+i];
			++i;
		}
		return NO;
	}
	
	return (obj->hoOi == Oi);
}


@end