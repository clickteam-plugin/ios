//----------------------------------------------------------------------------------
//
// CSERVICES : Routines utiles diverses
//
//----------------------------------------------------------------------------------
#import "CServices.h"
#import "CRect.h"
#import "CFont.h"
#import "CBitmap.h"
#import "CRenderToTexture.h"

int* xPos=nil;

// Fonctions C
int max(int a, int b)
{
	if (a>b)
	{
		return a;
	}
	return b;
}
int min(int a, int b)
{
	if (a<b)
	{
		return a;
	}
	return b;
}
double absDouble(double v)
{
	if (v>=0.0)
	{
		return v;
	}
	return -v;
}
int getR(int rgb)
{
	return (rgb>>16)&0xFF;
}
int getG(int rgb)
{
	return (rgb>>8)&0xFF;
}
int getB(int rgb)
{
	return (rgb&0xFF);
}

int getRGB(int r, int g, int b)
{
	return (r&0xFF)<<16 | (g&0xFF)<<8 | (b&0xFF);
}

int getRGBA(int r, int g, int b, int a)
{
	return (r&0xFF)<<24 | (g&0xFF)<<16 | (b&0xFF)<<8 | (a&0xFF);
}

int getABGR(int a, int b, int g, int r)
{
	return (a&0xFF)<<24 | (b&0xFF)<<16 | (g&0xFF)<<8 | (r&0xFF);
}

int getABGRPremultiply(int a, int b, int g, int r)
{
	float al = a/255.0f;
	r *= al;
	g *= al;
	b *= al;
	return (a&0xFF)<<24 | (b&0xFF)<<16 | (g&0xFF)<<8 | (r&0xFF);
}

int getARGB(int a, int r, int g, int b)
{
	return (a&0xFF)<<24 | (r&0xFF)<<16 | (g&0xFF)<<8 | (b&0xFF);
}
int inverseOpaqueColor(int color)
{
	unsigned char b = (color & 0x00FF0000) >> 16;
	unsigned char g = (color & 0x0000FF00) >> 8;
	unsigned char r = (color & 0x000000FF);
	return 0xFF000000 | r << 16 | g << 8 | b;
}

int clamp(int val, int a, int b)
{
	return min( max(val, a), b);
}

void setRGBFillColor(CGContextRef ctx, int rgb)
{
	CGFloat r=(CGFloat)(((rgb>>16)&255))/255.0;
	CGFloat g=(CGFloat)(((rgb>>8)&255))/255.0;
	CGFloat b=(CGFloat)(rgb&255)/255.0;
	CGContextSetRGBFillColor(ctx, r, g, b, 1.0);
}
void setRGBStrokeColor(CGContextRef ctx, int rgb)
{
	CGFloat r=(CGFloat)(((rgb>>16)&255))/255.0;
	CGFloat g=(CGFloat)(((rgb>>8)&255))/255.0;
	CGFloat b=(CGFloat)(rgb&255)/255.0;
	CGContextSetRGBStrokeColor(ctx, r, g, b, 1.0);
}
UIColor* getUIColor(int rgb)
{
	CGFloat r=(CGFloat)(((rgb>>16)&255))/255.0;
	CGFloat g=(CGFloat)(((rgb>>8)&255))/255.0;
	CGFloat b=(CGFloat)(rgb&255)/255.0;
	return [UIColor colorWithRed:r green:g blue:b alpha:1.0];
}
void drawLine(CGContextRef context, int x1, int y1, int x2, int y2)
{
	CGContextMoveToPoint(context, x1, y1);
	CGContextAddLineToPoint(context, x2, y2);
	CGContextStrokePath(context);
}
int HIWORD(int ul)
{
	return (ul >> 16)&0x0000FFFF;
}
int LOWORD(int ul)
{
	return ul & 0x0000FFFF;
}
int MAKELONG(int lo, int hi)
{
	return (hi << 16) | (lo & 0xFFFF);
}
int swapRGB(int rgb)
{
	int r=(rgb>>16)&0xFF;
	int g=(rgb>>8)&0xFF;
	int b=rgb&0xFF;
	return b<<16|g<<8|r;
}


@implementation CServices

+(int)drawText:(CBitmap*)bitmap withString:(NSString*)s andFlags:(short)flags andRect:(CRect)rc andColor:(int)rgb andFont:(CFont*)font andEffect:(int)effect andEffectParam:(int)effectParam
{
	CGContextRef context = nil;	//Was uninitialized
	if (bitmap!=nil)
	{
		UIGraphicsPushContext(bitmap->context);
		context=bitmap->context;
	}
	
	// Une chaine nulle?
	if ([s length]==0)
	{
		if ((flags & 0x0400) != 0)	//DT_CALCRECT
		{
			rc.right = rc.left;
			rc.bottom = rc.top;
		}
		return 0;
	}
	
	// Cree la fonte
	UIFont* f=[font createFont];

	// Fixe la couleur
	if ((flags & DT_CALCRECT)==0)
	{
		setRGBFillColor(context, rgb);	//Was uninitialized before, could be random value
		setRGBStrokeColor(context, rgb);
	}
	
	// Si retour chariots, coupe la ligne en bouts
	int maxHeight = 0;
	int index = [CServices indexOf:s withChar:10 startingAt:0];
	if (index >= 0)
	{
		CRect rc2 = rc;
		NSString* sub;
		int h;
		int prevIndex = 0;
		int maxWidth = 0;
		int index2, nextIndex;
		NSRange range;
		
		// Si VCENTER ou BOTTOM calcule la taille en Y
		do
		{
			index2 = [CServices indexOf:s withChar:13 startingAt:prevIndex];
			nextIndex=max(index, index2);
			if (index2>=0 && index2 == index - 1)
			{
				index--;
			}
			range.location=prevIndex;
			range.length=index-prevIndex;
			sub = [s substringWithRange:range];
			h = [self drawIt:f withString:sub andFlags:(short)(flags|DT_CALCRECT) andRect:rc2];
			maxWidth = max(maxWidth, rc2.right - rc2.left);
			maxHeight += h;
			rc2.top += h;
			rc2.bottom = rc.bottom;
			rc2.right = rc.right;
			prevIndex = nextIndex + 1;
			index = [CServices indexOf:s withChar:10 startingAt:prevIndex];
		} while (index >= 0);
		if (prevIndex < [s length])
		{
			sub = [s substringFromIndex:prevIndex];
			h = [self drawIt:f withString:sub andFlags:(short) (flags|DT_CALCRECT) andRect:rc2];
			maxWidth = max(maxWidth, rc2.right - rc2.left);
			maxHeight += h;
		}
		if ((flags & DT_CALCRECT) != 0)
		{
			rc.right = rc.left + maxWidth;
			rc.bottom = rc2.bottom;
			return maxHeight;
		}
		
		// Dessine
		rc2 = rc;
		if ((flags & DT_VCENTER) != 0)
		{
			rc2.top = rc2.top + (rc2.bottom - rc2.top) / 2 - maxHeight / 2;
		}
		else if ((flags & DT_BOTTOM) != 0)
		{
			rc2.top = rc2.bottom - maxHeight;
		}
		maxHeight = 0;
		prevIndex = 0;
		index = [CServices indexOf:s withChar:10 startingAt:0];
		do
		{
			index2 = [CServices indexOf:s withChar:13 startingAt:prevIndex];
			nextIndex=max(index, index2);
			if (index2>=0 && index2 == index - 1)
			{
				index--;
			}
			range.location=prevIndex;
			range.length=index-prevIndex;
			sub = [s substringWithRange:range];
			h = [self drawIt:f withString:sub andFlags:flags andRect:rc2];
			maxHeight += h;
			rc2.top += h;
			rc2.bottom = rc.bottom;
			rc2.right = rc.right;
			prevIndex = nextIndex + 1;
			index = [CServices indexOf:s withChar:10 startingAt:prevIndex];
		} while (index >= 0);
		if (prevIndex < [s length])
		{
			sub = [s substringFromIndex:prevIndex];
			h = [self drawIt:f withString:sub andFlags:flags andRect:rc2];
			maxHeight += h;
		}
		return maxHeight;
	}
	
	// Pas de retour chariot, dessin direct
	maxHeight = [self drawIt:f withString:s andFlags:(short)(flags|DT_VALIGN) andRect:rc];

	if (bitmap!=nil)
	{
		UIGraphicsPopContext();
	}   	
	return maxHeight;
}

+(int)drawIt:(UIFont*)f withString:(NSString*)s andFlags:(short)flags andRect:(CRect)rc
{	
	if ([s length] == 0)
	{
		s = @" ";
	}
	
	// Calcule la largeur de la chaine
	int hLine;
	int spaceWidth;
	CGSize size;
	size=[@" " sizeWithFont:f];
	hLine=size.height;
	spaceWidth = size.width;

	int rectWidth = rc.right - rc.left;
	int startSpace = 0;
	int currentSpace = 0;
	int previousSpace;
	int firstSpace = 0;
	int x;
	int width = 0;
	int height = 0;
	int currentXPos;
	if (xPos==nil)
	{
		xPos=(int*)malloc(100*sizeof(int));
	}
	int sx;
	NSString* ss;
	BOOL bQuit=NO;
	BOOL bContinue=NO;
	NSString* car;
	
	int y = rc.top;
	int hCalcul=hLine;
	if ((hCalcul&1)!=0)
	{
		hCalcul++;
	}
	if ((flags & DT_VALIGN) != 0)
	{
		if ((flags & DT_VCENTER) != 0)
		{
			y = rc.top + (rc.bottom - rc.top) / 2 - hCalcul / 2;
		}
		else if ((flags & DT_BOTTOM) != 0)
		{
			y = rc.bottom - hLine;
		}
	}
	int yTop=y;
	
	NSRange range;
	do
	{
		firstSpace = startSpace;
		currentXPos = 0;
		x = 0;
		height += hLine;
		do
		{
			xPos[currentXPos] = x;
			currentXPos += 1;
			previousSpace=currentSpace;

			currentSpace = [CServices indexOf:s withChar:32 startingAt:firstSpace];
			if (currentSpace == -1)
			{
				currentSpace = [s length];
			}
			if (currentSpace < firstSpace)
			{ 
				x-=spaceWidth;
				break;
			}
			range.location=firstSpace;
			range.length=currentSpace-firstSpace;
			ss = [s substringWithRange:range];
			size=[ss sizeWithFont:f];
			sx = size.width;
			if (x + sx > rectWidth)
			{
				currentXPos--;
				if (currentXPos>0)
				{
					sx-=spaceWidth;
					x-=spaceWidth;
					currentSpace=previousSpace;
					break;
				}
				int c;
				for (c = firstSpace; c < currentSpace; c++)
				{
					range.location=c;
					range.length=1;
					car=[s substringWithRange:range];
					size=[car sizeWithFont:f];
					sx = size.width;
					if (x + sx >= rectWidth)
					{
						c--;
						if (c>0)
						{
							width = max(x, width);
							if ((flags & 0x0400) == 0)	//DT_CALCRECT
							{
								if ((flags & 0x0001) != 0)	//DT_CENTER
								{
									x = rc.left + (rc.right - rc.left) / 2 - x / 2;
								}
								else if ((flags & 0x0002) != 0) //DT_RIGHT
								{
									x = rc.right - x;
								}
								else
								{
									x = rc.left;
								}
								range.location=firstSpace;
								range.length=c-firstSpace;
								ss = [s substringWithRange:range];
								[ss drawAtPoint:CGPointMake(x, y) withFont:f];
							}
						}
						currentSpace = [CServices indexOf:s withChar:32 startingAt:c];
						bQuit=YES;
						if (currentSpace >= 0)
						{
							bContinue=YES;
						}
						break;
					}
					x += sx;
				}
			}
			if (bQuit)
			{
				break;
			}
			x += sx;
			if (x + spaceWidth > rectWidth)
			{
				break;
			}
			x += spaceWidth;
			firstSpace = currentSpace + 1;
		} while (YES);
		if (bContinue==NO)
		{
			if (bQuit)
			{
				break;
			}
			width = max(x, width);
			int n;
			if ((flags & 0x0400) == 0)	//DT_CALCRECT
			{
				if ((flags & 0x0001) != 0)	//DT_CENTER
				{
					x = rc.left + (rc.right - rc.left) / 2 - x / 2;
				}
				else if ((flags & 0x0002) != 0) //DT_RIGHT
				{
					x = rc.right - x;
				}
				else
				{
					x = rc.left;
				}
				firstSpace = startSpace;
				for (n = 0; n < currentXPos; n++)
				{
					currentSpace = [CServices indexOf:s withChar:32 startingAt:firstSpace];
					if (currentSpace == -1)
					{
						currentSpace = [s length];
					}
					if (currentSpace < firstSpace)
					{
						break;
					}
					range.location=firstSpace;
					range.length=currentSpace-firstSpace;
					ss = [s substringWithRange:range];
					[ss drawAtPoint:CGPointMake(x + xPos[n], y) withFont:f];	
					firstSpace = currentSpace + 1;
				}
			}
		}
		bQuit=NO;
		bContinue=NO;
		y += hLine;
		startSpace = currentSpace + 1;
	} while (startSpace < [s length]);
	
	// Retourne la taille
	if ((flags & 0x0400) != 0)	//DT_CALCRECT
	{
		rc.right = rc.left + width;
		rc.bottom = yTop+height;
	}
	return height;
}

+(int)indexOf:(NSString*)s withChar:(unichar)c startingAt:(int)start
{
	int l=[s length];
	int p;
	for (p=start; p<l; p++)
	{
		if ([s characterAtIndex:p]==c)
		{
			return p;
		}
	}
	return -1;			
}
+(NSString*)intToString:(int)v withFlags:(int)flags
{
	NSString* s=[NSString stringWithFormat:@"%i", v];
	if ((flags&CPTDISPFLAG_INTNDIGITS)==0)
	{
		[s retain];
		return s;
	}
	int nDigits=flags&CPTDISPFLAG_INTNDIGITS;
	if ([s length]>nDigits)
	{
		s=[s substringToIndex:nDigits];
		[s retain];
		return s;
	}
	while([s length]<nDigits)
	{
		s=[@"0" stringByAppendingString:s];
	}
	[s retain];
	return s;
}
+(NSString*)doubleToString:(double)v withFlags:(int)flags
{
	NSString* s;
	
	if ((flags&CPTDISPFLAG_FLOAT_FORMAT)==0)
	{
		s=[NSString stringWithFormat:@"%g", v];
	}
	else
	{
		BOOL bRemoveTrailingZeros=NO;
		int nDigits=((flags&CPTDISPFLAG_FLOATNDIGITS)>>CPTDISPFLAG_FLOATNDIGITS_SHIFT)+1;
		int nDecimals=-1;
		if ((flags&CPTDISPFLAG_FLOAT_USEDECIMALS)!=0)
			nDecimals=((flags&CPTDISPFLAG_FLOATNDECIMALS)>>CPTDISPFLAG_FLOATNDECIMALS_SHIFT);
		else if (v>-1.0 & v<1.0)
		{
			nDecimals=nDigits;
			bRemoveTrailingZeros=YES;
		}
		
		NSString* format;
		if ((flags&CPTDISPFLAG_FLOAT_PADD)!=0)
		{
			format=@"%0";
			format=[format stringByAppendingFormat:@"%i", nDigits];
		}
		else
			format=@"%";
		
		if (nDecimals<0)
		{
			format=[format stringByAppendingString:@"g"];
		}
		else
		{
			format=[format stringByAppendingFormat:@".%ig", nDecimals];
		}
		s=[NSString stringWithFormat:format, v];
	}
	[s retain];
	return s;
}
@end

