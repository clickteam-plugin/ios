#import <Foundation/Foundation.h>

@class CRunApp;
@class CObject;
@class CObjInfo;
@class CQualToOiList;
@class CRun;
@class CEventProgram;

typedef BOOL(*FilterFunction)(CObject*,CObject*);

@interface ObjectSelection : NSObject
{
@private
	CRunApp* rhPtr;
	CRun* run;
	CEventProgram* eventProgram;
	
	CObject** ObjectList;
	CObjInfo** OiList;
	CQualToOiList** QualToOiList;
}
-(id)initWithRunHeader:(CRunApp*)runApp;
-(void)selectAll:(short)Oi;
-(void)selectNone:(short)Oi;
-(void)selectOneObject:(CObject*)object;
-(void)selectObjects:(short)Oi withObjects:(CObject**)objects andCount:(int)count;
-(BOOL)filterObjects:(CObject*)rdPtr andOi:(short)Oi andNegate:(BOOL)negate andFilterFunction:(FilterFunction)filter;
-(BOOL)objectIsOfType:(CObject*)obj type:(short)Oi;
-(int)getNumberOfSelected:(short)Oi;

-(BOOL)filterQualifierObjects:(CObject*)rdPtr andOi:(short)Oi andNegate:(BOOL)negate andFilterFunction:(FilterFunction)filter;
-(BOOL)filterNonQualifierObjects:(CObject*)rdPtr andOi:(short)Oi andNegate:(BOOL)negate andFilterFunction:(FilterFunction)filter;

@end