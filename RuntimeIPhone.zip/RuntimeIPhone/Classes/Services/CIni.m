//
//  CIni.m
//  RuntimeIPhone
//

#import "CIni.h"
#import "CFile.h"
#import "CArrayList.h"


// CINI ///////////////////////////////////////////////////////////////////////

@implementation CIni

-(id)init
{
	strings=[[CArrayList alloc] init];
	return self;
}
-(void)dealloc
{
	if (strings!=nil)
	{
		[strings clearRelease];
		[strings release];
	}
	if (currentFileName!=nil)
	{
		[currentFileName release];
	}
	[super dealloc];
}

-(void)loadIni:(NSString*)fileName
{
	BOOL reload=YES;
	if (currentFileName!=nil)
	{
		if ([currentFileName caseInsensitiveCompare:fileName]==0)
		{
			reload=NO;
		}
	}
	if (reload)
	{
		[self saveIni];
		
		if (currentFileName!=nil)
		{
			[currentFileName release];
		}
		currentFileName=[[NSString alloc] initWithString:fileName];
		if (strings==nil)
		{
			strings=[[CArrayList alloc] init];
		}
		else
		{
			[strings clearRelease];
		}
		
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
		NSString *documentsDirectory = [paths objectAtIndex:0];
		NSString *appFile = [documentsDirectory stringByAppendingPathComponent:fileName];
		NSError* errorPtr;
		NSData *myData = [[[NSData alloc] initWithContentsOfFile:appFile options:NSMappedRead error:&errorPtr] autorelease];
		if ([myData length]==0)
		{
            NSString* name=fileName;
            NSString* extension=@"ini";
            NSRange range=[fileName rangeOfString:@"."];
            if (range.location!=NSNotFound)
            {
                name=[fileName substringToIndex:range.location];
                extension=[fileName substringFromIndex:range.location+1];
            }
            appFile=[[NSBundle mainBundle] pathForResource:name ofType:extension];
            @try 
            {
                myData = [[[NSData alloc] initWithContentsOfFile:appFile options:NSMappedRead error:&errorPtr] autorelease];
            }
            @catch (NSException *exception) 
            {
                return;
            }
        }
		if ([myData length]!=0)
		{
            CFile* file=[[CFile alloc] initWithNSDataNoRelease:myData];
            while([file IsEOF]==NO)
            {
                NSString* s=[file readAStringEOL];
                [strings add:s];
            };
            [file release];
        }
	}
}
-(void)saveIni
{
	if (strings!=nil && currentFileName!=nil)
	{
		int n;
		int length=0;  
		NSString* s;
		for (n=0; n<[strings size]; n++)
		{
			s=(NSString*)[strings get:n];
			length+=[s length]+1;
		}
		char* buffer=(char*)malloc(length*2);
		char* ptr=buffer;
		for (n=0; n<[strings size]; n++)
		{
			s=(NSString*)[strings get:n];
			[s getCString:ptr maxLength:[s length]*2+1 encoding:NSWindowsCP1251StringEncoding];
			ptr+=strlen(ptr);
			*(ptr++)=10;
		}
		length=ptr-buffer;
		
		NSData* data=[[NSData alloc] initWithBytes:buffer length:length];
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
		NSString *documentsDirectory = [paths objectAtIndex:0];
		NSString *appFile = [documentsDirectory stringByAppendingPathComponent:currentFileName];
		[data writeToFile:appFile atomically:NO];
		[data release];
		free(buffer);
	}
}

-(int)findSection:(NSString*)sectionName
{
	int l;
	NSString* s;
	NSString* s2;
	for (l=0; l<[strings size]; l++)
	{
		s=(NSString*)[strings get:l];
        if ([s length]>0)
        {
            if ([s characterAtIndex:0]=='[')
            {
                NSRange range=[s rangeOfString:@"]"];
                if (range.location!=NSNotFound)
                {
                    int last=range.location;
                    if (last>=1)
                    {
                        range.location=1;
                        range.length=last-1;
                        s2=[s substringWithRange:range];
                        if ([s2 caseInsensitiveCompare:sectionName]==0)
                        {
                            return l;
                        }
					}
				}
			}
		}
	}
	return -1;
}
-(int)findKey:(int)l withParam1:(NSString*)keyName
{
	NSString* s;
	NSString* s2;
	for (; l<[strings size]; l++)
	{
		s=(NSString*)[strings get:l];
        if ([s length]>0)
        {
            if ([s characterAtIndex:0]=='[')
            {
                return -1;
            }
            NSRange range=[s rangeOfString:@"="];
            if (range.location!=NSNotFound)
            {
                s2=[s substringToIndex:range.location];
                if ([s2 caseInsensitiveCompare:keyName]==0)
                {
                    return l;
                }
			}
		}
	}
	return -1;
}

-(NSString*)getPrivateProfileString:(NSString*)sectionName withParam1:(NSString*)keyName andParam2:(NSString*)defaultString andParam3:(NSString*)fileName
{
	[self loadIni:fileName];
	
	int l=[self findSection:sectionName];
	if (l>=0)
	{
		l=[self findKey:l+1  withParam1:keyName];
		if (l>=0)
		{
			NSString* s=(NSString*)[strings get:l];
			NSRange range=[s rangeOfString:@"="]; 
			return [[NSString alloc] initWithString:[s substringFromIndex:range.location+1]];
		}
	}
	return defaultString;
}

-(void)writePrivateProfileString:(NSString*)sectionName withParam1:(NSString*)keyName andParam2:(NSString*)name andParam3:(NSString*)fileName
{
	[self loadIni:fileName];
	
	NSString* s;
	int section=[self findSection:sectionName];
	if (section<0)
	{
		s=@"[";
		s=[s stringByAppendingString:sectionName];
		s=[s stringByAppendingString:@"]"];
		s=[[NSString alloc] initWithString:s];
		[strings add:s];
		s=[keyName stringByAppendingString:@"="];
		s=[s stringByAppendingString:name];
		s=[[NSString alloc] initWithString:s];
		[strings add:s];
		return;
	}
	
	int key=[self findKey:section+1  withParam1:keyName];
	if (key>=0)
	{
		s=[keyName stringByAppendingString:@"="];
		s=[s stringByAppendingString:name];
		s=[[NSString alloc] initWithString:s];
		NSString* del=(NSString*)[strings get:key];
		[del release];
		[strings set:key object:s];
		return;
	}
	
	for (key=section+1; key<[strings size]; key++)
	{
		s=[strings get:key];
		if ([s characterAtIndex:0]=='[')
		{
			s=[keyName stringByAppendingString:@"="];
			s=[s stringByAppendingString:name];
			s=[[NSString alloc] initWithString:s];
			[strings addIndex:key object:s];
			return;
		}
	}
	s=[keyName stringByAppendingString:@"="];
	s=[s stringByAppendingString:name];
	s=[[NSString alloc] initWithString:s];
	[strings add:s];
}    

-(void)deleteItem:(NSString*)group withParam1:(NSString*)item andParam2:(NSString*)iniName
{
	[self loadIni:iniName];
	
	int s=[self findSection:group];
	if (s>=0)
	{
		int k=[self findKey:s+1  withParam1:item];
		if (k>=0)
		{
			[strings removeClearIndex:k];
		}
	}
}

-(void)deleteGroup:(NSString*)group withParam1:(NSString*)iniName
{
	[self loadIni:iniName];
	
	int s=[self findSection:group];
	if (s>=0)
	{
		[strings removeClearIndex:s];
		while(YES)
		{
			if (s>=[strings size])
			{
				break;
			}
			if ([((NSString*)[strings get:s]) characterAtIndex:0]=='[')
			{
				break;
			}
			[strings removeClearIndex:s];
		}
	}
}

@end
