
struct CPoint
{
	short x;
	short y;
};
typedef struct CPoint CPoint;


struct CApproach
{
	BOOL isFound;
	CPoint point;
};
typedef struct CApproach CApproach;