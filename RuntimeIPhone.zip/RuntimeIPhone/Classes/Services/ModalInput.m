#import "ModalInput.h"

@implementation ModalInput

@synthesize textField;
@synthesize passwordField;
@synthesize text;
@synthesize password;

-(id)initStringWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate cancelButtonTitle:(NSString *)cancelButtonTitle okButtonTitle:(NSString *)okayButtonTitle
{
    if (self = [super initWithTitle:title message:message delegate:delegate cancelButtonTitle:cancelButtonTitle otherButtonTitles:okayButtonTitle, nil])
    {
        UITextField *theTextField = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)]; 
		
        [theTextField setBackgroundColor:[UIColor whiteColor]];
        [self addSubview:theTextField];
        self.textField = theTextField;
        [theTextField release];
        CGAffineTransform translate = CGAffineTransformMakeTranslation(0.0, 0.0); 
        [self setTransform:translate];
    }
    return self;
}

-(id)initNumberWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate cancelButtonTitle:(NSString *)cancelButtonTitle okButtonTitle:(NSString *)okayButtonTitle
{
    if (self = [super initWithTitle:title message:message delegate:delegate cancelButtonTitle:cancelButtonTitle otherButtonTitles:okayButtonTitle, nil])
    {

		UITextField *theTextField = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
		theTextField.keyboardType = UIKeyboardTypeNumberPad;
        [theTextField setBackgroundColor:[UIColor whiteColor]];
        [self addSubview:theTextField];
        self.textField = theTextField;
        [theTextField release];
        CGAffineTransform translate = CGAffineTransformMakeTranslation(0.0, 0.0); 
        [self setTransform:translate];
    }
    return self;
}

-(id)initNamePasswordWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate cancelButtonTitle:(NSString *)cancelButtonTitle okButtonTitle:(NSString *)okayButtonTitle
{
    if (self = [super initWithTitle:title message:message delegate:delegate cancelButtonTitle:cancelButtonTitle otherButtonTitles:okayButtonTitle, nil])
    {
		UITextField *theTextField = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
		UITextField *thePasswordField = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 75.0, 260.0, 25.0)];
		thePasswordField.secureTextEntry = YES;
		[theTextField setBackgroundColor:[UIColor whiteColor]];
		[thePasswordField setBackgroundColor:[UIColor whiteColor]];
		[self addSubview:theTextField];
		[self addSubview:thePasswordField];
		self.textField = theTextField;
		self.passwordField = thePasswordField;
		[theTextField release];
		[thePasswordField release];
    }
    return self;
}


- (void)show
{
    [textField becomeFirstResponder];
    [super show];
	
	double add = 30.0;
	double pos = 0;
	if(passwordField != nil)
		add += 30.0;

	Class buttonClass = NSClassFromString(@"UIThreePartButton");
	for(UIView* subview in self.subviews)
	{
		if([subview isKindOfClass:[UILabel class]])
			pos = MAX(subview.frame.origin.y+subview.frame.size.height, pos);
		else if([subview isKindOfClass:buttonClass])
			subview.frame = CGRectMake(subview.frame.origin.x, subview.frame.origin.y+add, subview.frame.size.width, subview.frame.size.height);
	}
	
	textField.frame = CGRectMake(12.0, pos+5.0, 260.0, 25.0);
	if(passwordField != nil)
		passwordField.frame = CGRectMake(12.0, pos+35.0, 260.0, 25.0);

	self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, self.frame.size.height+add+10);
}


- (NSString *)text
{
    return textField.text;
}

- (NSString *)password
{
    return passwordField.text;
}

-(void)resignTextField
{
	[textField resignFirstResponder];
}


- (void)dealloc
{
    [textField release];
    [super dealloc];
}


@end