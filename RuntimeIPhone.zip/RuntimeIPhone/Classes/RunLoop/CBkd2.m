// -----------------------------------------------------------------------------
//
// CBKD2 : objet paste dans le decor
//
// -----------------------------------------------------------------------------
#import "CBkd2.h"
#import "CRun.h"
#import "CSprite.h"
#import "CSpriteGen.h"
#import "CRunApp.h"

@implementation CBkd2

-(id)initWithCRun:(CRun*)rh
{
	rhPtr=rh;
	return self;
}
-(void)dealloc
{
	int n;
	for (n=0; n<4; n++)
	{
		if (pSpr[n]!=nil)
		{
			[rhPtr->rhApp->spriteGen delSpriteFast:pSpr[n]];
		}
	}
	[super dealloc];
}

@end
