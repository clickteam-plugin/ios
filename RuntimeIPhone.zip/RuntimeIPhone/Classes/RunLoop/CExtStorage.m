//----------------------------------------------------------------------------------
//
// CEXTSTORAGE : donnees gloables pour une extension
//
//----------------------------------------------------------------------------------
#import "CExtStorage.h"

@implementation CExtStorage

@end
