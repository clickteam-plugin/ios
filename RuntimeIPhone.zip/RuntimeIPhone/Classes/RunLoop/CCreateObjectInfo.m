//----------------------------------------------------------------------------------
//
// CCREATEOBJECTINFO: informations pour la creation des objets
//
//----------------------------------------------------------------------------------
#import "CCreateObjectInfo.h"
#import "CLO.h"

@implementation CCreateObjectInfo

@end
