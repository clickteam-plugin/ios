//----------------------------------------------------------------------------------
//
// CEXTSTORAGE : donnees gloables pour une extension
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>

@interface CExtStorage : NSObject 
{
@public 
	int id;	
}

@end
