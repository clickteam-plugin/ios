// -----------------------------------------------------------------------------
//
// CBACKDRAW classe abtraite pour les backdraw routines
//
// -----------------------------------------------------------------------------
#import "CBackDraw.h"
#import "CRun.h"
#import "CBitmap.h"
@implementation CBackDraw

-(void)execute:(CRun*)rhPtr withBitmap:(CBitmap*)g2
{
}

@end
