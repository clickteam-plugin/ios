//----------------------------------------------------------------------------------
//
// CEMBEDDEDFILE : fichiers inclus dans l'application
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>

@class CRunApp;

@interface CEmbeddedFile : NSObject 
{
@public 
	CRunApp* runApp;
}

-(id)initWithApp:(CRunApp*)app;
-(void)preLoad;

@end
