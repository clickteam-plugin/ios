//----------------------------------------------------------------------------------
//
// CEMBEDDEDFILE : fichiers inclus dans l'application
//
//----------------------------------------------------------------------------------
#import "CEmbeddedFile.h"
#import "CRunApp.h"

@implementation CEmbeddedFile

-(id)initWithApp:(CRunApp*)app
{
	runApp=app;
	return self;
}
-(void)preLoad
{
}
@end
