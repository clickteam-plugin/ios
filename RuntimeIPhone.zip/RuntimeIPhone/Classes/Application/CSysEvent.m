//----------------------------------------------------------------------------------
//
// CSYSEVENT : classe abstraite pour stocker les evenements systeme
//
//----------------------------------------------------------------------------------
#import "CSysEvent.h"
#import "CRun.h"

@implementation CSysEvent

-(void)execute:(CRun*)rhPtr
{
}

@end
