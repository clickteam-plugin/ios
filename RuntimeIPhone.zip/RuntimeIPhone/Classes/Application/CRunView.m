//
//  CRunView.m
//  RuntimeIPhone
//
//  Created by Francois Lionet on 08/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "CRunView.h"
#import "CRunApp.h"
#import "CRunFrame.h"
#import "CRun.h"
#import "CSpriteGen.h"
#import "CJoystick.h"
#import "CServices.h"
#import "CBitmap.h"
#import "ES1Renderer.h"
#import "ES2Renderer.h"
#import "ITouches.h"

@implementation CRunView

+ (Class)layerClass
{
    return [CAEAGLLayer class];
}

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
	return YES;
}

-(id)initWithFrame:(CGRect)rect
{
    if ((self = [super initWithFrame:rect]))
    {
		CAEAGLLayer *eaglLayer = (CAEAGLLayer *)self.layer;
	
		renderer = nil;
		appRect = rect;
		pRunApp = nil;
		
		eaglLayer.opaque = YES;
		eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
										[NSNumber numberWithBool:NO],
										kEAGLDrawablePropertyRetainedBacking,
										kEAGLColorFormatRGBA8,
										kEAGLDrawablePropertyColorFormat, nil];
	
		//Attempt to create ES2 renderer, if not possible create an ES1 renderer
		renderer = [[ES2Renderer alloc] initWithView:self];
		if(renderer==nil)
			renderer = [[ES1Renderer alloc] initWithView:self];
		
		if (renderer==nil)
		{
			[self release];
			return nil;
		}
		
		for (int n=0; n<MAX_VIEWTOUCHES; n++)
			cancelledTouches[n]=nil;

		bTimer=NO;
		displayLink = nil;
		usesDisplayLink = NO;
    }
    return self;
}

-(void)dealloc
{
	if (renderer==nil)
		[self release];
	[super dealloc];
}

-(void)setMultiTouch:(BOOL)bMulti
{
	self.multipleTouchEnabled=bMulti;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if (pRunApp!=nil)
	{
		[pRunApp->run resume];
		
		UITouch* touch = [touches anyObject];
		CGPoint touchPosition = [touch locationInView:self];
		[pRunApp mouseMoved:touchPosition.x withY:touchPosition.y];
		
		BOOL bFlag=NO;
		NSEnumerator *enumerator = [touches objectEnumerator];
		while ((touch = [enumerator nextObject])) 
		{
			BOOL bFlagLocal=NO;
			if (pRunApp->joystick!=nil)
			{
				id<ITouches>oc = pRunApp->joystick;
				bFlagLocal=[oc touchBegan:touch];
				if (bFlagLocal)
				{
					bFlag=YES;
				}
			}
			if (pRunApp->touches!=nil)
			{
				if (bFlagLocal==NO)
				{
					id<ITouches>oc = pRunApp->touches;
					[oc touchBegan:touch];
				}
			}
			if (bFlagLocal)
			{
				int n;
				for (n=0; n<MAX_VIEWTOUCHES; n++)
				{
					if (cancelledTouches[n]==nil)
					{
						cancelledTouches[n]=touch;
						break;
					}
				}
			}
		}		
			
		if (!bFlag)
		{
			[pRunApp mouseDown:YES];
			[pRunApp mouseClicked:[touch tapCount]];
		}
	}
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	if (pRunApp!=nil)
	{
		UITouch* touch = [touches anyObject];
		CGPoint touchPosition = [touch locationInView:self];
        [pRunApp mouseMoved:touchPosition.x withY:touchPosition.y];

		NSEnumerator *enumerator = [touches objectEnumerator];
		while ((touch = [enumerator nextObject])) 
		{
			BOOL bFlagLocal=NO;
			if (pRunApp->joystick!=nil)
			{
				id<ITouches>oc = pRunApp->joystick;
				[oc touchMoved:touch];
			}
			int n;
			for (n=0; n<MAX_VIEWTOUCHES; n++)
			{
				if (cancelledTouches[n]==touch)
				{
					bFlagLocal=YES;
					break;
				}
			}
			if (pRunApp->touches!=nil)
			{
				if (bFlagLocal==NO)
				{
					id<ITouches>oc = pRunApp->touches;
					[oc touchMoved:touch];
				}
			}
		}		
	}
}

-(void)touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event
{
	if (pRunApp!=nil)
	{
		NSEnumerator *enumerator = [touches objectEnumerator];
		UITouch* touch;
		touch = [touches anyObject];
		CGPoint touchPosition = [touch locationInView:self];
        [pRunApp mouseMoved:touchPosition.x withY:touchPosition.y];

		BOOL bFlag=NO;
		while ((touch = [enumerator nextObject])) 
		{
			BOOL bFlagLocal=NO;
			if (pRunApp->joystick!=nil)
			{
				id<ITouches>oc = pRunApp->joystick;				
				[oc touchEnded:touch];
			}
			int n;
			for (n=0; n<MAX_VIEWTOUCHES; n++)
			{
				if (cancelledTouches[n]==touch)
				{
					cancelledTouches[n]=nil;
					bFlagLocal=YES;
					bFlag=YES;
					break;
				}
			}			
			if (pRunApp->touches!=nil)
			{
				if (bFlagLocal==NO)
				{
					id<ITouches>oc = pRunApp->touches;				
					[oc touchEnded:touch];
				}
			}
		}		
		
		if (bFlag==NO)
		{	
			[pRunApp mouseDown:NO];
		}
    }
}

-(void)touchesCancelled:(NSSet*)touches withEvent:(UIEvent*)event
{
	if (pRunApp!=nil)
	{
		NSEnumerator *enumerator = [touches objectEnumerator];
		UITouch* touch;
		while ((touch = [enumerator nextObject])) 
		{
			if (pRunApp->joystick!=nil)
			{
				id<ITouches>oc = pRunApp->joystick;
				[oc touchCancelled:touch];
			}
			int n;
			for (n=0; n<MAX_VIEWTOUCHES; n++)
			{
				if (cancelledTouches[n]==touch)
				{
					cancelledTouches[n]=nil;
					break;
				}
			}			
			if (pRunApp->touches!=nil)
			{
				id<ITouches>oc = pRunApp->touches;
				[oc touchCancelled:touch];
			}
		}		
		[pRunApp mouseDown:NO];
	}
}

-(void)initApplication:(CRunApp*)pApp
{
	pRunApp=pApp;
	[pRunApp setView:self];
	[pRunApp startApplication];
	[[self superview] setNeedsLayout];
}
-(void)pauseTimer
{
	if (bTimer)
	{
		bTimer=NO;
		if(usesDisplayLink)
		{
			[displayLink invalidate];
			displayLink = nil;
		}
		else
		{
			[timer invalidate];
			timer = nil;
		}
	}
}
-(void)resumeTimer
{
	if (bTimer==NO)
	{
		bTimer=YES;
		
		int framerate = pRunApp->gaFrameRate;
		if(framerate == 60 || framerate == 30 || framerate == 15)
		{
			usesDisplayLink = YES;
			frameInterval = 1;
			if(framerate == 30)
				frameInterval = 2;
			else if(framerate == 15)
				frameInterval = 3;
		}
		else
			usesDisplayLink = NO;

		//Which timer to use
		if(usesDisplayLink)
		{
			if(displayLink != nil)
				[displayLink invalidate];
				
			displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(timerEntry)];
			displayLink.frameInterval = frameInterval;
			[displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
		}
		else
			timer=[NSTimer scheduledTimerWithTimeInterval:(double)(1.0/pRunApp->gaFrameRate) target:self selector:@selector(timerEntry) userInfo:nil repeats:YES];
	}
}
-(void)resetFrameRate
{
	[self pauseTimer];
	[self resumeTimer];
}
-(void)endApplication
{
	[self pauseTimer];
}
-(void)timerEntry
{
	[renderer bindRenderBuffer];
	[renderer updateViewport];
	[renderer useBlending:YES];
	
	//Run event loop
	if ( [pRunApp playApplication:NO]==NO )
	{
		[pRunApp endApplication];
		[pRunApp release];
	}
	
	if (pRunApp != nil && pRunApp->joystick!=nil && pRunApp->appRunningState == SL_FRAMELOOP)
		[pRunApp->joystick draw];
	
	[renderer swapBuffers];
}
-(void)drawNoUpdate
{
	[renderer bindRenderBuffer];
	[renderer updateViewport];
	[renderer useBlending:YES];
	[pRunApp->run screen_Update];
	[renderer swapBuffers];
}

- (void)layoutSubviews
{
    [renderer resizeFromLayer:(CAEAGLLayer*)self.layer];
}
-(CRenderer*)getRenderer
{
	return renderer;
}

@end
