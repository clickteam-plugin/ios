//----------------------------------------------------------------------------------
//
// CRUNAPP : objet application
//
//----------------------------------------------------------------------------------
#import "CRunApp.h"
#import "CRunView.h"
#import "CArrayList.h"
#import "CFile.h"
#import "CChunk.h"
#import "CImageBank.h"
#import "CFontBank.h"
#import "CSoundBank.h"
#import "CSoundPlayer.h"
#import "CEmbeddedFile.h"
#import "CValue.h"
#import "COIList.h"
#import "CExtLoader.h"
#import "CCCA.h"
#import "CRunFrame.h"
#import "CServices.h"
#import "CRun.h"
#import "CColMask.h"
#import "CEventProgram.h"
#import "CSpriteGen.h"
#import "CSysEventClick.h"
#import "CJoystick.h"
#import "CJoystickAcc.h"
#import "CBitmap.h"
#import "CTrans.h"
#import "CTransitionManager.h"
#import "CTransitionData.h"
#import "CRenderToTexture.h"
#import "CIAdViewController.h"
#import "MainViewController.h"
#import "CALPlayer.h"

@implementation CRunApp

static CRunApp* sRunApp;

-(void)clear
{
    frameOffsets=nil;
    framePasswords=nil;
    appName=nil;
    globalValuesInitTypes=nil;
    globalValuesInit=nil;
    globalStringsInit=nil;
    OIList=nil;
    imageBank=nil;
    fontBank=nil;
    soundBank=nil;
    soundPlayer=nil;
    ALPlayer=nil;
    gValues=nil;
    gStrings=nil;
    tempGValue=nil;
    parentApp=nil;
	subApp=nil;
    run=nil;
    frameHandleToIndex=nil;
    adGO=nil;
    sysEvents=nil;
    extLoader=nil;
    extensionStorage=nil;
    embeddedFiles=nil;
    transitionManager=nil;
	oldFrameImage=nil;
	iAdViewController=nil;
	
	frameMaxIndex=0;
	startFrame=0;
	appRunFlags=0;
	quit=NO;
	debug=0;
	bUnicode=NO;
	displayType=0;
	bStatusBar=NO;
	orientation=ORIENTATION_PORTRAIT;
	sRunApp = self;
}
-(id)initWithPath:(NSString*)path
{
	[self clear];
	file=[[CFile alloc] initWithPath:path];
	return self;
}
-(id)initWithFile:(CFile*)f
{
	[self clear];
	file=f;
	[file setFilePointer:0];
	return self;
}
	
-(void)setView:(CRunView*)pView
{
	runView=pView;
	renderer = runView->renderer;
}
-(void)dealloc
{
	[super dealloc];
}
-(void)setParentApp:(CRunView*)view withApp:(CRunApp*)pApp startFrame:(int)sFrame options:(int)options width:(int)sx height:(int)sy
{
	parentApp = pApp;
	parentOptions = options;
	startFrame = sFrame;
	[self setView:view];
	gaCxWin=sx;
	gaCyWin=sy;
	parentWidth=sx;
	parentHeight=sy;
}
-(void)setIAdViewController:(CIAdViewController*)pCont
{
	iAdViewController=pCont;
}
-(void)setMainViewController:(MainViewController*)pCont
{
	mainViewController=pCont;
}
-(BOOL)load
{	
	// Charge le mini-header
	char* name = (char*)malloc(4);
	[file readACharBuffer:name withLength:4];		    // gaType
	BOOL bOK=NO;
	if (name[0]=='P' && name[1]=='A' && name[2]=='M' && name[3]=='E')
	{
		bOK=true;
		bUnicode=false;
	}
	if (name[0]=='P' && name[1]=='A' && name[2]=='M' && name[3]=='U')
	{
		bOK=true;
		bUnicode=true;
	}
	free(name);
	if (!bOK)
	{
		return NO;
	}
	
	[file setUnicode:bUnicode];
	
	short s = [file readAShort];	    // gaVersion
	if (s != RUNTIME_VERSION)
	{
		return NO;
	}
	
	[file readAShort];		    // gaSubversion
	[file readAInt];		    // gaPrdVersion
	[file skipBytes:4];		    // gaPrdBuild
		
	// Reserve les objets
	OIList = [[COIList alloc] init];
	imageBank = [[CImageBank alloc] initWithApp:self];
	fontBank = [[CFontBank alloc] initWithApp:self];
	soundBank = [[CSoundBank alloc] initWithApp:self];
	soundPlayer = [[CSoundPlayer alloc] initWithApp:self];
	ALPlayer = [[CALPlayer alloc] init];
	
	// Lis les chunks
	CChunk* chk = [[CChunk alloc] init];
	int posEnd;
	int nbPass = 0, n;
	while (chk->chID != CHUNK_LAST)
	{
		[chk readHeader:file];
		if (chk->chSize == 0)
		{
			continue;
		}
		posEnd = [file getFilePointer] + chk->chSize;
		
		switch (chk->chID)
		{
			case CHUNK_APPHEADER:
				[self loadAppHeader];
				// Buffer pour les offsets frame
				frameOffsets = (int*)malloc(gaNbFrames*sizeof(int));
				// Pour les password
				framePasswords = (NSString**)malloc(gaNbFrames*sizeof(NSString*));
				for (n = 0; n < gaNbFrames; n++)
				{
					framePasswords[n] = nil;
				}
				break;			
			case CHUNK_APPHEADER2:
				[self loadAppHeader2];
				break;
			case CHUNK_APPNAME:
				appName = [file readAString];
				break;
			case CHUNK_GLOBALVALUES:
				[self loadGlobalValues];
				break;
			case CHUNK_GLOBALSTRINGS:
				[self loadGlobalStrings];
				break;
			case CHUNK_FRAMEITEMS:
			case CHUNK_FRAMEITEMS_2:
				[OIList preLoad:file];
				break;
			case CHUNK_FRAMEHANDLES:
				[self loadFrameHandles:chk->chSize];
				break;
				
			case CHUNK_FRAME:
			{
				// Repere les positions des frames dans le fichier
				frameOffsets[frameMaxIndex] = [file getFilePointer];
				CChunk* frChk = [[CChunk alloc] init];
				while (frChk->chID != 0x7F7F)		// CHUNK_LAST
				{
					[frChk readHeader:file];
					if (frChk->chSize == 0)
					{
						continue;
					}
					int frPosEnd = [file getFilePointer] + frChk->chSize;
					
					switch (frChk->chID)
					{
						case CHUNK_FRAMEHEADER:
							break;
						case CHUNK_FRAMEPASSWORD:
							framePasswords[frameMaxIndex] = [file readAString];
							nbPass++;
							break;
					}
					[file seek:frPosEnd];
				}
				frameMaxIndex++;
				[frChk release];	
				break;
			}
		
			case CHUNK_EXTENSIONS2:
				extLoader = [[CExtLoader alloc] initWithApp:self];
				[extLoader loadList];
				break;
			case CHUNK_BINARYFILES:
			{
				int nFiles = [file readAInt];
				embeddedFiles = [[CArrayList alloc] init];
				for (n = 0; n < nFiles; n++)
				{
					CEmbeddedFile* pEmb=[[CEmbeddedFile alloc] initWithApp:self];
					[embeddedFiles add:pEmb];
					[pEmb preLoad];
				}
				break;
			}
			case CHUNK_IMAGES:
				[imageBank preLoad];
				break;
			case CHUNK_FONTS:
				[fontBank preLoad];
				break;
			case CHUNK_SOUNDS:
				[soundBank preLoad];
				break;
		
		}
		
		// Positionne a la fin du chunk
		[file seek:posEnd];
	}
	[chk release];
	
	// Fixe le flags multiple samples
	[soundPlayer setMultipleSounds:((gaFlags & GA_MIX)!=0)];
	
	screenRect = [[UIScreen mainScreen] applicationFrame];
	if (orientation!=ORIENTATION_PORTRAIT)
		screenRect = CGRectMake(0, 0, screenRect.size.height, screenRect.size.width);
	
	return YES;
}

// Lancement de l'application
-(BOOL)startApplication
{
	// Init RUN LOOP
	run = [[CRun alloc] initWithApp:self];
	events = [[CEventProgram alloc] initWithApp:self];
	spriteGen=[[CSpriteGen alloc] initWithBank:imageBank andApp:self];
	
	// Initialisation des events
	sysEvents = [[CArrayList alloc] init];
	
	appRunningState = 0;	    // SL_RESTART
	currentFrame = -2;
	displayType = -1;
	return YES;
}
	 
-(void)createDisplay
{
	sxView=(int)runView.bounds.size.width;
	syView=(int)runView.bounds.size.height;
	xOffset=0;
	yOffset=0;
}		

// Fait fonctionner l'application
-(BOOL)playApplication:(BOOL)bOnlyRestartApp
{
	int error = 0;
	BOOL bLoop = YES;
	BOOL bContinue = YES;
	
	VBLCount++;
	do
	{
		switch (appRunningState)
		{
                // SL_RESTART
			case 0:
				[self initGlobal];
				nextFrame = startFrame;
				appRunningState = 1;
				[self killGlobalData];
				// reInitMenu();
				// Build 248 : only restart application?
				if (bOnlyRestartApp)
				{
					// Used in Sub-Applications, initializes application global data and exit
					// (= don't execute the first frame loop now, it will be executed at the end
					// of the first loop of the parent frame as usual)
					bLoop = false;
					break;
				}
                // SL_STARTFRAME
			case 1:
				error = [self startTheFrame];
				break;
                // SL_FRAMEFADEINLOOP
			case 2:
				if ([self loopFrameFadeIn] == NO)
				{
					[self endFrameFadeIn];
					if (appRunningState == SL_QUIT || appRunningState == SL_RESTART)
					{
						[self endFrame];
					}
				}
				else
				{
					bLoop = false;
				}
				break;
                // SL_FRAMELOOP
			case 3:
				if ([self loopFrame] == NO)
				{
					if ([self startFrameFadeOut:oldFrameImage])
					{
						appRunningState=SL_FRAMEFADEOUTLOOP;
					}
					else
					{
						[self endFrame];
					}
				}
				else
				{
					bLoop = NO;
				}
				break;
                // SL_FRAMEFADEOUTLOOP
			case 4:
				if ([self loopFrameFadeOut]==NO)
				{
					[self endFrameFadeOut];
					if (appRunningState == SL_QUIT || appRunningState == SL_RESTART)
					{
						[self endFrame];
					}
				}
				else
				{
					bLoop = NO;
				}
				break;
                // SL_ENDFRAME
			case 5:
				[self endFrame];
				break;
			default:
				bLoop = NO;
				break;
		}
	} while (bLoop == YES && error == 0 && quit == NO);
	
	// Error?
	if (error != 0)
	{
		appRunningState = SL_QUIT;
	}
	
	// Quit ?
	if (appRunningState == SL_QUIT)
	{
		bContinue = NO;
	}
	
	// RAZ souris
	mouseClick=0;
	
	// Continue?
	return bContinue;
}

// End application
-(void)endApplication
{
	if (parentApp==nil)
	{
		[runView endApplication];
		[file release];
		[self killAccelerometer];
	}
	
	// Stop sounds
	if (soundPlayer != nil)
	{
		[soundPlayer stopAllSounds];
	}
	
	[imageBank release];
	[fontBank release];
	[soundBank release];
	[soundPlayer release];
    [ALPlayer release];
    
	[OIList release];
	
	if (embeddedFiles!=nil)
	{
		[embeddedFiles clearRelease];
		[embeddedFiles release];
	}
	
	[sysEvents clearRelease];
	[sysEvents release];
	[self killGlobalData];
	
	free(frameOffsets);
	if (frameHandleToIndex!=nil)
	{
		free(frameHandleToIndex);
	}
	
	int n;
	for (n=0; n<gaNbFrames; n++)
	{
		if (framePasswords[n]!=nil)
		{
			[framePasswords[n] release];
		}
	}
	
	if (globalValuesInit!=nil)
	{
		free(globalValuesInit);
	}
	if (globalStringsInit!=nil)
	{
		for (n=0; n<nGlobalStringsInit; n++)
		{
			[globalStringsInit[n] release];
		}
		free(globalStringsInit);
	}
	if (gValues!=nil)
	{
		[gValues clearRelease];
		[gValues release];
	}
	if (gStrings!=nil)
	{
		[gStrings clearRelease];
		[gStrings release];
	}
	if (run!=nil)
	{
		[run release];
	}
	if (frame!=nil)
	{
		[frame release];
	}
	if (spriteGen!=nil)
	{
		[spriteGen release];
	}
	if (events!=nil)
	{
		[events release];
	}
	if (extensionStorage!=nil)
	{
		[extensionStorage clearRelease];
		[extensionStorage release];
	}
	if (transitionManager!=nil)
	{
		[transitionManager release];
	}
	if (joystickAcc!=nil)
	{
		[joystickAcc release];
	}
	if (joystick!=nil)
	{
		[joystick release];
	}
	if(oldFrameImage!=nil)
	{
		[oldFrameImage release];
	}
}

// Memory warning
-(void)cleanMemory
{
	if (run!=nil)
	{
		[run cleanMemory];
	}
	if (imageBank!=nil)
	{
		[imageBank cleanMemory];
	}
	if (soundBank!=nil)
	{
		[soundBank cleanMemory];
	}
	if (renderer != nil)
	{
		[renderer cleanMemory];
	}
}

// Charge la frame
-(int)startTheFrame
{	
	int error = 0;
	//CBitmap* pOldSurf = nil;
	
	do
	{
        iOSObject=nil;

		// Charge la frame
		if (nextFrame != currentFrame)
		{
			if (frame!=nil)
			{
				[frame release];
			}
			frame = [[CRunFrame alloc] initWithApp:self];
			if ([frame loadFullFrame:nextFrame]==NO)
			{
				error = -1;
				break;
			}
			currentFrame = nextFrame;
		}
		
		// Init runtime variables
		frame->leX = frame->leY = 0;
		frame->leLastScrlX = frame->leLastScrlY = 0;
		frame->rhOK = NO;
		frame->levelQuit = 0;
		
		// Creates logical screen
		int cxLog = min(gaCxWin, frame->leWidth);
		int cyLog = min(gaCyWin, frame->leHeight);
		frame->leEditWinWidth = cxLog;
		frame->leEditWinHeight = cyLog;
		
	
		// Calculate maximum number of sprites (add max. number of bkd sprites)
//		int nMaxSprite = frame->maxObjects * 2;		    // * 2 for background objects created as sprites
//		for (short i = 0; i < frame->LOList->nIndex; i++)
//		{
//			CLO* lo = [frame->LOList getLOFromIndex:i];
//			if (lo->loLayer > 0)
//			{
//				COI* oi = [OIList getOIFromHandle:lo->loOiHandle];
//				if (oi->oiType < COI.OBJ_SPR)
//				{
//					nMaxSprite++;
//				}
//			}
//		}
		
		// Create collision mask
		int flags = [events getCollisionFlags];
		flags |= [frame getMaskBits];
		frame->leFlags |= LEF_TOTALCOLMASK;
		if (frame->colMask!=nil)
		{
			[frame->colMask release];			
			frame->colMask = nil;
		}
		if ((frame->leFlags & LEF_TOTALCOLMASK) != 0)
		{
			if ((flags & (CM_OBSTACLE | CM_PLATFORM)) != 0)
			{
				frame->colMask = [CColMask create:-COLMASK_XMARGIN withY1:-COLMASK_YMARGIN andX2:frame->leWidth + COLMASK_XMARGIN andY2:frame->leHeight + COLMASK_YMARGIN andFlags:flags];
			}
		}
		
		if (displayType < 0)
		{
			// Taille de la fenetre
			if (parentApp != nil)
			{
				if ((parentOptions & CCAF_CUSTOMSIZE) != 0)
				{
					gaCxWin = parentWidth;
					gaCyWin = parentHeight;
				}
				else
				{
					if (parentHeight > 0)
					{
						gaCxWin = parentWidth;
					}
					if (parentWidth > 0)
					{
						gaCyWin = parentHeight;
					}
				}
				if ((parentOptions & CCAF_STRETCH) != 0)
				{
					gaFlags |= GA_STRETCH;
				}
				displayType=1;
			}
			
			// Creation de la fenetre
			[self createDisplay];
		}
		
		[spriteGen setFrame:frame];
		[renderer setProjectionMatrix:renderer->topLeft.x andY:renderer->topLeft.y andWidth:renderer->currentWidth andHeight:renderer->currentHeight];
	}
	while (false);
			
	// Init runloop
	firstMask=nil;
	secondMask=nil;
		
	[run initRunLoop:(frame->fadeIn!=nil)];
	
	// Sets idle timer
	[[UIApplication sharedApplication] setIdleTimerDisabled:(frame->iPhoneOptions&IPHONEOPT_SCREENLOCKING)!=0];
    
	// Set app running state
	if (frame->fadeIn != nil)
	{
		// Do 1st loop
		if ([self loopFrame]==NO)
		{
			appRunningState = SL_ENDFRAME;
		}
		else
		{
			if(oldFrameImage == nil)
			{
				oldFrameImage = [[CRenderToTexture alloc] initWithWidth:runView->renderer->backingWidth andHeight:runView->renderer->backingHeight andRunApp:self];
			}
			
			if ([self startFrameFadeIn:oldFrameImage]==NO)
			{
				appRunningState = SL_FRAMELOOP;
			}
		}
	}
	else
	{
		appRunningState = SL_FRAMELOOP;
		
		if (oldFrameImage!=nil)
		{
			[oldFrameImage release];
			oldFrameImage = nil;
		}
	}	
	
	if (error != 0)
	{
		appRunningState = SL_QUIT;
	}
	return error;
}

// Un tour de boucle
-(BOOL)loopFrame
{
	if (frame->levelQuit == 0)
	{
		// One frame loop
		frame->levelQuit = [run doRunLoop];
	}
	return (frame->levelQuit == 0);
}

// Sortie d'une boucle
-(void)endFrame
{
	int ul;
	
	// Fin de la boucle => renvoyer code de sortie
	ul = [run killRunLoop:frame->levelQuit keepSounds:NO];
	
	// Run Frame?
	if ((gaNewFlags & GANF_RUNFRAME) != 0)
	{
		appRunningState = SL_QUIT;
	}
	// Calculer event en fonction du code de sortie
	else
	{
		switch (LOWORD(ul))
		{
                // Next frame
			case 1:				// LOOPEXIT_NEXTLEVEL
				nextFrame = currentFrame + 1;
				appRunningState = SL_STARTFRAME;
				break;
						
                // Previous frame
			case 2:				// LOOPEXIT_PREVLEVEL:
				nextFrame = max(0, currentFrame-1);
				appRunningState = SL_STARTFRAME;
				break;
				
                // Jump to frame
			case 3:				// LOOPEXIT_GOTOLEVEL:
				appRunningState = SL_STARTFRAME;
				if ((HIWORD(ul) & 0x8000) != 0)			// Si flag 0x8000, numero de cellule direct
				{
					nextFrame = HIWORD(ul) & 0x7FFF;
					if (nextFrame >= gaNbFrames)
					{
						nextFrame = gaNbFrames - 1;
					}
					if (nextFrame < 0)
					{
						nextFrame = 0;
					}
				}
				else											// Sinon, HCELL
				{
					if (HIWORD(ul)<frameMaxHandle)
					{
						nextFrame = frameHandleToIndex[HIWORD(ul)];
						if (nextFrame == -1)
						{
							nextFrame = currentFrame + 1;
						}
					}
					else
					{
						nextFrame = currentFrame + 1;
					}
				}
				break;
				
                // Restart application
			case 4:				// LOOPEXIT_NEWGAME:
				// Restart application
				appRunningState = SL_RESTART;
				nextFrame = startFrame;
				break;
				
                // Quit
			default:
				appRunningState = SL_QUIT;
				break;
		}
	}
	
	if (appRunningState == SL_STARTFRAME)
	{
		// If invalid frame number, quit current game
		if (nextFrame < 0 || nextFrame >= gaNbFrames)
		{
			appRunningState = SL_QUIT;
		}
	}
	
	// Unload current frame if frame change
	if (appRunningState != SL_STARTFRAME || nextFrame != currentFrame)
	{		
		// Reset current frame
		currentFrame = -1;
	}
}

// RAZ des donnes objets globaux
-(void)killGlobalData
{
	if (adGO!=nil)
	{
		[adGO release];
		adGO = nil;
	}
}

// Transitions
-(CTransitionManager*)getTransitionManager
{
	if (transitionManager==nil)
	{
		transitionManager=[[CTransitionManager alloc] initWithApp:self];
	}
	return transitionManager;
}

// Gestion du fade in
-(BOOL)startFrameFadeIn:(CRenderToTexture*)oldImage
{
	CTransitionData* pData=frame->fadeIn;

	if (pData!=nil)
	{
		CRenderToTexture* newImage = [[CRenderToTexture alloc] initWithWidth:runView->renderer->backingWidth andHeight:runView->renderer->backingHeight andRunApp:self];
		
		//Render into the new frame buffer
		[newImage bindFrameBuffer];
		[renderer updateViewport];
		[run transitionDrawFrame];
		[newImage unbindFrameBuffer];
		[newImage clearAlphaChannel:1.0f];
		
		// Fill source surface
		if ((pData->transFlags&TRFLAG_COLOR)!=0)
			[oldImage fillWithColor:pData->transColor];		
		
		[renderer flush];
		
		// Starts the transition
		frame->pTrans=[[self getTransitionManager] createTransition:pData withRenderer:renderer andStart:oldImage andEnd:newImage andType:0];
		if (frame->pTrans!=nil)
		{
			appRunningState=SL_FRAMEFADEINLOOP;
			return YES;
		}
	}

	[run createRemainingFrameObjects];
	[self endFrameFadeIn];
	return NO;		
}
-(BOOL)loopFrameFadeIn
{
	if (frame->pTrans!=nil)
	{
		if ([frame->pTrans isCompleted])
		{
			[self endFrameFadeIn];
			return NO;
		}
		[renderer setOriginX:0 andY:0];
		[frame->pTrans stepDraw:TRFLAG_FADEIN];
		return YES;
	}
	return NO;
}
-(BOOL)endFrameFadeIn
{
	if (frame->pTrans!=nil)
	{
		[frame->pTrans end];
		[frame->pTrans release];
		frame->pTrans=nil;
		if (appRunningState==SL_FRAMEFADEINLOOP)
		{
			appRunningState=SL_FRAMELOOP;
		}
		[run createRemainingFrameObjects];
	}
	return YES;
}

// Gestion du fade out
-(BOOL)startFrameFadeOut:(CRenderToTexture*)oldImage
{
	CTransitionData* pData=frame->fadeOut;
	 	
	if (pData!=nil)
	{
		CRenderToTexture* targetImage = [[CRenderToTexture alloc] initWithWidth:runView->renderer->backingWidth andHeight:runView->renderer->backingHeight andRunApp:self];
				
		if ((pData->transFlags&TRFLAG_COLOR)!=0)
			[targetImage fillWithColor:pData->transColor];
		else
			[targetImage fillWithColor:0];
		
		[oldImage clearAlphaChannel:1.0f];
		
		// Starts transition
		frame->pTrans=[[self getTransitionManager] createTransition:pData withRenderer:renderer andStart:oldImage andEnd:targetImage andType:0];
		if (frame->pTrans!=nil)
		{
			appRunningState=SL_FRAMEFADEOUTLOOP;
			return YES;
		}
	}
	[self endFrameFadeOut];

	return NO;
}
-(BOOL)loopFrameFadeOut
{
	if (frame->pTrans!=nil)
	{
		if ([frame->pTrans isCompleted])
		{
			[self endFrameFadeOut];
			return NO;
		}
		[renderer setOriginX:0 andY:0];
		[frame->pTrans stepDraw:TRFLAG_FADEOUT];
		return YES;
	}
	return NO;
}
-(BOOL)endFrameFadeOut
{
	if (frame->pTrans!=nil)
	{
		[frame->pTrans end];
		[frame->pTrans release];
		frame->pTrans=nil;
		if (appRunningState==SL_FRAMEFADEOUTLOOP)
		{
			appRunningState=SL_ENDFRAME;
		}
	}
	return YES;
}

// Initialise les variables globales
-(void)initGlobal
{
	int n;
	
	// Vies et score
	if (parentApp == nil || (parentApp != nil && (parentOptions & CCAF_SHARE_LIVES) == 0))
	{
		for (n = 0; n < MAX_PLAYER; n++)
		{
			lives[n] = gaLivesInit ^ 0xFFFFFFFF;
		}
		bLivesExternal=NO;
	}
	else
	{
		bLivesExternal=YES;
	}
	
	if (parentApp == nil || (parentApp != nil && (parentOptions & CCAF_SHARE_SCORES) == 0))
	{
		for (n = 0; n < MAX_PLAYER; n++)
		{
			scores[n] = gaScoreInit ^ 0xFFFFFFFF;
		}
		bScoresExternal=NO;
	}
	else
	{
		bScoresExternal=YES;
	}

	for (n = 0; n < MAX_PLAYER; n++)
	{
		playerNames[n] = [[NSString alloc] init];
	}

	// Global values
	if (parentApp == nil || (parentApp != nil && (parentOptions & CCAF_SHARE_GLOBALVALUES) == 0) )
	{
		gValues = [[CArrayList alloc] init];
		for (n = 0; n < nGlobalValuesInit; n++)
		{
			[gValues add:[[CValue alloc] initWithInt:globalValuesInit[n]]];
		}
	}
	else
	{
		gValues = nil;
	}
	tempGValue = [[CValue alloc] init];

	// Global strings
	if (parentApp == nil || (parentApp != nil && (parentOptions & CCAF_SHARE_GLOBALVALUES) == 0) )
	{
		gStrings = [[CArrayList alloc] init];
		for (n = 0; n < nGlobalStringsInit; n++)
		{
			[gStrings add:[[NSString alloc] initWithString:globalStringsInit[n]]];
		}
	}
	else
	{
		gStrings = nil;
	}
}
			
// Retourne les vies et les scores
-(int*)getLives
{
	CRunApp* app = self;
	while (app->bLivesExternal==YES)
	{
		app = app->parentApp;
	}
	return app->lives;
}

-(int*)getScores
{
	CRunApp* app = self;
	while (app->bScoresExternal==YES)
	{
		app = app->parentApp;
	}
	return app->scores;
}

// Recherche les global values dans les parents
-(CArrayList*)getGlobalValues
{
	CRunApp* app = self;
	while (app->gValues==nil)
	{
		app = app->parentApp;
	}
	return app->gValues;
}

-(int)getNGlobalValues
{
	if (gValues != nil)
	{
		return [gValues size];
	}
	return 0;
}

-(CArrayList*)getGlobalStrings
{
	CRunApp* app = self;
	while (app->gStrings == nil)
	{
		app = app->parentApp;
	}
	return app->gStrings;
}

-(int)getNGlobalStrings
{
	if (gStrings != nil)
	{
		return [gStrings size];
	}
	return 0;
}

-(CArrayList*)checkGlobalValue:(int)num
{
	CArrayList*values = [self getGlobalValues];
	
	if (num < 0 || num > 1000)
	{
		return nil;
	}
	int oldSize = [values size];
	if (num >= oldSize)
	{
		[values ensureCapacity:num];
		int n;
		for (n = oldSize; n <= num; n++)
		{
			[values add:[[CValue alloc] init]];
		}
	}
	return values;
}

-(CValue*)getGlobalValueAt:(int)num
{
	CArrayList* values = [self checkGlobalValue:num];
	if (values != nil)
	{
		return (CValue*)[values get:num];
	}
	return tempGValue;
}

-(void)setGlobalValueAt:(int)num value:(CValue*)value
{
	CArrayList* values = [self checkGlobalValue:num];
	if (values != nil)
	{
		[ ((CValue*)[values get:num]) forceValue:value];
	}
}

-(CArrayList*)checkGlobalString:(int)num
{
	CArrayList* strings = [self getGlobalStrings];
	
	if (num < 0 || num > 1000)
	{
		return nil;
	}
	int oldSize = [strings size];
	if (num >= oldSize)
	{
		[strings ensureCapacity:num];
		int n;
		for (n = oldSize; n <= num; n++)
		{
			[strings add:[[NSString alloc] init]];
		}
	}
	return strings;
}

-(NSString*)getGlobalStringAt:(int)num
{
	CArrayList* strings = [self checkGlobalString:num];
	if (strings != nil)
	{
		return (NSString*)[strings get:num];
	}
	return @"";
}

-(void) setGlobalStringAt:(int)num string:(NSString*)value
{
	CArrayList* strings = [self checkGlobalString:num];
	if (strings != nil)
	{
		NSString* s=(NSString*)[strings get:num];
		if (s!=nil)
		{
			[s release];
		}
		s=[[NSString alloc] initWithString:value];
		[strings set:num object:s];
	}
}

// Charge le header de l'application
-(void)loadAppHeader
{
	[file skipBytes:4];			// Structure size
	gaFlags = [file readAShort];   		// Flags
	gaNewFlags = [file readAShort];		// New flags
	gaMode = [file readAShort];		// graphic mode
	gaOtherFlags = [file readAShort];		// Other Flags
	gaCxWin = [file readAShort];		// Window x-size
	gaCyWin = [file readAShort];		// Window y-size
	gaScoreInit = [file readAInt];		// Initial score
	gaLivesInit = [file readAInt];		// Initial number of lives
	[file skipBytes:MAX_PLAYER*sizeof(short)]; // Control type
	[file skipBytes:MAX_PLAYER*MAX_KEY*sizeof(short)];
	gaBorderColour = [file readAColor];	// Border colour
	gaNbFrames = [file readAInt];		// Number of frames
	gaFrameRate = [file readAInt];		// Number of frames per second
	[file skipBytes:4];
}

// Charge le header de l'application
-(void)loadAppHeader2
{
	hdr2Options=[file readAInt];
	[file skipBytes:10];
	orientation=[file readAShort];
}
	
// Charge le chunk GlobalValues
-(void)loadGlobalValues
{
	nGlobalValuesInit = [file readAShort];
	globalValuesInit = (int*)malloc(nGlobalValuesInit*sizeof(int));
	globalValuesInitTypes = (char*)malloc(nGlobalValuesInit*sizeof(char));
	int n;
	for (n = 0; n < nGlobalValuesInit; n++)
	{
		globalValuesInit[n] = [file readAInt];
	}
	[file readACharBuffer:globalValuesInitTypes withLength:nGlobalValuesInit];
}

// Charge le chunk GlobalStrings
-(void)loadGlobalStrings
{
	nGlobalStringsInit = [file readAInt];
	globalStringsInit = (NSString**)malloc(nGlobalStringsInit*sizeof(NSString*));
	int n;
	for (n = 0; n < nGlobalStringsInit; n++)
	{
		globalStringsInit[n] = [file readAString];
	}
}

// Charge le chunk Frame handles
-(void) loadFrameHandles:(int)size
{
	frameMaxHandle = (short) (size / 2);
	frameHandleToIndex = (short*)malloc(frameMaxHandle*sizeof(short));
	
	int n;
	for (n = 0; n < frameMaxHandle; n++)
	{
		frameHandleToIndex[n] = [file readAShort];
	}
}

// Transformation d'un HCELL en numero de cellule
-(short)HCellToNCell:(short)hCell
{
	if (frameHandleToIndex == nil || hCell == -1 || hCell >= frameMaxHandle)
	{
		return -1;
	}
	return frameHandleToIndex[hCell];
}
-(int)newGetCptVBL
{
	return VBLCount;
}

-(void)setFrameRate:(int)rate
{
	if (parentApp==nil)
	{
		gaFrameRate=rate;
		[runView resetFrameRate];
	}
}

// GESTION SOURIS ///////////////////////////////////////////////////////////////
-(void)mouseMoved:(int)x withY:(int)y
{
	mouseX=x;
	mouseY=y;
	if (run!=nil)
	{
		[run mouseMoved:x withY:y];
	}
}
-(void)mouseClicked:(int)numTap
{
	mouseClick=numTap;
	if (run!=nil)
	{
		CSysEventClick* click=[[CSysEventClick alloc] initWithClick:numTap];
		[sysEvents add:click];
		[run mouseClicked:numTap];
	}
}
-(void)mouseDown:(BOOL)bFlag
{
	bMouseDown=bFlag;
	if (run!=nil)
	{
		[run mouseDown:bFlag];
	}
}

// GESTION JOYSTICK ////////////////////////////////////////////////////////////
-(void)createJoystick:(BOOL)bCreate withFlags:(int)flags
{
	if (bCreate)
	{		
		if (joystick==nil)
		{
			joystick=[[CJoystick alloc] initWithApp:self];
		}
		[joystick reset:flags];
	}
	else
	{
		if (joystick!=nil)
		{
			[joystick release];
			joystick=nil;
		}
	}
}
-(void)createJoystickAcc:(BOOL)bCreate
{
	if (bCreate)
	{		
		if (joystickAcc==nil)
		{
			joystickAcc=[[CJoystickAcc alloc] initWithApp:self];
		}
	}
	else
	{
		if (joystickAcc!=nil)
		{
			[joystickAcc release];
			joystickAcc=nil;
		}
	}
}	

// ACCELEROMETER //////////////////////////////////////////////////////////////
-(void)startAccelerometer
{
	if (accelerometerCount==0)
	{
		UIAccelerometer* accelerometer=[UIAccelerometer sharedAccelerometer];
		accelerometer.updateInterval=1.0/gaFrameRate;
		accelerometer.delegate=self;
	}
    accelerometerCount++;
}
-(void)endAccelerometer
{
	accelerometerCount--;
	if (accelerometerCount==0)
	{
		UIAccelerometer* accelerometer=[UIAccelerometer sharedAccelerometer];
		accelerometer.updateInterval=1.0;
		accelerometer.delegate=nil;
	}	
}
-(void)killAccelerometer
{
	if (accelerometerCount>0)
	{
		accelerometerCount=1;
		[self endAccelerometer];
	}
}
-(void)accelerometer:(UIAccelerometer*)accelerometer didAccelerate:(UIAcceleration*)acceleration
{	
	switch (orientation)
	{
	case ORIENTATION_PORTRAIT:
		accX=acceleration.x;
		accY=acceleration.y;
		accZ=acceleration.z;
		break;
	case ORIENTATION_LANDSCAPELEFT:
		accX=acceleration.y;
		accY=-acceleration.x;
		accZ=acceleration.z;
		break;
	case ORIENTATION_LANDSCAPERIGHT:
		accX=-acceleration.x;
		accY=acceleration.y;
		accZ=acceleration.z;
		break;
	}
	filteredAccX = ( (accX * kFilteringFactor) + (filteredAccX * (1.0 - kFilteringFactor)) );
	filteredAccY = ( (accY * kFilteringFactor) + (filteredAccY * (1.0 - kFilteringFactor)) );
	filteredAccZ = ( (accZ * kFilteringFactor) + (filteredAccZ * (1.0 - kFilteringFactor)) );
	instantAccX = accX - ( (accX * kFilteringFactor) + (instantAccX * (1.0 - kFilteringFactor)) );
    instantAccY = accY - ( (accY * kFilteringFactor) + (instantAccY * (1.0 - kFilteringFactor)) );
    instantAccZ = accZ - ( (accZ * kFilteringFactor) + (instantAccZ * (1.0 - kFilteringFactor)) );	

	if (joystickAcc!=nil)
	{
		[joystickAcc handle];
	}
}

+(CRunApp*)getRunApp
{
	return sRunApp;
}

-(void)positionUIElement:(UIView*)view withObject:(CObject*)ho
{
	CRun* rh = run;	
	int plusX = 0, plusY = 0;
	
	for(CCCA* sub = subApp; sub != nil; sub = sub->subApp->parentApp->subApp)
	{
		plusX += sub->hoX;
		plusY += sub->hoY;
	}
    view.frame = CGRectMake((ho->hoX-rh->rhWindowX+plusX), (ho->hoY-rh->rhWindowY+plusY), ho->hoImgWidth, (ho->hoImgHeight));
}


@end
