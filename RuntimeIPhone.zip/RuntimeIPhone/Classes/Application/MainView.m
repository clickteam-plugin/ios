//
//  MainView.m
//  RuntimeIPhone
//
//  Created by Anders Riggelsen on 3/30/11.
//  Copyright 2011 Clickteam. All rights reserved.
//

#import "MainView.h"
#import "CRunView.h"
#import "CRunApp.h"

@implementation MainView

-(id)initWithFrame:(CGRect)rect andRunApp:(CRunApp*)rApp
{
	if(self == [super initWithFrame:rect])
	{
		screenRect = rect;
		runApp = rApp;
		return self;
	}
	return nil;
}

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
	return YES;
}

-(void)layoutSubviews
{
	if([self.subviews count] == 0)
		return;
		
	CRunView* runView = (CRunView*)[self.subviews objectAtIndex:0];
	CRunApp* rhApp = runView->pRunApp;
	
	if(rhApp == nil)
		return;
	
	CGSize s = [[UIScreen mainScreen] bounds].size;
	CGSize z = screenRect.size;	
	CGSize a = runView->appRect.size;
	float scale = MIN(z.width/a.width, z.height/a.height);
	
	//Center in screen
	CGAffineTransform t = CGAffineTransformMakeScale(scale, scale);
	
	switch (rhApp->orientation)
	{
		case ORIENTATION_LANDSCAPELEFT:
			t = CGAffineTransformRotate(t, -M_PI/2.0);
			break;
		case ORIENTATION_LANDSCAPERIGHT:
			t = CGAffineTransformRotate(t, M_PI/2.0);
			break;
	}
    int sWidth=s.width*[UIScreen mainScreen].scale;
    if (sWidth==320)
    {
        runView.center = CGPointMake(s.width/2.0, s.height/2.0);
    }
    else if (sWidth==640)
    {
        switch(rhApp->orientation)
        {
            case ORIENTATION_PORTRAIT:
                switch((int)a.width)
                {
                    case 320:
                    case 640:
                    default:
                        runView.center = CGPointMake(s.width/2.0, s.height/2.0);
                        break;
                    case 768:
                        t=CGAffineTransformTranslate(t, -536, -640);                        
                        break;
                }
                break;
            case ORIENTATION_LANDSCAPELEFT:
                switch((int)a.width)
                {
                    case 480:
                    case 960:
                    default:
                        runView.center = CGPointMake(s.width/2.0, s.height/2.0);
                        break;
                    case 1024:
                        t=CGAffineTransformTranslate(t, 326, -840);                        
                        break;
                }
                break;
            case ORIENTATION_LANDSCAPERIGHT:
                switch((int)a.width)
                {
                    case 480:
                    case 960:
                    default:
                        runView.center = CGPointMake(s.width/2.0, s.height/2.0);
                        break;
                    case 1024:
                        t=CGAffineTransformTranslate(t, -328, 844);                        
                        break;
                }
                break;
        }
    }
    else if (sWidth==768)
    {
        switch(rhApp->orientation)
        {
            case ORIENTATION_PORTRAIT:
                switch((int)a.width)
                {
                    case 320:
                        t=CGAffineTransformTranslate(t, 108, 128);
                        break;
                    case 640:
                        t=CGAffineTransformTranslate(t, 64, 28);
                        break;
                    case 768:
                    default:
                        runView.center = CGPointMake(s.width/2.0, s.height/2.0);
                        break;
                }
                break;
            case ORIENTATION_LANDSCAPELEFT:
                switch((int)a.width)
                {
                    case 480:
                        t=CGAffineTransformTranslate(t, -164, 64);
                        break;
                    case 960:
                        t=CGAffineTransformTranslate(t, -180, -86);
                        break;
                    case 1024:
                    default:
                        runView.center = CGPointMake(s.width/2.0, s.height/2.0);
                        break;
                }
                break;
            case ORIENTATION_LANDSCAPERIGHT:
                switch((int)a.width)
                {
                    case 480:
                        t=CGAffineTransformTranslate(t, 164, -70);
                        break;
                    case 960:
                        t=CGAffineTransformTranslate(t, 180, 96);
                        break;
                    case 1024:
                    default:
                        runView.center = CGPointMake(s.width/2.0, s.height/2.0);
                        break;
                }
                break;
        }
    }
    else
    {
        runView.center = CGPointMake(s.width/2.0, s.height/2.0);
    }
	runView.transform = t;
}

@end
