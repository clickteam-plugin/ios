//
//  CRunViewController.m
//  RuntimeIPhone
//
//  Created by Francois Lionet on 02/04/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "CRunViewController.h"
#import "CRunApp.h"

@implementation CRunViewController

-(id)initWithApp:(CRunApp*)pApp
{
	runApp=pApp;
	
	if (self==[super init])
	{
	}
	return self;
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
-(void)loadView
{
	appRect = CGRectMake(0, 0, runApp->gaCxWin, runApp->gaCyWin);
	screenRect = runApp->screenRect;
	
	runView = [[CRunView alloc] initWithFrame:appRect];
	
	runView.contentMode = UIViewContentModeScaleAspectFill;
	runView.autoresizingMask = UIViewAutoresizingNone;	
	self.view = runView;
	[runView release];
}

-(void)didReceiveMemoryWarning 
{
    [super didReceiveMemoryWarning];
}

-(void)dealloc 
{
	[runView release];	
    [super dealloc];
}

@end
