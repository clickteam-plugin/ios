//----------------------------------------------------------------------------------
//
// CIADVIEWCONTROLLER
//
//----------------------------------------------------------------------------------
#import "CIAdViewController.h"
#import "CRunApp.h"
#import "CRunView.h"
#import "CRunViewController.h"
#import "CRun.h"
#import "MainView.h"

@implementation CIAdViewController

-(id)initWithApp:(CRunApp*)a andView:(MainView*)rView
{
	if (self=[super init])
	{
		app=a;
		mainView=rView;
		adView=[[ADBannerView alloc] initWithFrame:CGRectZero];
		adView.delegate=self;
		
		CGSize screen = [[UIScreen mainScreen] bounds].size;
		CGSize ad;
		
		switch(app->orientation)
		{
			case ORIENTATION_PORTRAIT:
				adView.currentContentSizeIdentifier=ADBannerContentSizeIdentifierPortrait;
				ad = adView.frame.size;
				adView.transform = CGAffineTransformMakeRotation(0);
				if (app->hdr2Options&AH2OPT_IADBOTTOM)
				{
					outPoint = CGPointMake(screen.width/2, screen.height+ad.height/2);
					inPoint = CGPointMake(screen.width/2, screen.height-ad.height/2);
				}
				else
				{
					outPoint = CGPointMake(screen.width/2, -ad.height/2);
					outPoint = CGPointMake(screen.width/2, ad.height/2);
				}
				break;
			case ORIENTATION_LANDSCAPERIGHT:
				adView.requiredContentSizeIdentifiers=[NSSet setWithObject:ADBannerContentSizeIdentifierLandscape];
				adView.currentContentSizeIdentifier=ADBannerContentSizeIdentifierLandscape;
				ad = adView.frame.size;
				adView.transform = CGAffineTransformMakeRotation(M_PI/2.0);
				if (app->hdr2Options&AH2OPT_IADBOTTOM)
				{
					outPoint = CGPointMake(-ad.height/2, screen.height/2);
					inPoint = CGPointMake(ad.height/2, screen.height/2);
				}
				else
				{
					outPoint = CGPointMake(screen.width+ad.height/2, screen.height/2);
					inPoint = CGPointMake(screen.width-ad.height/2, screen.height/2);
				}
				break;
				
			case ORIENTATION_LANDSCAPELEFT:
				adView.requiredContentSizeIdentifiers=[NSSet setWithObject:ADBannerContentSizeIdentifierLandscape];
				adView.currentContentSizeIdentifier=ADBannerContentSizeIdentifierLandscape;
				ad = adView.frame.size;
				adView.transform = CGAffineTransformMakeRotation(-M_PI/2.0);
				if (app->hdr2Options&AH2OPT_IADBOTTOM)
				{
					outPoint = CGPointMake(screen.width+ad.height/2, screen.height/2);
					inPoint = CGPointMake(screen.width-ad.height/2, screen.height/2);
				}
				else
				{
					outPoint = CGPointMake(-ad.height/2, screen.height/2);
					inPoint = CGPointMake(ad.height/2, screen.height/2);
				}
				break;
		}
		
		adView.center = outPoint;
		[rView addSubview:adView];
		bShown=NO;
		bAdAuthorised=YES; // francois:
	}
	return self;
}


-(void)bannerViewDidLoadAd:(ADBannerView*)banner
{
	bAdOK=YES;
	if (bShown==NO && bAdAuthorised==YES)
	{
		[UIView beginAnimations:@"animateAdBannerOff" context:NULL];
		adView.center = inPoint;
		[UIView commitAnimations];
		bShown=YES;
	}
}
-(void)bannerView:(ADBannerView*)banner didFailToReceiveAdWithError:(NSError*)error
{
	bAdOK=NO;
	if (bShown)
	{
		[UIView beginAnimations:@"animateAdBannerOff" context:NULL];
		adView.center = outPoint;
		[UIView commitAnimations];
		bShown=NO;
	}
}
-(void)setAdAuthorised:(BOOL)bAuthorised
{
	if (bAuthorised!=bAdAuthorised)
	{
		bAdAuthorised=bAuthorised;
		if (bAdAuthorised)
		{
			if (bShown==NO && bAdOK==YES)
			{			
				[self bannerViewDidLoadAd:nil];
			}
		}
		else
		{
			if (bShown)
			{
				BOOL oldBAdOK=bAdOK;
				[self bannerView:nil didFailToReceiveAdWithError:nil];
				bAdOK=oldBAdOK;
			}
		}
	}
}
-(BOOL)bannerViewActionShouldBegin:(ADBannerView*)banner willLeaveApplication:(BOOL)willLeave
{
	if (!willLeave)
	{
		if (app->run!=nil)
		{
			[app->run pause];
		}
		[app->runView pauseTimer];		
	}
	return YES;
}
-(void)bannerViewActionDidFinish:(ADBannerView *)banner
{
	if (app->run!=nil)
	{
		[app->run resume];
	}
	[app->runView resumeTimer];
}
@end
