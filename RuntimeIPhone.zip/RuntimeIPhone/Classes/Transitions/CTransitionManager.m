//----------------------------------------------------------------------------------
//
// CTRANSITIONMANAGER
//
//----------------------------------------------------------------------------------
#import "CTransitionManager.h"
#import "CRunApp.h"
#import "CBitmap.h"
#import "CTrans.h"
#import "CTransitions.h"
#import "CFile.h"
#import "CTransitionData.h"
#import "CObject.h"
#import "CRun.h"
#import "CObjectCommon.h"
#import "CRunApp.h"
#import "CImageBank.h"
#import "CImage.h"
#import "CRCom.h"
#import "CSprite.h"
#import "CRenderToTexture.h"

//F01
#import "CTransitionscctrans.h"
//F01END

@implementation CTransitionManager

-(id)initWithApp:(CRunApp*)a
{
	app = a;
	return self;
}

-(CTrans*)createTransition:(CTransitionData*)pData withRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)surfaceStart andEnd:(CRenderToTexture*)surfaceEnd andType:(int)type
{
	CTransitions* transitions=nil;

//F02
	if ([pData->dllName caseInsensitiveCompare:@"cctrans"]==0)
	{
		transitions = [[CTransitionscctrans alloc] init];
	}
//F02END
	
	if (transitions!=nil)
	{
		CTrans* trans = [transitions getTrans:pData];
		[app->file seek:pData->dataOffset];
		[trans setApp:app];
		[trans initialize:pData withFile:app->file andRenderer:renderer andStart:surfaceStart andEnd:surfaceEnd andType:type];
		[transitions release];
		return trans;
	}
	return nil;
}

-(CTrans*)startObjectFade:(CObject*)hoPtr withFlag:(BOOL)bFadeOut
{
	CRunApp* runApp = hoPtr->hoAdRunHeader->rhApp;
	CRenderer* renderer = runApp->renderer;
	
	CTransitionData* pData=hoPtr->hoCommon->ocFadeIn;
	if (bFadeOut)
	{
		pData=hoPtr->hoCommon->ocFadeOut;
	}
	
	CImage* img=nil;
	if ( (hoPtr->hoOEFlags & OEFLAG_ANIMATIONS) != 0 )
	{
		img=[runApp->imageBank getImageFromHandle:hoPtr->roc->rcImage];
		if ( hoPtr->roc->rcSprite != nil && (hoPtr->roc->rcAngle != 0 || hoPtr->roc->rcScaleX != 1.0 || hoPtr->roc->rcScaleY != 1.0)
			&& (hoPtr->roc->rcSprite->sprSf != nil || hoPtr->roc->rcSprite->sprTempSf != nil) )
		{
			if (hoPtr->roc->rcSprite->sprSf!=nil)
			{
				img=hoPtr->roc->rcSprite->sprSf;                    
			}
			else if(hoPtr->roc->rcSprite->sprTempSf != nil)
			{
				img=hoPtr->roc->rcSprite->sprTempSf;             
			}
			else
				return nil;
		}
	}

	int width=img->width;
	int height=img->height;
	
	CRenderToTexture* surface1 = [[CRenderToTexture alloc] initWithWidth:width andHeight:height andRunApp:runApp];
	CRenderToTexture* surface2 = [[CRenderToTexture alloc] initWithWidth:width andHeight:height andRunApp:runApp];
	
	
/*FRA
	else if (hoPtr.hoType>=32)
	{
		CExtension pExt=(CExtension)hoPtr;
		img=pExt.ext.getRunObjectSurface();
	}
 
	NOTE to Francois: If we need to support this for any
	object extension we just need to make it draw itself to
	position 0,0 when either surface1 or 2 have their framebuffer bound.
	No need to ask them for their image, if we just draw them we have their image.
*/
	
	//Prepare surfaces for the transition images
	if (bFadeOut)
	{
		[surface1 bindFrameBuffer];
		[renderer renderImage:(ITexture*)img withX:0 andY:0 andWidth:width andHeight:height andInkEffect:0 andInkEffectParam:0];
		[surface1 unbindFrameBuffer];
	}
	else
	{
		[surface2 bindFrameBuffer];
		[renderer renderImage:(ITexture*)img withX:0 andY:0 andWidth:width andHeight:height andInkEffect:0 andInkEffectParam:0];
		[surface2 unbindFrameBuffer];
	}

	// Charge la transition
	CTrans* pTrans=nil;
	pTrans=[self createTransition:pData withRenderer:runApp->renderer andStart:surface1 andEnd:surface2 andType:1];
	int trFlags=0;
	if ((hoPtr->hoFlags&HOF_FADEOUT)!=0)
		trFlags |= TRFLAG_FADEOUT;
	else
		trFlags |= TRFLAG_FADEIN;
	

	return pTrans;
}

@end
