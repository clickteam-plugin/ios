//----------------------------------------------------------------------------------
//
// CTransitionCTrans : point d'entree des transitions standart
//
//----------------------------------------------------------------------------------
#import "CTransitionscctrans.h"
#import "CTransitionData.h"
#import "CServices.h"
#import "CFile.h"
#import "CBitmap.h"
#import "CRunApp.h"
#import "CRun.h"
#import "CRenderer.h"
#import "CRenderToTexture.h"

char* identifiers[]=
{
	"BAND",
	"SE00",
	"SE10",
	"SE12",
	"DOOR",
	"SE03",
	"MOSA",
	"SE05",
	"SE06",
	"SCRL",
	"SE01",
	"SE07",
	"SE09",
	"SE13",	
	"SE08",
	"SE02",
	"ZIGZ",
	"SE04",
	"ZOOM",
	"SE11",
	"FADE",
	nil
};

@implementation CTransitionscctrans

-(CTrans*)getTrans:(CTransitionData*)data
{
	// Extrait l'identifier
	int id=data->transID;
	char idChars[5];
	idChars[0]=(char)(id&0xFF);
	id>>=8;
	idChars[1]=(char)(id&0xFF);
	id>>=8;
	idChars[2]=(char)(id&0xFF);
	id>>=8;
	idChars[3]=(char)(id&0xFF);
	idChars[4]=0;
	
	// Recherche dans la liste
	int n;
	for (n=0; identifiers[n]!=nil; n++)
	{
		if (strcmp(idChars, identifiers[n])==0)
		{
			break;
		}
	}
	
	// Cree la transition
	CTrans* trans=nil;
	switch (n)
	{
		case 0:
			trans=(CTrans*)[[CTransBand alloc] init];
			break;
		case 1:
			trans=(CTrans*)[[CTransAdvancedScrolling alloc] init];
			break;
		case 2:
			trans=(CTrans*)[[CTransBack alloc] init];
			break;
		case 3:
			trans=(CTrans*)[[CTransCell alloc] init];
			break;
		case 4:
			trans=(CTrans*)[[CTransDoor alloc] init];
			break;
		case 5:
			trans=(CTrans*)[[CTransLine alloc] init];
			break;
		case 6:
			trans=(CTrans*)[[CTransMosaic alloc] init];
			break;
		case 7:
			trans=(CTrans*)[[CTransOpen alloc] init];
			break;
		case 8:
			trans=(CTrans*)[[CTransPush alloc] init];
			break;
		case 9:
			trans=(CTrans*)[[CTransScroll alloc] init];
			break;
		case 10:
			trans=(CTrans*)[[CTransSquare alloc] init];
			break;
		case 11:
			trans=(CTrans*)[[CTransStretch alloc] init];
			break;
		case 12:
			trans=(CTrans*)[[CTransStretch2 alloc] init];
			break;
		case 13:
			trans=(CTrans*)[[CTransTrame alloc] init];
			break;
		case 14:
			trans=(CTrans*)[[CTransTurn alloc] init];
			break;
		case 15:
			trans=(CTrans*)[[CTransTurn2 alloc] init];
			break;
		case 16:
			trans=(CTrans*)[[CTransZigZag alloc] init];
			break;
		case 17:
			trans=(CTrans*)[[CTransZigZag2 alloc] init];
			break;
		case 18:
			trans=(CTrans*)[[CTransZoom alloc] init];
			break;
		case 19:
			trans=(CTrans*)[[CTransZoom2 alloc] init];
			break;
		case 20:
			trans=(CTrans*)[[CTransFade alloc] init];
			break;
	}
	return trans;
}
@end


// ADVANCED SCROLLING 
///////////////////////////////////////////////////////////////////////////////////////////

@implementation CTransAdvancedScrolling

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
		
		if ( dwStyle!=8 )
			m_style = dwStyle;
		else
		{
			m_style=[app->run random:10000];
			m_style=8*m_style/10000;
		}
	}
	
	int elapsedTime = [self getDeltaTime];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];
	}
	else
	{
		int w, h;
		[es2renderer renderBlitFull:source1];
		
		switch(m_style)
		{
			case 0:
				// Scrolling (To right, to left and to down)
				/////////////////////////////////////////////
				
				w = m_source2Width/3 * elapsedTime / m_duration;
				h = m_source2Height;
				
				[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:m_source2Width/3-w andYSrc:0 andWidth:w andHeight:h]; // Left Side
				[es2renderer renderBlit:source2 withXDst:m_source2Width-w andYDst:0 andXSrc:2*m_source2Width/3 andYSrc:0 andWidth:w andHeight:h]; // Right Side
				w = m_source2Width/3;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderBlit:source2 withXDst:w andYDst:0 andXSrc:w andYSrc:m_source2Height-h andWidth:w andHeight:h]; // Top side
				break;
			case 1:
				// Scrolling (To right, to left and to up)
				/////////////////////////////////////////////
				
				w = m_source2Width/3 * elapsedTime / m_duration;
				h = m_source2Height;
				[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:m_source2Width/3-w andYSrc:0 andWidth:w andHeight:h];					// Left Side
				[es2renderer renderBlit:source2 withXDst:m_source2Width-w andYDst:0 andXSrc:2*m_source2Width/3 andYSrc:0 andWidth:w andHeight:h];	// Right Side
				
				w = m_source2Width/3;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderBlit:source2 withXDst:w andYDst:m_source2Height-h andXSrc:w andYSrc:0 andWidth:w andHeight:h];					// Bottom side
				break;
			case 2:
				// To right, to left and to up
				////////////////////////////////
				
				w = m_source2Width/3 * elapsedTime / m_duration;
				h = m_source2Height;
				[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:m_source2Width/3-w andYSrc:0 andWidth:w andHeight:h];					// Left Side
				[es2renderer renderBlit:source2 withXDst:m_source2Width-w andYDst:0 andXSrc:2*m_source2Width/3 andYSrc:0 andWidth:w andHeight:h];	// Right Side
				
				w = m_source2Width/3;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderBlit:source2 withXDst:w andYDst:0 andXSrc:w andYSrc:0 andWidth:w andHeight:h];									// Top side
				break;
			case 3:
				// To right, to left and to down
				/////////////////////////////////
				
				w = m_source2Width/3 * elapsedTime / m_duration;
				h = m_source2Height;
				[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:m_source2Width/3-w andYSrc:0 andWidth:w andHeight:h];					// Left Side
				[es2renderer renderBlit:source2 withXDst:m_source2Width-w andYDst:0 andXSrc:2*m_source2Width/3 andYSrc:0 andWidth:w andHeight:h];	// Right Side
				
				w = m_source2Width/3;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderBlit:source2 withXDst:w andYDst:m_source2Height-h andXSrc:w andYSrc:m_source2Height-h andWidth:w andHeight:h];	// Bottom side
				break;
			case 4:
				// To right, to left, to down and to up
				////////////////////////////////////////
				
				w = m_source2Width/3 * elapsedTime / m_duration;
				h = m_source2Height;
				[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:m_source2Width/3-w andYSrc:0 andWidth:w andHeight:h];					// Left Side
				[es2renderer renderBlit:source2 withXDst:m_source2Width-w andYDst:0 andXSrc:2*m_source2Width/3 andYSrc:0 andWidth:w andHeight:h];	// Right Side
				
				w = m_source2Width/3;
				h = m_source2Height/2 * elapsedTime / m_duration;
				[es2renderer renderBlit:source2 withXDst:w andYDst:0 andXSrc:w andYSrc:m_source2Height/2-h andWidth:w andHeight:h];					// Top side
				[es2renderer renderBlit:source2 withXDst:w andYDst:m_source2Height-h andXSrc:w andYSrc:m_source2Height/2 andWidth:w andHeight:h];	// Bottom side
				break;
			case 5:
				// To right, to left, to down and to up
				////////////////////////////////////////
				
				w = m_source2Width/3 * elapsedTime / m_duration;
				h = m_source2Height;
				[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:m_source2Width/3-w andYSrc:0 andWidth:w andHeight:h];					// Left Side
				[es2renderer renderBlit:source2 withXDst:m_source2Width-w andYDst:0 andXSrc:2*m_source2Width/3 andYSrc:0 andWidth:w andHeight:h];	// Right Side
				
				w = m_source2Width/3;
				h = m_source2Height/2 * elapsedTime / m_duration;
				[es2renderer renderBlit:source2 withXDst:w andYDst:0 andXSrc:w andYSrc:0 andWidth:w andHeight:h];									// Top side
				[es2renderer renderBlit:source2 withXDst:w andYDst:m_source2Height-h andXSrc:w andYSrc:m_source2Height-h andWidth:w andHeight:h];	// Bottom side
				break;
			case 6:
				// Scrolling (3 bands)
				///////////////////////
				
				w = m_source2Width/3;
				h = m_source2Height * elapsedTime / m_duration;
				
				[es2renderer renderBlit:source2 withXDst:0 andYDst:m_source2Height-h andXSrc:0 andYSrc:0 andWidth:w andHeight:h];					// Band 1
				[es2renderer renderBlit:source2 withXDst:w andYDst:0 andXSrc:w andYSrc:m_source2Height-h andWidth:w andHeight:h];					// Band 2
				[es2renderer renderBlit:source2 withXDst:w*2 andYDst:m_source2Height-h andXSrc:w*2 andYSrc:0 andWidth:w andHeight:h];				// Band 3
				break;
			case 7:
				// Scrolling (7 bands)
				///////////////////////
				
				w = m_source2Width/7;
				h = m_source2Height * elapsedTime / m_duration;
				
				[es2renderer renderBlit:source2 withXDst:0 andYDst:m_source2Height-h andXSrc:0 andYSrc:0 andWidth:w andHeight:h];					// Band 1
				[es2renderer renderBlit:source2 withXDst:w andYDst:0 andXSrc:w andYSrc:m_source2Height-h andWidth:w andHeight:h];					// Band 2
				[es2renderer renderBlit:source2 withXDst:w*2 andYDst:m_source2Height-h andXSrc:w*2 andYSrc:0 andWidth:w andHeight:h];				// Band 3
				[es2renderer renderBlit:source2 withXDst:w*3 andYDst:0 andXSrc:w*3 andYSrc:m_source2Height-h andWidth:w andHeight:h];				// Band 4
				[es2renderer renderBlit:source2 withXDst:w*4 andYDst:m_source2Height-h andXSrc:w*4 andYSrc:0 andWidth:w andHeight:h];				// Band 5
				[es2renderer renderBlit:source2 withXDst:w*5 andYDst:0 andXSrc:w*5 andYSrc:m_source2Height-h andWidth:w andHeight:h];				// Band 6
				[es2renderer renderBlit:source2 withXDst:w*6 andYDst:m_source2Height-h andXSrc:w*6 andYSrc:0 andWidth:w*2 andHeight:h];				// Band 7
				break;
			default:
				[es2renderer renderBlitFull:source2];
				break;
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

//
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransBack

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
	}
	
	int halfWidth = m_source2Width/2;
	int halfHeight = m_source2Height/2;
	
	int elapsedTime = [self getDeltaTime];
	float progress = elapsedTime / (float)m_duration;
	float nProgress = 1.0f - progress;
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];
	}
	else
	{
		int w, h;
		[es2renderer renderBlitFull:source2];
		switch(dwStyle)
		{
			case 0:// OPEN
				w = halfWidth * nProgress;
				h = halfHeight * nProgress;
				[es2renderer renderStretch:source1 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc:0 andYSrc:0 andWSrc:halfWidth andHSrc:halfHeight];
				w = halfWidth * progress;
				h = halfHeight * nProgress;
				[es2renderer renderStretch:source1 withXDst:halfWidth+w andYDst:0 andWDst:halfWidth-w andHDst:h andXSrc:halfWidth andYSrc:0 andWSrc:halfWidth andHSrc:halfHeight];
				w = halfWidth * nProgress;
				h = halfHeight * progress;
				[es2renderer renderStretch:source1 withXDst:0 andYDst:halfHeight+h andWDst:w andHDst:halfHeight-h andXSrc:0 andYSrc:halfHeight andWSrc:halfWidth andHSrc:halfHeight];
				w = halfWidth * progress;
				h = halfHeight * progress;
				[es2renderer renderStretch:source1 withXDst:halfWidth+w andYDst:halfHeight+h andWDst:halfWidth-w andHDst:halfHeight-h andXSrc:halfWidth andYSrc:halfHeight andWSrc:halfWidth andHSrc:halfHeight];
				break;
			case 1:// SLIDE
				w = m_source2Width * nProgress;
				h = m_source2Height * nProgress;
				[es2renderer renderBlit:source1 withXDst:0 andYDst:0 andXSrc:m_source2Width-w andYSrc:m_source2Height-h andWidth:w andHeight:h];
				break;
			case 2:// SLIDE
				w = m_source2Width * progress;
				h = m_source2Height * nProgress;
				[es2renderer renderBlit:source1 withXDst:w andYDst:0 andXSrc:0 andYSrc:m_source2Height-h andWidth:m_source2Width-w andHeight:h];
				break;
			case 3:// SLIDE
				w = m_source2Width * nProgress;
				h = m_source2Height * progress;
				[es2renderer renderBlit:source1 withXDst:0 andYDst:h andXSrc:m_source2Width-w andYSrc:0 andWidth:w andHeight:m_source2Height-h];
				break;
			case 4:// SLIDE
				w = m_source2Width * progress;
				h = m_source2Height * progress;
				[es2renderer renderBlit:source1 withXDst:w andYDst:h andXSrc:0 andYSrc:0 andWidth:m_source2Width-w andHeight:m_source2Height-h];
				break;
			case 5:// OPEN (SCROLLING)
				w = halfWidth * nProgress;
				h = halfHeight * nProgress;
				[es2renderer renderBlit:source1 withXDst:w-halfWidth andYDst:h-halfHeight andXSrc:0 andYSrc:0 andWidth:halfWidth andHeight:halfHeight];				
				w = halfWidth * progress;
				h = halfHeight * nProgress;
				[es2renderer renderBlit:source1 withXDst:halfWidth+w andYDst:h-halfHeight andXSrc:halfWidth andYSrc:0 andWidth:halfWidth andHeight:halfHeight];
				w = halfWidth * nProgress;
				h = halfHeight * progress;
				[es2renderer renderBlit:source1 withXDst:w-halfWidth andYDst:halfHeight+h andXSrc:0 andYSrc:halfHeight andWidth:halfWidth andHeight:halfHeight];
				w = halfWidth * progress;
				h = halfHeight * progress;
				[es2renderer renderBlit:source1 withXDst:halfWidth+w andYDst:halfHeight+h andXSrc:halfWidth andYSrc:halfHeight andWidth:halfWidth andHeight:halfHeight];
				break;
			case 6: // SLIDE
				h = halfWidth * nProgress;
				[es2renderer renderBlit:source1 withXDst:0 andYDst:h-halfHeight andXSrc:0 andYSrc:0 andWidth:m_source2Width andHeight:halfHeight];
				[es2renderer renderBlit:source1 withXDst:0 andYDst:m_source2Height-h andXSrc:0 andYSrc:halfHeight andWidth:m_source2Width andHeight:halfHeight];
				break;
			case 7: // SLIDE
				w = halfWidth * nProgress;
				[es2renderer renderBlit:source1 withXDst:w-halfWidth andYDst:0 andXSrc:0 andYSrc:0 andWidth:halfWidth andHeight:m_source2Height];
				[es2renderer renderBlit:source1 withXDst:m_source2Width-w andYDst:0 andXSrc:halfWidth andYSrc:0 andWidth:halfWidth andHeight:m_source2Height];
				break;
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSBAND
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransBand

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	bpNbBands=[file readAShort];
	bpDirection=[file readAShort];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];
	
	tempBuffer = [[CRenderToTexture alloc] initWithWidth:s->width andHeight:s->height andRunApp:[CRunApp getRunApp]];
	[tempBuffer bindFrameBuffer];
	[es2renderer renderBlitFull:source1];
	[tempBuffer unbindFrameBuffer];
	
}
-(char*)stepDraw:(int)flag
{
	int sw = [source1 getWidth];
	int sh = [source1 getHeight];
	int n;
			
	// 1st time? create surface
	if ( m_starting )
	{
		// Security...
		if ( bpNbBands == 0 )
			bpNbBands = 1;
		
		switch (bpDirection) 
		{
			case LEFT_RIGHT:
			case RIGHT_LEFT:
				m_wbande = (sw + bpNbBands - 1)/ bpNbBands;
				if ( m_wbande == 0 )
				{
					m_wbande = 1;
					bpNbBands = (short)sw;
				}
				break;
			default:
				m_wbande = (sh + bpNbBands - 1) / bpNbBands;
				if ( m_wbande == 0 )
				{
					m_wbande = 1;
					bpNbBands = (short)sh;
				}
				break;
		}
		m_rw = 0;
		m_starting = NO;
	}

	[es2renderer useBlending:NO];
	[tempBuffer bindFrameBuffer];
	
	// Attention, passer la transparence en parametre...
	if ( bpNbBands <= 0 || m_wbande <= 0 || m_duration == 0 )
		[es2renderer renderBlitFull:source1];	// termine
	else
	{
		int rw = m_wbande * [self getDeltaTime] / m_duration;
		if ( rw > m_rw )
		{
			int x=0, y=0, w=0, h=0;
			for (n=0; n<(int)bpNbBands; n++)
			{
				switch (bpDirection) 
				{
					case LEFT_RIGHT:
						x = (int)m_rw + n * (int)m_wbande;
						y = 0;
						w = (int)rw - (int)m_rw;
						h = (int)sh;
						break;
					case RIGHT_LEFT:
						x = (int)sw - ((int)m_rw + n * (int)m_wbande) - ((int)rw-(int)m_rw);
						y = 0;
						w = (int)rw - (int)m_rw;
						h = (int)sh;
						break;
					case TOP_BOTTOM:
						x = 0;
						y = (int)m_rw + n * (int)m_wbande;
						w = (int)sw;
						h = (int)rw - (int)m_rw;
						break;
					case BOTTOM_TOP:
						x = 0;
						y = (int)sh - ((int)m_rw + n * (int)m_wbande) - ((int)rw-(int)m_rw);
						w = (int)sw;
						h = (int)rw - (int)m_rw;
						break;
				}
				[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight: h];
			}
		}
		m_rw = rw;
	}
	[tempBuffer unbindFrameBuffer];
	[es2renderer useBlending:YES];
	[es2renderer renderBlitFull:tempBuffer];

	return nil;
}
-(void)end
{
	[tempBuffer release];
	[self finish];
}

@end

// TRANSCELL
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransCell

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwPos=[file readAInt];
	dwPos2=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
	}
	
	int elapsedTime = [self getDeltaTime];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];					// completed
	}
	else
	{
		[es2renderer renderBlitFull:source1];
		int x, y, w, h, i, j, w2, h2;
		double width, height;
		
		width = (double)m_source2Width / (double)dwPos;
		height = (double)m_source2Height / (double)dwPos2;
		w = m_source2Width / dwPos;
		h = m_source2Height / dwPos2;
		
		for ( i=0 ; i<dwPos ; i++ )
		{
			for ( j=0 ; j<dwPos2 ; j++ )
			{
				x = (int)( (double)i * width );
				y = (int)( (double)j * height );
				
				w2 = w * elapsedTime / m_duration;
				h2 = h * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:x+(w-w2)/2 andYDst:y+(h-h2)/2 andWDst:w2 andHDst:h2 andXSrc:x+(w-w2)/2 andYSrc:y+(h-h2)/2 andWSrc:w2 andHSrc:h2];
			}
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSDOOR
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransDoor

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	m_direction=[file readAShort];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time? create surface
	if ( m_starting )
	{
		switch (m_direction) 
		{
			case CENTER_LEFTRIGHT:
			case LEFTRIGHT_CENTER:
				m_wbande = [source1 getWidth] / 2;
				break;
			default:
				m_wbande = [source1 getHeight] / 2;
				break;
		}
		m_rw = 0;
		m_starting = NO;
	}
	
	// Attention, passer la transparence en parametre...
	if ( m_wbande == 0 )
		[es2renderer renderBlitFull:source2];	// termine
	else
	{
		[es2renderer renderBlitFull:source1];
		int	x=0, y=0, w=0, h=0;
		int rw = m_wbande * [self getDeltaTime] / m_duration;
		if ( rw > m_rw )
		{
			// 1st band
			switch(m_direction) 
			{
				case CENTER_LEFTRIGHT:
					x = [source1 getWidth] / 2 - (int)rw;
					y = 0;
					w = (int)rw - (int)m_rw;
					h = [source2 getHeight];
					break;
				case LEFTRIGHT_CENTER:
					x = (int)m_rw;
					y = 0;
					w = (int)rw - (int)m_rw;
					h = [source2 getHeight];
					break;
				case CENTER_TOPBOTTOM:
					x = 0;
					y = [source1 getHeight] / 2 - (int)rw;
					w = [source2 getWidth];
					h = (int)rw - (int)m_rw;
					break;
				case TOPBOTTOM_CENTER:
					x = 0;
					y = (int)m_rw;
					w = [source2 getWidth];
					h = (int)rw - (int)m_rw;
					break;
			}
			[es2renderer renderBlit:source2 withXDst: x andYDst: y andXSrc: x andYSrc: y andWidth: w andHeight: h];
			
			// 2nd band
			switch(m_direction) 
			{
				case CENTER_LEFTRIGHT:
					x = [source1 getWidth] / 2 + (int)m_rw;
					break;
				case LEFTRIGHT_CENTER:
					x = [source1 getWidth] - (int)rw;
					break;
				case CENTER_TOPBOTTOM:
					y = [source1 getHeight] / 2 + (int)m_rw;
					break;
				case TOPBOTTOM_CENTER:
					y = [source1 getHeight] - (int)rw;
					break;
			}
			[es2renderer renderBlit:source2 withXDst: x andYDst: y andXSrc: x andYSrc: y andWidth: w andHeight: h];
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSFADE
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransFade

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time? create surface
	if ( m_starting )
	{
		m_starting = NO;
	}
	
	int fadeCoef;
	
	// Fade in
	if ( (flag & TRFLAG_FADEIN)!=0 )
	{
		fadeCoef = 255 - 255 * [self getDeltaTime] / m_duration;
		[es2renderer renderBlitFull:source1];
		[es2renderer renderFade:source2 withCoef:fadeCoef];

	}
	// Fade out
	else
	{
		fadeCoef = (255 * [self getDeltaTime] / m_duration);
		[es2renderer renderBlitFull:source2];
		[es2renderer renderFade:source1 withCoef:fadeCoef];
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSLINE
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransLine

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwPos=[file readAInt];
	dwStyle=[file readAInt];
	dwScrolling=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
	}
	
	int elapsedTime = [self getDeltaTime];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];      // completed
	}
	else
	{
		[es2renderer renderBlitFull:source1];
		int x, y, w, h;
		int i = 0;		// Loop
		int j = 0;		// Loop
		double linesize = 0;
		
		// Horizontal
		if ( dwStyle==0 )
		{
			linesize = (double)m_source2Height / (double)dwPos;
			for ( i=0 ; i<dwPos ; i++ )
			{
				if ( j==0 )
				{
					x = 0;
					y = (int)((double)i * linesize);
					w = m_source2Width * elapsedTime / m_duration;
					
					// Last
					if ( i==dwPos-1 )
						h = m_source2Height;
					else
						h = (int)(linesize+1.0);
					
					// Without scrolling or with scrolling
					if ( dwScrolling==0 )
						[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
					else
						[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:m_source2Width-w andYSrc:y andWidth:w andHeight:h];
					
					j = 1;
				}
				else
				{
					y = (int)((double)i * linesize);//h;
					w = m_source2Width * elapsedTime / m_duration;
					x = m_source2Width - w;
					
					// Last
					if ( i==dwPos-1 )
						h = m_source2Height;
					else
						h = (int)(linesize+1.0);
					
					// Without scrolling or with scrolling
					if ( dwScrolling==0 )
						[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
					else
						[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:0 andYSrc:y andWidth:w andHeight:h];
					
					j = 0;
				}
			}
		}
		// Vertical
		else
		{
			linesize = (double)m_source2Width / (double)dwPos;
			for ( i=0 ; i<dwPos ; i++ )
			{
				if ( j==0 )
				{
					x = (int)((double)i * linesize);
					y = 0;
					h = m_source2Height * elapsedTime / m_duration;
					
					// Last
					if ( i==dwPos-1 )
						w = m_source2Width;
					else
						w = (int)(linesize+1);
					
					// Without scrolling or with scrolling
					if ( dwScrolling==0 )
						[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
					else
						[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:m_source2Height-h andWidth:w andHeight:h];
					
					j = 1;
				}
				else
				{
					x = (int)((double)i * linesize);
					h = m_source2Height * elapsedTime / m_duration;
					y = m_source2Height - h;
					
					// Last
					if ( i==dwPos-1 )
						w = m_source2Width;
					else
						w = (int)(linesize+1);
					
					// Without scrolling or with scrolling
					if ( dwScrolling==0 )
						[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
					else
						[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:0 andWidth:w andHeight:h];
					j = 0;
				}
			}
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSMOSAIC
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransMosaic

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	m_spotPercent=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time? create surface
	if ( m_starting )
	{
		int sw = [source1 getWidth];
		int sh = [source1 getHeight];
		
		// Spot size: voir si ca rend bien
		m_spotSize = (int)((((int)sw * m_spotPercent / 100) + ((int)sh * m_spotPercent / 100)) / 2);
		if ( m_spotSize == 0 )
			m_spotSize = 1;
		
		// Calcul buffer bits
		int bufSize;
		m_nbBlockPerLine = ((sw + m_spotSize - 1) / m_spotSize);
		m_nbBlockPerCol = ((sh + m_spotSize - 1) / m_spotSize);
		m_nbBlocks = (int)m_nbBlockPerLine * (int)m_nbBlockPerCol;
		bufSize = (m_nbBlocks + 7) / 8 + 2;	// 2 = security
		m_lastNbBlocks = 0;
		m_bitbuf = (unsigned char*)calloc(bufSize, 1);
		m_starting = NO;
	}
	
	if ( m_bitbuf == nil || m_nbBlockPerLine < 2 || m_nbBlockPerCol < 2 || m_duration == 0 )
		[es2renderer renderBlitFull:source2];	// termine
	else
	{
		int NB_TRIES=1;
		int i;
		int l, xb=0, yb=0;
		int nbBlocks = (int)((double)m_nbBlocks * (double)[self getDeltaTime] / (double)m_duration);
		int nbCurrentBlocks = nbBlocks - m_lastNbBlocks;
		if ( nbCurrentBlocks != 0 )
		{
			[es2renderer useBlending:NO];
			m_lastNbBlocks = nbBlocks;
			for (l=0; l<nbCurrentBlocks; l++)
			{
				// Get random block coordinates
				for (i=0; i<NB_TRIES; i++)
				{
					xb = [app->run random:m_nbBlockPerLine];
					yb = [app->run random:m_nbBlockPerCol];
					
					int	nb, off;
					unsigned char mask;
					
					nb = yb * m_nbBlockPerLine + xb;
					off = nb/8;
					mask = (unsigned char)(1 << (nb&7));
					if ( (m_bitbuf[off] & mask) == 0 )
					{
						m_bitbuf[off] |= mask;
						break;
					}
					
					int pBuf=off; 
					int	nbb = (m_nbBlocks+7)/8;
					int	b;
					BOOL	r = NO;
					for (b=off; b<nbb; b++, pBuf++)
					{
						if ( m_bitbuf[pBuf] != 0xFF )
						{
							yb = (b*8) / m_nbBlockPerLine;
							xb = (b*8) % m_nbBlockPerLine;
							for (mask=1; mask!=0; mask<<=1)
							{
								if ( (m_bitbuf[pBuf] & mask) == 0 )
								{
									m_bitbuf[pBuf] |= mask;
									r = YES;
									break;
								}
								if ( ++xb >= m_nbBlockPerLine )
								{
									xb = 0;
									if ( ++yb >= m_nbBlockPerCol )
										break;
								}
							}
							if ( r )
								break;								
						}
					}
					if ( r )
						break;
					
					pBuf = 0;
					for (b=0; b<off; b++, pBuf++)
					{
						if ( m_bitbuf[pBuf] != 255 )
						{
							yb = (b*8) / m_nbBlockPerLine;
							xb = (b*8) % m_nbBlockPerLine;
							for (mask=1; mask!=0; mask<<=1)
							{
								if ( (m_bitbuf[pBuf] & mask) == 0 )
								{
									m_bitbuf[pBuf] |= mask;
									r = YES;
									break;
								}
								if ( ++xb >= m_nbBlockPerLine )
								{
									xb = 0;
									if ( ++yb >= m_nbBlockPerCol )
										break;
								}
							}
							if ( r )
								break;
						}
						if ( r )
							break;
						
						r = NO;
					}
				}
				if ( i < NB_TRIES )
				{
					[source1 bindFrameBuffer];
					[es2renderer renderBlit:source2 withXDst:(int)xb*(int)m_spotSize andYDst: (int)yb*(int)m_spotSize andXSrc:(int)xb*(int)m_spotSize andYSrc: (int)yb*(int)m_spotSize andWidth: (int)m_spotSize andHeight: (int)m_spotSize];
					[source1 unbindFrameBuffer];
				}
			}
		}
		[es2renderer useBlending:YES];
		[es2renderer renderBlitFull:source1];
	}
	return nil;
}
-(void)end
{
	free(m_bitbuf);
	[self finish];
}

@end

// TRANSOPEN
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransOpen

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];
	
	tempBuffer = [[CRenderToTexture alloc] initWithWidth:s->width andHeight:s->height andRunApp:[CRunApp getRunApp]];
	[tempBuffer bindFrameBuffer];
	[es2renderer renderBlitFull:source1];
	[tempBuffer unbindFrameBuffer];
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
	}
	
	int elapsedTime = [self getDeltaTime];
	double pourcentage = (double)(elapsedTime)/(double)(m_duration);
	
	[es2renderer useBlending:NO];
	[tempBuffer bindFrameBuffer];
	
	
	if ( pourcentage>1.0 )
	{
		[es2renderer renderBlitFull:source2];					// completed
	}
	else
	{
		int x, y, w, h;
		
		[source1 bindFrameBuffer];
		if ( pourcentage<0.3 )
		{
			w = m_source2Width*2 * elapsedTime / m_duration;
			w *= 2;
			h = m_source2Height / 7;
			x = m_source2Width/2 - w/2;
			y = m_source2Height/2 - h/2;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
			
			w = m_source2Width / 7;
			h = m_source2Height*2 * elapsedTime / m_duration;
			h *= 2;
			x = m_source2Width/2 - w/2;
			y = m_source2Height/2 - h/2;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
		}
		else
		{
			x = m_source2Width/2;
			w = m_source2Width * elapsedTime / m_duration - x;
			h = m_source2Height/2;
			y = 0;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
			
			y = m_source2Height/2;
			h = m_source2Height * elapsedTime / m_duration - y;
			w = m_source2Width/2;
			x = w;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
			
			w = m_source2Width * elapsedTime / m_duration - m_source2Width/2;
			x = m_source2Width/2 - w;
			h = m_source2Height/2;
			y = h;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
			
			h = m_source2Height * elapsedTime / m_duration - m_source2Height/2;
			y = m_source2Height/2 - h;
			w = m_source2Width/2;
			x = 0;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
		}
		[source1 unbindFrameBuffer];
		[es2renderer renderBlitFull:source1];
	}
	
	[tempBuffer unbindFrameBuffer];
	[es2renderer useBlending:YES];
	[es2renderer renderBlitFull:tempBuffer];
	return nil;
}
-(void)end
{
	[tempBuffer release];
	[self finish];
}

@end

// TRANSPUSH
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransPush

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
		m_refresh = NO;
	}
	
	int elapsedTime = [self getDeltaTime];
	
	double pourcentage = (double)(elapsedTime)/(double)(m_duration);
	if ( pourcentage>1.0 )
	{
		[es2renderer renderBlitFull:source2];
	}
	else
	{
		[es2renderer renderBlitFull:source1];
		int x, y, w, h;
		
		// First Scrolling
		if ( pourcentage<=0.5 )
		{
			switch(dwStyle)
			{
				case 0:
					w = m_source2Width * elapsedTime / m_duration * 2;
					h = m_source2Height/2;
					x = m_source2Width - w;
					y = m_source2Height/2;
					[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:x andYSrc:y andWidth:w andHeight:h];
					break;
				case 1:
					w = m_source2Width * elapsedTime / m_duration * 2;
					h = m_source2Height/2;
					x = m_source2Width - w;
					y = m_source2Height/2;
					[es2renderer renderBlit:source2 withXDst:x andYDst:0 andXSrc:0 andYSrc:y andWidth:w andHeight:h];
					break;
				case 2:
					w = m_source2Width * elapsedTime / m_duration * 2;
					h = m_source2Height/2;
					x = m_source2Width - w;
					y = m_source2Height/2;
					[es2renderer renderBlit:source2 withXDst:0 andYDst:y andXSrc:x andYSrc:0 andWidth:w andHeight:h];
					break;
				case 3:
					w = m_source2Width * elapsedTime / m_duration * 2;
					h = m_source2Height/2;
					x = m_source2Width - w;
					y = m_source2Height/2;
					[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:0 andYSrc:0 andWidth:w andHeight:h];
					break;
			}
		}
		
		// Second Scrolling
		if ( pourcentage>0.5 )
		{
			if ( m_refresh==NO )
			{
				if ( dwStyle<=1 )
					[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:0 andYSrc:m_source2Height/2 andWidth:m_source2Width andHeight:m_source2Height/2];
				else
					[es2renderer renderBlit:source2 withXDst:0 andYDst:m_source2Height/2 andXSrc:0 andYSrc:0 andWidth:m_source2Width andHeight:m_source2Height/2];
				m_refresh = YES;
			}
			
			pourcentage = (double)elapsedTime - (double)m_duration/2.0;
			pourcentage /= (double)m_duration / 2.0;
			pourcentage *= 1000;
			h = m_source2Height/2 * (int)pourcentage / 1000;
			
			switch(dwStyle)
			{
				case 0:
				case 1:
					[es2renderer renderStretch:source2 withXDst: 0 andYDst: h andWDst:m_source2Width andHDst: m_source2Height/2 andXSrc:0 andYSrc: m_source2Height/2 andWSrc: m_source2Width andHSrc: m_source2Height/2];
					[es2renderer renderStretch:source2 withXDst: 0 andYDst: 0 andWDst: m_source2Width andHDst: h andXSrc:0 andYSrc: m_source2Height/2-h andWSrc: m_source2Width andHSrc: h];
					break;
				case 2:
				case 3:
					[es2renderer renderStretch:source2 withXDst: 0 andYDst: m_source2Height/2-h andWDst:m_source2Width andHDst: m_source2Height/2 andXSrc:0 andYSrc: 0 andWSrc: m_source2Width andHSrc: m_source2Height/2];
					[es2renderer renderStretch:source2 withXDst: 0 andYDst: m_source2Height-h andWDst: m_source2Width andHDst: h andXSrc: 0 andYSrc: m_source2Height/2 andWSrc: m_source2Width andHSrc: h];
					break;
			}
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSSCROLL
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransScroll

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	m_direction=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	int sw = [source1 getWidth];
	int sh = [source1 getHeight];
	
	// 1st time? create surface
	if ( m_starting )
	{
		switch (m_direction) 
		{
			case LEFT_RIGHT:
			case RIGHT_LEFT:
				m_wbande = sw;
				break;
			default:
				m_wbande = sh;
				break;
		}
		m_rw = 0;
		m_starting = NO;
	}
	
	if ( m_duration == 0 )
		[es2renderer renderBlitFull:source2];  // termine
	else
	{
		[es2renderer renderBlitFull:source1];
		int rw = m_wbande * [self getDeltaTime] / m_duration;
		if ( rw > m_rw )
		{
			int x=0, y=0;
			
			switch (m_direction) 
			{
				case LEFT_RIGHT:
					x = (int)rw - sw;
					y = 0;
					break;
				case RIGHT_LEFT:
					x = sw - (int)rw;
					y = 0;
					break;
				case TOP_BOTTOM:
					x = 0;
					y = (int)rw - sh;
					break;
				case BOTTOM_TOP:
					x = 0;
					y = sh - (int)rw;
					break;
			}
			[es2renderer renderBlit:source2 withXDst: x andYDst: y andXSrc: 0 andYSrc: 0 andWidth: sw andHeight: sh];
			m_rw = rw;
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSSQUARE
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransSquare

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	dwPos=[file readAInt];
	dwStretch=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
	}
	
	int elapsedTime = [self getDeltaTime];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];													// completed
	}
	else
	{
		[es2renderer renderBlitFull:source1];
		int x, y, w, h;
		int width, height;
		
		// Inside Square
		/////////////////
		
		width = m_source2Width * dwPos / 100;
		height = m_source2Height * dwPos / 100;
		
		w = width * elapsedTime / m_duration;
		h = height * elapsedTime / m_duration;
		x = m_source2Width/2 - w/2;
		y = m_source2Height/2 - h/2;
		
		// No Stretch
		if ( dwStretch==0 )
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
		else
			[es2renderer renderStretch:source2 withXDst: x andYDst: y andWDst: w andHDst: h andXSrc: m_source2Width/2-width/2 andYSrc: m_source2Height/2-height/2 andWSrc: width andHSrc: height];
		
		// Outside Square
		//////////////////
		
		int pos = 100 - dwPos;
		width = m_source2Width * pos / 100;
		height = m_source2Height * pos / 100;
		
		w = width/2 * elapsedTime / m_duration;
		h = height/2 * elapsedTime / m_duration;
		[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:0 andYSrc:0 andWidth:m_source2Width andHeight:h];									// Up To Down
		[es2renderer renderBlit:source2 withXDst:0 andYDst:0 andXSrc:0 andYSrc:0 andWidth:w andHeight:m_source2Height];									// Left to Right
		[es2renderer renderBlit:source2 withXDst:0 andYDst:m_source2Height-h andXSrc:0 andYSrc:m_source2Height-h andWidth:m_source2Width andHeight:h];	// Down To Up
		[es2renderer renderBlit:source2 withXDst:m_source2Width-w andYDst:0 andXSrc:m_source2Width-w andYSrc:0 andWidth:w andHeight:m_source2Height];	// Right To Left
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSSTRETCH
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransStretch

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
	}
	
	int elapsedTime = [self getDeltaTime];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];					// completed
	}
	else
	{
		[es2renderer renderBlitFull:source1];
		int w, h;
		
		switch(dwStyle)
		{
                // Top Left
			case 0:
				w = m_source2Width * elapsedTime / m_duration;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst: 0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				break;
                // Top Right
			case 1:
				w = m_source2Width * elapsedTime / m_duration;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:m_source2Width-w andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				break;
                // Bottom Left
			case 2:
				w = m_source2Width * elapsedTime / m_duration;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:0 andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				break;
                // Bottom Right
			case 3:
				w = m_source2Width * elapsedTime / m_duration;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:m_source2Width-w andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				break;
                // 4 corners
			case 4:
				// Top Left
				w = m_source2Width/2 * elapsedTime / m_duration;
				h = m_source2Height/2 * elapsedTime / m_duration;
				if ( h<5 )
                    h = 5;
				[es2renderer renderStretch:source2 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc:0 andYSrc:0 andWSrc:[source1 getWidth]/2 andHSrc:[source1 getHeight]/2];
				// Top Right
				w = m_source2Width/2 * elapsedTime / m_duration;
				h = m_source2Height/2 * elapsedTime / m_duration;
				if ( h<5 )
					h = 5;
				[es2renderer renderStretch:source2 withXDst:m_source2Width-w andYDst:0 andWDst:w andHDst:h andXSrc:m_source2Width/2 andYSrc:0 andWSrc:m_source2Width/2 andHSrc:m_source2Height/2];
				// Bottom Left
				w = m_source2Width/2 * elapsedTime / m_duration;
				h = m_source2Height/2 * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:0 andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc:0 andYSrc:m_source2Height/2 andWSrc:m_source2Width/2 andHSrc:m_source2Height/2];
				// Bottom Right
				w = m_source2Width/2 * elapsedTime / m_duration;
				h = m_source2Height/2 * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:m_source2Width-w andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc:m_source2Width/2 andYSrc:m_source2Height/2 andWSrc:m_source2Width/2 andHSrc:m_source2Height/2];
				break;
                // Center
			case 5:
				// Top Left
				w = m_source2Width/2 * elapsedTime / m_duration;
				h = m_source2Height/2 * elapsedTime / m_duration;
				if ( h<5 )
					h = 5;
				[es2renderer renderStretch:source2 withXDst:m_source2Width/2-w andYDst:m_source2Height/2-h andWDst:w andHDst:h andXSrc:0 andYSrc:0 andWSrc:[source1 getWidth]/2 andHSrc:[source1 getHeight]/2];
				// Top Right
				w = m_source2Width/2 * elapsedTime / m_duration;
				h = m_source2Height/2 * elapsedTime / m_duration;
				if ( h<5 )
					h = 5;
				[es2renderer renderStretch:source2 withXDst:m_source2Width/2 andYDst:m_source2Height/2-h andWDst:w andHDst:h andXSrc:m_source2Width/2 andYSrc:0 andWSrc:m_source2Width/2 andHSrc:m_source2Height/2];
				// Bottom Left
				w = m_source2Width/2 * elapsedTime / m_duration;
				h = m_source2Height/2 * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:m_source2Width/2-w andYDst:m_source2Height/2 andWDst:w andHDst:h andXSrc:0 andYSrc:m_source2Height/2 andWSrc:m_source2Width/2 andHSrc:m_source2Height/2];
				// Bottom Right
				w = m_source2Width/2 * elapsedTime / m_duration;
				h = m_source2Height/2 * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:m_source2Width/2 andYDst:m_source2Height/2 andWDst:w andHDst:h andXSrc:m_source2Width/2 andYSrc:m_source2Height/2 andWSrc:m_source2Width/2 andHSrc:m_source2Height/2];
				break;
                // Top Middle
			case 6:
				w = m_source2Width;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				break;
                // Middle Left
			case 7:
				w = m_source2Width * elapsedTime / m_duration;
				h = m_source2Height;
				[es2renderer renderStretch:source2 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				break;
                // Middle Right
			case 8:
				w = m_source2Width * elapsedTime / m_duration;
				h = m_source2Height;
				[es2renderer renderStretch:source2 withXDst:m_source2Width-w andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				break;
                // Bottom Middle
			case 9:
				w = m_source2Width;
				h = m_source2Height * elapsedTime / m_duration;
				[es2renderer renderStretch:source2 withXDst:0 andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				break;
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSSTRECH2
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransStretch2

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
		m_phase = 0;
	}
	
	int elapsedTime = [self getDeltaTime];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];					// completed
	}
	else
	{
		int w, h;
		
		switch(dwStyle)
		{
                // Top Left
			case 0:
				if ( m_phase==0 )
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w = m_source2Width - w;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h = m_source2Height - h;
					
					[es2renderer renderStretch:source1 withXDst: 0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w -= m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h -= m_source2Height;
					[es2renderer renderStretch:source2 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Top Middle
			case 1:
				if ( m_phase==0 )
				{
					w = m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h = m_source2Height - h;
					
					[es2renderer renderStretch:source1 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h -= m_source2Height;
					[es2renderer renderStretch:source2 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Top Right
			case 2:
				if ( m_phase==0 )
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w = m_source2Width - w;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h = m_source2Height - h;
					
					[es2renderer renderStretch:source1 withXDst:m_source2Width-w andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w -= m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h -= m_source2Height;
					[es2renderer renderStretch:source2 withXDst:m_source2Width-w andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Middle Left
			case 3:
				if ( m_phase==0 )
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w = m_source2Width - w;
					h = m_source2Height;
					
					[es2renderer renderStretch:source1 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w -= m_source2Width;
					h = m_source2Height;
					[es2renderer renderStretch:source2 withXDst:0 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Center H
			case 4:
				if ( m_phase==0 )
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w = m_source2Width - w;
					h = m_source2Height;
					
					[es2renderer renderStretch:source1 withXDst:m_source2Width/2-w/2 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w -= m_source2Width;
					h = m_source2Height;
					[es2renderer renderStretch:source2 withXDst:m_source2Width/2-w/2 andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Center V
			case 5:
				if ( m_phase==0 )
				{
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h = m_source2Height - h;
					w = m_source2Width;
					
					[es2renderer renderStretch:source1 withXDst:0 andYDst:m_source2Height/2-h/2 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h -= m_source2Height;
					w = m_source2Width;
					[es2renderer renderStretch:source2 withXDst:0 andYDst:m_source2Height/2-h/2 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Center H+V
			case 6:
				if ( m_phase==0 )
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w = m_source2Width - w;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h = m_source2Height - h;
					
					[es2renderer renderStretch:source1 withXDst:m_source2Width/2-w/2 andYDst:m_source2Height/2-h/2 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w -= m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h -= m_source2Height;
					[es2renderer renderStretch:source2 withXDst:m_source2Width/2-w/2 andYDst:m_source2Height/2-h/2 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Middle Right
			case 7:
				if ( m_phase==0 )
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w = m_source2Width - w;
					h = m_source2Height;
					
					[es2renderer renderStretch:source1 withXDst:m_source2Width-w andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w -= m_source2Width;
					h = m_source2Height;
					[es2renderer renderStretch:source2 withXDst:m_source2Height-w andYDst:0 andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Bottom Left
			case 8:
				if ( m_phase==0 )
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w = m_source2Width - w;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h = m_source2Height - h;
					
					[es2renderer renderStretch:source1 withXDst:0 andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w -= m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h -= m_source2Height;
					[es2renderer renderStretch:source2 withXDst:0 andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Bottom Middle
			case 9:
				if ( m_phase==0 )
				{
					w = m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h = m_source2Height - h;
					
					[es2renderer renderStretch:source1 withXDst:0 andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h -= m_source2Height;
					[es2renderer renderStretch:source2 withXDst:0 andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
                // Bottom Right
			case 10:
				if ( m_phase==0 )
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w = m_source2Width - w;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h = m_source2Height - h;
					
					[es2renderer renderStretch:source1 withXDst:m_source2Width-w andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
					
					if ( elapsedTime>=m_duration/2 )
						m_phase = 1;
				}
				else
				{
					w = 2 * m_source2Width * elapsedTime / m_duration;
					w -= m_source2Width;
					h = 2 * m_source2Height * elapsedTime / m_duration;
					h -= m_source2Height;
					[es2renderer renderStretch:source2 withXDst:m_source2Width-w andYDst:m_source2Height-h andWDst:w andHDst:h andXSrc: 0 andYSrc:0 andWSrc:m_source2Width andHSrc: m_source2Height];
				}
				break;
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSTRAME
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransTrame

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];    
    
	tempBuffer = [[CRenderToTexture alloc] initWithWidth:s->width andHeight:s->height andRunApp:[CRunApp getRunApp]];
	[tempBuffer bindFrameBuffer];
	[es2renderer renderBlitFull:source1];
	[tempBuffer unbindFrameBuffer];
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
		m_index = 0;
		m_index2 = 0;
	}
	
	int elapsedTime = [self getDeltaTime];
	
	[es2renderer useBlending:NO];
	[tempBuffer bindFrameBuffer];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];					// completed
	}
	else
	{
		[source1 bindFrameBuffer];
		int w, h, i, j, k;
		
		h = m_source2Height * elapsedTime / m_duration;
		w = m_source2Width * elapsedTime / m_duration;
		
		if ( dwStyle==0 )
		{
			k = h % 2;
			for ( i=0 ; i<m_source2Width ; i+=2 )
			{
				for ( j=m_index ; j<h ; j++ )
				{
					[es2renderer renderBlit:source2 withXDst:i andYDst:j andXSrc:i andYSrc:j andWidth:1 andHeight:1];
				}
				for ( j=m_source2Height-h-k ; j<m_source2Height-m_index ; j++ )
				{
					[es2renderer renderBlit:source2 withXDst:i+1 andYDst:j+1 andXSrc:i+1 andYSrc:j+1 andWidth:1 andHeight:1];
				}
			}
			if (h%2==0)
				m_index=h;
			else
				m_index=h-1;
		}
		
		if ( dwStyle==1 )
		{
			k = w % 2;
			for ( j=0 ; j<m_source2Height ; j++ )
			{
				for ( i=m_index2 ; i<w ; i+=2 )
				{
					[es2renderer renderBlit:source2 withXDst:i+1 andYDst:j andXSrc:i+1 andYSrc:j andWidth:1 andHeight:1];
				}
				for ( i=m_source2Width-w-k ; i<m_source2Width-m_index2 ; i+=2 )
				{
					[es2renderer renderBlit:source2 withXDst:i andYDst:j+1 andXSrc:i andYSrc:j+1 andWidth:1 andHeight:1];
				}
			}
			if (w%2==0)
				m_index2=w;
			else
				m_index2=w-1;
		}
		
		if ( dwStyle==2 )
		{
			k = h % 2;
			for ( i=0 ; i<m_source2Width ; i+=2 )
			{
				for ( j=m_index ; j<h ; j+=2 )
				{
					[es2renderer renderBlit:source2 withXDst:i andYDst:j andXSrc:i andYSrc:j andWidth:1 andHeight:1];
				}
				for ( j=m_source2Height-h-k ; j<m_source2Height-m_index ; j+=2 )
				{
					[es2renderer renderBlit:source2 withXDst:i+1 andYDst:j+1 andXSrc:i+1 andYSrc:j+1 andWidth:1 andHeight:1];
				}
			}
			
			k = w % 2;
			for ( j=0 ; j<m_source2Height ; j+=2 )
			{
				for ( i=m_index2 ; i<w ; i+=2 )
				{
					[es2renderer renderBlit:source2 withXDst:i+1 andYDst:j andXSrc:i+1 andYSrc:j andWidth:1 andHeight:1];
				}
				for ( i=m_source2Width-w-k ; i<m_source2Width-m_index2 ; i+=2 )
				{
					[es2renderer renderBlit:source2 withXDst:i andYDst:j+1 andXSrc:i andYSrc:j+1 andWidth:1 andHeight:1];
				}
			}
			if (h%2==0)
				m_index=h;
			else
				m_index=h-1;
			if (w%2==0)
				m_index2=w;
			else
				m_index2=w-1;
		}
		[source1 unbindFrameBuffer];
	}
	[es2renderer renderBlitFull:source1];
	[tempBuffer unbindFrameBuffer];
	[es2renderer useBlending:YES];
	[es2renderer renderBlitFull:tempBuffer];
	return nil;
}
-(void)end
{
	[tempBuffer release];
	[self finish];
}

@end

// TRANSTURN
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransTurn

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwPos=[file readAInt];
	dwCheck1=[file readAInt];
	dwCheck2=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];
	
	tempBuffer = [[CRenderToTexture alloc] initWithWidth:s->width andHeight:s->height andRunApp:[CRunApp getRunApp]];
	[tempBuffer bindFrameBuffer];
	[es2renderer renderBlitFull:source1];
	[tempBuffer unbindFrameBuffer];
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
		m_angle = 0.0;
	}
	
	int elapsedTime = [self getDeltaTime];
	
	[es2renderer useBlending:NO];
	[tempBuffer bindFrameBuffer];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];			// completed
	}
	else
	{
		int x, y, w, h;
		int dist, xcenter, ycenter;
		
		xcenter = m_source2Width/2;
		ycenter = m_source2Height/2;
		
		m_angle = dwPos * 6.28318 * (double)elapsedTime / ((double)m_duration);
		
		// Inverse ?
		if ( dwCheck2==1 )
		{
			m_angle = 6.28318 - m_angle;
		}
		
		dist = m_source2Width/2 - m_source2Width/2 * elapsedTime / m_duration;
		x = (int)( (double)xcenter + cos(m_angle) * (double)dist );
		y = (int)( (double)ycenter + sin(m_angle) * (double)dist );
		
		w = m_source2Width * elapsedTime / m_duration;
		h = m_source2Height * elapsedTime / m_duration;
		
		[es2renderer renderStretch:source1 withXDst: 0 andYDst: 0 andWDst: m_source2Width andHDst: m_source2Height andXSrc: 0 andYSrc: 0 andWSrc: [source1 getWidth] andHSrc: [source1 getHeight]];
		
		// Full Image ?
		if ( dwCheck1==1 )
			[es2renderer renderStretch:source2 withXDst: x-w/2 andYDst: y-h/2 andWDst: w andHDst: h andXSrc: 0 andYSrc: 0 andWSrc: m_source2Width andHSrc: m_source2Height];
		else
			[es2renderer renderStretch:source2 withXDst: x-w/2 andYDst: y-h/2 andWDst: w andHDst: h andXSrc: m_source2Width-w andYSrc: m_source2Height-h andWSrc: w andHSrc: h];
	}
	
	[tempBuffer unbindFrameBuffer];
	[es2renderer useBlending:YES];
	[es2renderer renderBlitFull:tempBuffer];
	return nil;
}
-(void)end
{
	[tempBuffer release];
	[self finish];
}

@end

// TRANSTURN2
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransTurn2

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwPos=[file readAInt];
	dwCheck1=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];
	
	tempBuffer = [[CRenderToTexture alloc] initWithWidth:s->width andHeight:s->height andRunApp:[CRunApp getRunApp]];
	[tempBuffer bindFrameBuffer];
	[es2renderer renderBlitFull:source1];
	[tempBuffer unbindFrameBuffer];
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
		m_curcircle = 0;
	}
	
	int elapsedTime = [self getDeltaTime];
	
	[es2renderer useBlending:NO];
	[tempBuffer bindFrameBuffer];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];				// completed
	}
	else
	{
		int x, y, xcenter, ycenter, dist;
		double angle = 0.0;
		
		xcenter = m_source2Width/2;
		ycenter = m_source2Height/2;
		
		angle = dwPos * 6.28318 * (double)elapsedTime / (double)m_duration;
		angle -= m_curcircle * 6.28318;
		if ( dwCheck1==1 )
			angle = 6.28318 - angle;
		
		dist = m_source2Width * elapsedTime / m_duration;
		x = (int)( (double)xcenter + cos(angle) * (double)dist );
		y = (int)( (double)ycenter + sin(angle) * (double)dist );
		
		[es2renderer renderBlitFull:source2];
		[es2renderer renderBlit:source1 withXDst:x-m_source2Width/2 andYDst:y-m_source2Height/2 andXSrc:0 andYSrc:0 andWidth:m_source2Width andHeight:m_source2Height];
		
		if ( dwCheck1==0 )
		{
			if ( angle>=6.28318 )
				m_curcircle++;
		}
		else
		{
			if ( angle<=0 )
				m_curcircle++;
		}
	}
	
	[tempBuffer unbindFrameBuffer];
	[es2renderer useBlending:YES];
	[es2renderer renderBlitFull:tempBuffer];
	
	return nil;
}
-(void)end
{
	[tempBuffer release];
	[self finish];
}

@end

// TRANSZIGZAG
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransZigZag

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	zpSpotPercent=[file readAInt];
	zpStartPoint=[file readAShort];
	zpDirection=[file readAShort];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];
	
	tempBuffer = [[CRenderToTexture alloc] initWithWidth:s->width andHeight:s->height andRunApp:[CRunApp getRunApp]];
	[tempBuffer bindFrameBuffer];
	[es2renderer renderBlitFull:source1];
	[tempBuffer unbindFrameBuffer];
}
-(char*)stepDraw:(int)flag
{
	int sw = [source1 getWidth];
	int sh = [source1 getHeight];
	
	[es2renderer useBlending:NO];
	[tempBuffer bindFrameBuffer];
	
	// 1st time? create surface
	if ( m_starting )
	{
		// Spot size: voir si ca rend bien
		m_spotSize = (int)((((int)sw * zpSpotPercent / 100) + ((int)sh * zpSpotPercent / 100)) / 2);
		if ( m_spotSize == 0 )
			m_spotSize = 1;
		
		m_nbBlockPerLine = ((sw + m_spotSize - 1) / m_spotSize);
		m_nbBlockPerCol = ((sh + m_spotSize - 1) / m_spotSize);
		
		// Start point
		m_currentDirection = zpDirection;
		m_currentStartPoint = zpStartPoint;
		
		switch(zpStartPoint) 
		{
			case TOP_LEFT:
				m_curx = m_cury = 0;
				break;
			case TOP_RIGHT:
				m_curx = sw - m_spotSize;
				m_cury = 0;
				break;
			case BOTTOM_LEFT:
				m_curx = 0;
				m_cury = sh - m_spotSize;
				break;
			case BOTTOM_RIGHT:
				m_curx = sw - m_spotSize;
				m_cury = sh - m_spotSize;
				break;
			case CENTER:
				m_curx = sw/2 - m_spotSize;
				m_cury = sh/2 - m_spotSize;
				if ( m_currentDirection == DIR_HORZ )
					m_currentStartPoint = TOP_LEFT;
				else
					m_currentStartPoint = TOP_RIGHT;
				m_left = m_curx - m_spotSize;
				m_top = m_cury - m_spotSize;
				m_bottom = m_cury + m_spotSize*2;
				m_right = m_curx + m_spotSize*2;
				
				m_nbBlockPerLine = 2 + 2 * (m_curx + m_spotSize - 1)/m_spotSize;
				m_nbBlockPerCol = 2 + 2 * (m_cury + m_spotSize - 1)/m_spotSize;
				break;
		}
		m_nbBlocks = (int)m_nbBlockPerLine * (int)m_nbBlockPerCol;
		m_lastNbBlocks = 0;
		m_starting = NO;
	}
	
	if ( m_spotSize >= (int)sw || m_spotSize >= (int)sh )
		[es2renderer renderBlitFull:source2];	// termine
	else
	{
		// Compute number of spots to display in 1 step
		int l;
		int nbBlocks = (int)((double)m_nbBlocks * (double)[self getDeltaTime] / (double)m_duration);
		int nbCurrentBlocks = nbBlocks - m_lastNbBlocks;
		if ( nbCurrentBlocks != 0 )
		{
			m_lastNbBlocks = nbBlocks;
			for (l=0; l<nbCurrentBlocks; l++)
			{
				// Blit current spot
				[source1 bindFrameBuffer];
				[es2renderer renderBlit:source2 withXDst: m_curx andYDst: m_cury andXSrc: m_curx andYSrc: m_cury andWidth: m_spotSize andHeight: m_spotSize];
				[source1 unbindFrameBuffer];
				
				// Increment spot coordinates
				if ( zpStartPoint == CENTER )
				{
					switch(m_currentStartPoint) 
					{
						case TOP_LEFT:
							m_curx += m_spotSize;
							if ( m_curx >= (int)m_right )
							{
								m_curx -= m_spotSize;
								m_cury += m_spotSize;
								m_currentStartPoint = TOP_RIGHT;
								m_right += m_spotSize;
							}
							break;
						case TOP_RIGHT:
							m_cury += m_spotSize;
							if ( m_cury >= (int)m_bottom )
							{
								m_cury -= m_spotSize;
								m_curx -= m_spotSize;
								m_currentStartPoint = BOTTOM_RIGHT;
								m_bottom += m_spotSize;
							}
							break;
						case BOTTOM_RIGHT:
							m_curx -= m_spotSize;
							if ( (int)(m_curx+m_spotSize) <= m_left )
							{
								m_curx += m_spotSize;
								m_cury -= m_spotSize;
								m_currentStartPoint = BOTTOM_LEFT;
								m_left -= m_spotSize;
							}
							break;
						case BOTTOM_LEFT:
							m_cury -= m_spotSize;
							if ( (int)(m_cury + m_spotSize) <= m_top )
							{
								m_cury += m_spotSize;
								m_curx += m_spotSize;
								m_currentStartPoint = TOP_LEFT;
								m_top -= m_spotSize;
							}
							break;
					}
				}
				else 
				{
					switch (m_currentDirection) 
					{
                            // Horizontal
						case DIR_HORZ:
							switch(m_currentStartPoint) 
						{
							case TOP_LEFT:
								m_curx += m_spotSize;
								if ( m_curx >= (int)sw )
								{
									m_curx -= m_spotSize;
									m_cury += m_spotSize;
									m_currentStartPoint = TOP_RIGHT;
								}
								break;
							case TOP_RIGHT:
								m_curx -= m_spotSize;
								if ( (int)(m_curx+m_spotSize) <= 0 )
								{
									m_curx += m_spotSize;
									m_cury += m_spotSize;
									m_currentStartPoint = TOP_LEFT;
								}
								break;
							case BOTTOM_LEFT:
								m_curx += m_spotSize;
								if ( m_curx >= (int)sw )
								{
									m_curx -= m_spotSize;
									m_cury -= m_spotSize;
									m_currentStartPoint = BOTTOM_RIGHT;
								}
								break;
							case BOTTOM_RIGHT:
								m_curx -= m_spotSize;
								if ( (int)(m_curx+m_spotSize) <= 0 )
								{
									m_curx += m_spotSize;
									m_cury -= m_spotSize;
									m_currentStartPoint = BOTTOM_LEFT;
								}
								break;
						}
							break;
							
                            // Vertical
						case DIR_VERT:
							switch(m_currentStartPoint) 
						{
							case TOP_LEFT:
								m_cury += m_spotSize;
								if ( m_cury >= (int)sh )
								{
									m_cury -= m_spotSize;
									m_curx += m_spotSize;
									m_currentStartPoint = BOTTOM_LEFT;
								}
								break;
							case TOP_RIGHT:
								m_cury += m_spotSize;
								if ( m_cury >= (int)sh )
								{
									m_cury -= m_spotSize;
									m_curx -= m_spotSize;
									m_currentStartPoint = BOTTOM_RIGHT;
								}
								break;
							case BOTTOM_LEFT:
								m_cury -= m_spotSize;
								if ( (int)(m_cury + m_spotSize) <= 0 )
								{
									m_cury += m_spotSize;
									m_curx += m_spotSize;
									m_currentStartPoint = TOP_LEFT;
								}
								break;
							case BOTTOM_RIGHT:
								m_cury -= m_spotSize;
								if ( (int)(m_cury + m_spotSize) <= 0 )
								{
									m_cury += m_spotSize;
									m_curx -= m_spotSize;
									m_currentStartPoint = TOP_RIGHT;
								}
								break;
						}
							break;
					}
				}
			}
		}
		[es2renderer renderBlitFull:source1];
	}
	
	[tempBuffer unbindFrameBuffer];
	[es2renderer useBlending:YES];
	[es2renderer renderBlitFull:tempBuffer];
	
	return nil;
}
-(void)end
{
	[tempBuffer release];
	[self finish];
}

@end

// TRANSZIGZAG2
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransZigZag2

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwStyle=[file readAInt];
	dwPos=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];
	
	tempBuffer = [[CRenderToTexture alloc] initWithWidth:s->width andHeight:s->height andRunApp:[CRunApp getRunApp]];
	[tempBuffer bindFrameBuffer];
	[es2renderer renderBlitFull:source1];
	[tempBuffer unbindFrameBuffer];
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
		m_linepos = 0;
		m_dir = 0;
	}
	
	int elapsedTime = [self getDeltaTime];
	
	[es2renderer useBlending:NO];
	[tempBuffer bindFrameBuffer];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];					// completed
	}
	else
	{
		int x, y, w, h;
		double nb = 0.0;
		
		[source1 bindFrameBuffer];
		if ( dwStyle==0 )
		{
			nb = (double)m_source2Height / (double)dwPos;
			
			// TOP
			h = (int)( (double)m_linepos * nb) + (int)nb;
			y = 0;
			w = m_source2Width * elapsedTime / m_duration;
			w = w * dwPos / 2;
			w -= m_source2Width * m_linepos;
			if ( m_dir==0 )
				x = 0;
			else
				x = m_source2Width - w;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
			
			// BOTTOM
			y = m_source2Height - h;
			if ( m_dir==1 )
				x = 0;
			else
				x = m_source2Width - w;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
			
			// End of line
			if ( w>=m_source2Width )
			{
				m_linepos++;
				m_dir++;
				if ( m_dir==2 )
					m_dir = 0;
			}
		}
		else
		{
			nb = (double)m_source2Width / (double)dwPos;
			
			// LEFT
			w = (int)( (double)m_linepos * nb) + (int)nb;
			x = 0;
			h = m_source2Height * elapsedTime / m_duration;
			h = h * dwPos / 2;
			h -= m_source2Height * m_linepos;
			if ( m_dir==0 )
				y = 0;
			else
				y = m_source2Height - h;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
			
			// RIGHT
			x = m_source2Width - w;
			if ( m_dir==1 )
				y = 0;
			else
				y = m_source2Height - h;
			[es2renderer renderBlit:source2 withXDst:x andYDst:y andXSrc:x andYSrc:y andWidth:w andHeight:h];
			
			// End of line
			if ( h>=m_source2Height )
			{
				m_linepos++;
				m_dir++;
				if ( m_dir==2 )
					m_dir = 0;
			}
		}
		[source1 unbindFrameBuffer];
		[es2renderer renderBlitFull:source1];
	}
	
	[tempBuffer unbindFrameBuffer];
	[es2renderer useBlending:YES];
	[es2renderer renderBlitFull:tempBuffer];
	
	return nil;
}
-(void)end
{
	[tempBuffer release];
	[self finish];
}

@end

// TRANSZOOM
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransZoom

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	int sw = [source1 getWidth];
	int sh = [source1 getHeight];
	
	// 1st time? 
	if ( m_starting )
	{
		// Reset m_starting
		m_starting = NO;
	}
	
	// Securites
	if ( m_duration == 0 )	// || etc... )
		[es2renderer renderBlitFull:source2];
	else
	{
		int	nw, nh;
		int deltaTime = [self getDeltaTime];
		
		// Fade out
		if ( (flag & TRFLAG_FADEOUT)!=0 )
		{
			nw = (int)(sw - sw * deltaTime / m_duration);
			nh = (int)(sh - sh * deltaTime / m_duration);
			
			// Fill background
			[es2renderer renderBlitFull:source2];
			
			// Stretch new image
			[es2renderer renderStretch:source1 withXDst: (sw-nw)/2 andYDst: (sh-nh)/2 andWDst: nw andHDst: nh andXSrc: 0 andYSrc: 0 andWSrc: sw andHSrc: sh];
		}
		
		// Fade in
		else
		{
			nw = (int)(sw * deltaTime / m_duration);
			nh = (int)(sh * deltaTime / m_duration);
			
			// Fill background
			[es2renderer renderBlitFull:source1];
			
			// Stretch new image
			[es2renderer renderStretch:source2 withXDst: (sw-nw)/2 andYDst: (sh-nh)/2 andWDst: nw andHDst: nh andXSrc:0 andYSrc: 0 andWSrc: sw andHSrc: sh];
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end

// TRANSZOOM2
//////////////////////////////////////////////////////////////////////////////////////////
@implementation CTransZoom2

-(void)initialize:(CTransitionData*)data withFile:(CFile*)file andRenderer:(CRenderer*)renderer andStart:(CRenderToTexture*)s andEnd:(CRenderToTexture*)d andType:(int)type
{
	dwPos=[file readAInt];
	[self start:data withRenderer:renderer andStart:s andEnd:d andType:type];        
}
-(char*)stepDraw:(int)flag
{
	// 1st time?
	if ( m_starting )
	{
		m_starting = NO;
		m_source2Width = [source2 getWidth];
		m_source2Height = [source2 getHeight];
	}
	
	int elapsedTime = [self getDeltaTime];
	
	if ( ((double)(elapsedTime)/(double)(m_duration))>1.0 )
	{
		[es2renderer renderBlitFull:source2];		// completed
	}
	else
	{
		int x, y, w, h;
		
		if ( dwPos==0 )
		{
			w = m_source2Width * elapsedTime / m_duration;
			h = m_source2Height * elapsedTime / m_duration;
			x = m_source2Width/2 - w/2;
			y = m_source2Height/2 - h/2;
			
			[es2renderer renderStretch:source2 withXDst:0 andYDst:0 andWDst:m_source2Width andHDst:m_source2Height andXSrc:x andYSrc:y andWSrc:w andHSrc:h];
		}
		else
		{
			w = m_source2Width * elapsedTime / m_duration;
			w = m_source2Width - w;
			h = m_source2Height * elapsedTime / m_duration;
			h = m_source2Height - h;
			x = m_source2Width/2 - w/2;
			y = m_source2Height/2 - h/2;
			
			[es2renderer renderStretch:source1 withXDst:0 andYDst:0 andWDst:m_source2Width andHDst:m_source2Height andXSrc:x andYSrc:y andWSrc:w andHSrc:h];
		}
	}
	return nil;
}
-(void)end
{
	[self finish];
}

@end
