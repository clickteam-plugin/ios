//----------------------------------------------------------------------------------
//
// CTRANSITIONS : interface avec la dll
//
//----------------------------------------------------------------------------------
#import "CTransitions.h"
#import "CTrans.h"
#import "CTransitionData.h"

@implementation CTransitions

-(CTrans*)getTrans:(CTransitionData*)data
{
	return nil;
}

@end
