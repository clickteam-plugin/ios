//
//  ES1Renderer.m
//  RuntimeIPhone
//
//  Created by Anders Riggelsen on 1/14/11.
//  Copyright 2011 Clickteam. All rights reserved.
//

#import "CRenderer.h"
#import "ES1Renderer.h"
#import "ITexture.h"
#import "CRenderToTexture.h"
#import "Maths.h"
#import "CServices.h"
#import "CRunView.h"

@implementation ES1Renderer


- (id)initWithView:(CRunView*)runView
{
    if ((self = [super initWithView:runView]))
    {
        context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
        if (!context || ![EAGLContext setCurrentContext:context])
        {
            [self release];
            return nil;
        }

		openGLversion = ES1;
		
        // Create default framebuffer object. The backing will be allocated for the current layer in -resizeFromLayer
        glGenFramebuffersOES(1, &defaultFramebuffer);
        glGenRenderbuffersOES(1, &colorRenderbuffer);
        glBindFramebufferOES(GL_FRAMEBUFFER_OES, defaultFramebuffer);
        glBindRenderbufferOES(GL_RENDERBUFFER_OES, colorRenderbuffer);
        glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, colorRenderbuffer);
		
		glEnable(GL_BLEND);
		glEnable(GL_TEXTURE_2D);
			
		useClipping = NO;
		clipLeft = clipTop = clipRight = clipBottom = 0;
		
		usedTextures = [[NSMutableSet alloc] init];
		
		unsigned char colors [16] = {255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255};
		memcpy(cColor,colors,16*sizeof(unsigned char));
		[self setColors:colors];
		
		GLfloat texCoords [8] = {0,0,1,0,0,1,1,1};
		[self setTexCoords:texCoords];
		
		//Enable vertex attributes
		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		
		glActiveTexture(GL_TEXTURE0);
	}
	
    return self;
}

-(void)dealloc
{
	[self destroyFrameBuffers];
	[super dealloc];
}

-(void)destroyFrameBuffers
{
    if (defaultFramebuffer)
    {
        glDeleteFramebuffersOES(1, &defaultFramebuffer);
        defaultFramebuffer = 0;
    }
    if (colorRenderbuffer)
    {
        glDeleteRenderbuffersOES(1, &colorRenderbuffer);
        colorRenderbuffer = 0;
    }
}

- (void)setTexture:(ITexture*)texture
{
	int texId = [texture getTextureID];
	if(currentTextureID != texId)
	{
		glBindTexture(GL_TEXTURE_2D, texId);
		currentTextureID = texId;
	}
}

- (void)setVertices:(GLfloat*)vertices
{
	glVertexPointer(2, GL_FLOAT, 0, vertices);
}

-(void)setTexCoords:(GLfloat*)texCoords
{
	glTexCoordPointer(2, GL_FLOAT, 0, texCoords);
}

-(void)setColors:(unsigned char*)colors
{
	cColor[0] = colors[0];
	cColor[1] = colors[1];
	cColor[2] = colors[2];
	
	cColor[4] = colors[4];
	cColor[5] = colors[5];
	cColor[6] = colors[6];
	
	cColor[8] = colors[8];
	cColor[9] = colors[9];
	cColor[10] = colors[10];
	
	cColor[12] = colors[12];
	cColor[13] = colors[13];
	cColor[14] = colors[14];
	
	glColorPointer(4, GL_UNSIGNED_BYTE, 0, cColor);
}

-(void)setColorAlpha:(unsigned char)alpha
{
	cColor[3] = alpha;
	cColor[7] = alpha;
	cColor[11] = alpha;
	cColor[15] = alpha;
}

-(void)setInkEffect:(int)effect andParam:(int)effectParam
{
	unsigned int rgbaCoeff;
	float red = 1.0f, green = 1.0f, blue = 1.0f, alpha = 1.0f;
	
	//Ignores shader effects
	if((effect & BOP_MASK)==BOP_EFFECTEX)
	{
		effect = BOP_BLEND;
		rgbaCoeff = effectParam;
		alpha = (rgbaCoeff >> 24)/255.0f;
	}
	//Extracts the RGB Coefficient
	else if((effect & BOP_RGBAFILTER) != 0)
	{
		effect = MAX(effect & BOP_MASK, BOP_BLEND);		
		rgbaCoeff = effectParam;
		red = ((rgbaCoeff>>16) & 0xFF) / 255.0f;
		green = ((rgbaCoeff>>8) & 0xFF) / 255.0f;
		blue = (rgbaCoeff & 0xFF) / 255.0f;
		alpha = (rgbaCoeff >> 24)/255.0f;
	}
	//Uses the generic INK-effect
	else
	{
		effect &= BOP_MASK;
		if(effectParam == -1)
			alpha = 1.0f;
		else
			alpha = 1.0f - effectParam/128.0f;
	}
	
	switch (effect)
	{
		case BOP_COPY:
			[self setBlendEquation:GL_FUNC_ADD];
			[self setBlendFunction:GL_SRC_ALPHA dFactor:GL_ONE_MINUS_SRC_ALPHA];
			[self setBlendColorRed:1 green:1 blue:1 alpha:1];
			break;
		default:
		case BOP_BLEND:
		case BOP_BLEND_REPLEACETRANSP:
		case BOP_BLEND_DONTREPLACECOLOR:
		case BOP_OR:
		case BOP_XOR:
		{
			[self setBlendEquation:GL_FUNC_ADD];
			[self setBlendFunction:GL_SRC_ALPHA dFactor:GL_ONE_MINUS_SRC_ALPHA];
			[self setBlendColorRed:red green:green blue:blue alpha:alpha];
			[self setColorAlpha:alpha];
			break;
		}
		case BOP_INVERT:
			[self setBlendEquation:GL_FUNC_ADD];
			[self setBlendFunction:GL_SRC_ALPHA dFactor:GL_ONE_MINUS_SRC_ALPHA];
			[self setBlendColorRed:red green:green blue:blue alpha:alpha];
			break;
		case BOP_ADD:
			[self setBlendEquation:GL_FUNC_ADD];
			[self setBlendFunction:GL_SRC_ALPHA dFactor:GL_ONE];
			[self setBlendColorRed:red green:green blue:blue alpha:alpha];
			break;
		case BOP_SUB:
			[self setBlendEquationSeperate:GL_FUNC_REVERSE_SUBTRACT other:GL_FUNC_ADD];
			[self setBlendFunction:GL_ONE dFactor:GL_ONE];
			[self setBlendColorRed:red green:green blue:blue alpha:alpha];
			break;
	}
}

-(void)setProjectionMatrix:(int)x andY:(int)y andWidth:(int)width andHeight:(int)height
{	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrthof(x, x+width, y+height, y, 1.0f, -1.0f);
	glViewport(x, y, width, height);
}

-(void)bindRenderBuffer
{
	[EAGLContext setCurrentContext:context];
	glBindFramebufferOES(GL_FRAMEBUFFER_OES, defaultFramebuffer);
}

- (BOOL)resizeFromLayer:(CAEAGLLayer *)layer
{
	// Allocate color buffer backing based on the current layer size
	[EAGLContext setCurrentContext:context];
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, colorRenderbuffer);
    [context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:layer];
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);
	
	currentWidth = backingWidth;
	currentHeight = backingHeight;
	
    if (glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES)
    {
        NSLog(@"Failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
        return NO;
    }
	[self setProjectionMatrix:topLeft.x andY:topLeft.y andWidth:currentWidth andHeight:currentHeight];
    return YES;
}


-(void)renderGradient:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	GLfloat squareVertices[] = {
        x,		y,
		x+w,	y,
        x,		y+h,
		x+w,	y+h
    };
	
	glEnableClientState(GL_COLOR_ARRAY);
	glDisable(GL_TEXTURE_2D);
	
	[self setColorAlpha:255];
	
	//Update shader information
	[self setInkEffect:inkEffect andParam:inkEffectParam];
	[self setVertices:squareVertices];
	[self setColors:colors];
	
    // Draw
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	
	glEnable(GL_TEXTURE_2D);
	glDisableClientState(GL_COLOR_ARRAY);
}

-(void)renderLineWithXA:(int)xA andYA:(int)yA andXB:(int)xB andYB:(int)yB andColor:(int)color andThickness:(int)thickness
{	
	color = inverseOpaqueColor(color);
	GLfloat points[] = {xA,yA, xB,yB};
	int colors[] = {color, color};
	
	glEnableClientState(GL_COLOR_ARRAY);
	glDisable(GL_TEXTURE_2D);
	
	//Update shader information
	[self setInkEffect:0 andParam:0];
	[self setVertices:points];
	[self setColors:(unsigned char*)colors];
	
    // Draw
	glLineWidth(thickness);
    glDrawArrays(GL_LINES, 0, 2);
	
	glEnable(GL_TEXTURE_2D);
	glDisableClientState(GL_COLOR_ARRAY);
}




@end
