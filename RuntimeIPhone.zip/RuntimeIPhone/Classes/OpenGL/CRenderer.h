
#import <QuartzCore/QuartzCore.h>

#import <OpenGLES/EAGL.h>
#import <OpenGLES/EAGLDrawable.h>

#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

enum OpenGLESVersion {
	ES1, ES2
};

@class ITexture;
@class CRenderToTexture;
@class CRunView;

@interface CRenderer : NSObject
{
@public
    EAGLContext* context;
	CRunView* view;
	
    // The pixel dimensions of the CAEAGLLayer
    GLint backingWidth;
    GLint backingHeight;
	
	GLint currentWidth;
	GLint currentHeight;
	
	BOOL useClipping;
	GLint clipLeft, clipTop, clipRight, clipBottom;
	
	int originX, originY;
	CGPoint topLeft;
	
	int textureUsage;
	NSMutableSet* usedTextures;
	
    // The OpenGL ES names for the framebuffer and renderbuffer used to render to this view
    GLuint defaultFramebuffer, colorRenderbuffer;
	int openGLversion;
	
	UIDeviceOrientation orientation;
	CAEAGLLayer* glLayer;
	CGSize windowSize;
	
	//Current OpenGL state to minimize redundant state changes
	int currentTextureID;
	int currentBlendEquationA;
	int currentBlendEquationB;
	int currentBlendFunctionA;
	int currentBlendFunctionB;
	float cR, cG, cB, cA;
} 

-(id)initWithView:(CRunView*)runView;
-(void)dealloc;
-(void)destroyFrameBuffers;

-(BOOL)resizeFromLayer:(CAEAGLLayer *)layer;
-(void)clear:(float)red green:(float)green blue:(float)blue;
-(void)swapBuffers;
-(void)flush;

-(void)bindRenderBuffer;
-(void)updateViewport;

-(void)setInkEffect:(int)effect andParam:(int)effectParam;
-(void)setTexture:(ITexture*)texture;
-(void)setVertices:(GLfloat*)vertices;
-(void)setTexCoords:(GLfloat*)texCoords;
-(void)setColors:(unsigned char*)colors;
-(void)setProjectionMatrix:(int)x andY:(int)y andWidth:(int)width andHeight:(int)height;

-(void)renderSimpleImage:		(int)x andY:(int)y andWidth:(int)w andHeight:(int)h;
-(void)renderImage:				(ITexture*)image withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderPattern:			(ITexture*)image withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderPatternEllipse:	(ITexture*)image withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderScaledRotatedImage:(ITexture*)image withAngle:(int)angle andScaleX:(float)sX andScaleY:(float)sY andHotSpotX:(int)hX andHotSpotY:(int)hY andX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderPoint:				(ITexture*)image withX:(int)x andY:(int)y andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderLineWithXA:		(int)xA andYA:(int)yA andXB:(int)xB andYB:(int)yB andColor:(int)color andThickness:(int)thickness;

-(void)renderGradientEllipse:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderGradient:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderSolidColor:(int)color withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;

//For transitions
-(void)setOriginX:(int)x andY:(int)y;
-(void)renderBlitFull:	(CRenderToTexture*)source;
-(void)renderBlit:		(CRenderToTexture*)source withXDst:(int)xDst andYDst:(int)yDst andXSrc:(int)xSrc andYSrc:(int)ySrc andWidth:(int)width andHeight:(int)height;
-(void)renderStretch:	(CRenderToTexture*)source withXDst:(int)xDst andYDst:(int)yDst andWDst:(int)wDst andHDst:(int)hDst andXSrc:(int)xSrc andYSrc:(int)ySrc andWSrc:(int)wSrc andHSrc:(int)hSrc;
-(void)renderStretch:	(CRenderToTexture*)source withXDst:(int)xDst andYDst:(int)yDst andWDst:(int)wDst andHDst:(int)hDst andXSrc:(int)xSrc andYSrc:(int)ySrc andWSrc:(int)wSrc andHSrc:(int)hSrc andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderFade:		(CRenderToTexture*)source withCoef:(int)alpha;

-(void)useBlending:(bool)useBlending;

-(void)setBlendEquation:(GLenum)equation;
-(void)setBlendEquationSeperate:(GLenum)equationA other:(GLenum)equationB;
-(void)setBlendFunction:(GLenum)sFactor dFactor:(GLenum)dFactor;
-(void)setBlendColorRed:(float)red green:(float)green blue:(float)blue alpha:(float)alpha;

//Clipping
-(void)setClipWithX:(int)x andY:(int)y  andWidth:(int)w  andHeight:(int)h;
-(void)resetClip;

+(void)checkForError;

-(void)uploadTexture:(ITexture*)texture;
-(void)removeTexture:(ITexture*)texture;
-(void)cleanMemory;


@end

