//
//  ES2Renderer.m
//  OpenGLTest
//
//  Created by Anders Riggelsen on 4/19/10.
//

#import "CRenderer.h"
#import "ES2Renderer.h"
#import "CShader.h"
#import "ITexture.h"
#import "CRenderToTexture.h"
#import "Maths.h"
#import "CServices.h"
#import "CRunView.h"

@implementation ES2Renderer

- (id)initWithView:(CRunView*)runView
{
    if ((self = [super initWithView:runView]))
    {
        context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
        if (!context || ![EAGLContext setCurrentContext:context] || ![self loadShaders])
        {
            [self release];
            return nil;
        }
		
		openGLversion = ES2;
		
        // Create default framebuffer object. The backing will be allocated for the current layer in -resizeFromLayer
        glGenFramebuffers(1, &defaultFramebuffer);
        glGenRenderbuffers(1, &colorRenderbuffer);
        glBindFramebuffer(GL_FRAMEBUFFER, defaultFramebuffer);
        glBindRenderbuffer(GL_RENDERBUFFER, colorRenderbuffer);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, colorRenderbuffer);
		
		glEnable(GL_BLEND);
		
		useClipping = NO;
		clipLeft = clipTop = clipRight = clipBottom = 0;
		
		usedTextures = [[NSMutableSet alloc] init];
		[CRenderer checkForError];
	}
	
    return self;
}

- (BOOL)resizeFromLayer:(CAEAGLLayer *)layer
{
	// Allocate color buffer backing based on the current layer size
	[EAGLContext setCurrentContext:context];
    glBindRenderbuffer(GL_RENDERBUFFER, colorRenderbuffer);
    [context renderbufferStorage:GL_RENDERBUFFER fromDrawable:layer];
    glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_WIDTH, &backingWidth);
    glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_HEIGHT, &backingHeight);
	
	currentWidth = backingWidth;
	currentHeight = backingHeight;
	
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    {
        NSLog(@"Failed to make complete framebuffer object %x", glCheckFramebufferStatus(GL_FRAMEBUFFER));
        return NO;
    }
	
	[self setProjectionMatrix:topLeft.x	andY:topLeft.y andWidth:currentWidth andHeight:currentHeight];
	
    return YES;
}

-(void)dealloc
{
	[self destroyFrameBuffers];
	
	[basicShader release];
	[defaultShader release];
	[gradientShader release];
	[gradientEllipseShader release];
	[defaultEllipseShader release];
	[super dealloc];
}

-(void)destroyFrameBuffers
{
    if (defaultFramebuffer)
    {
        glDeleteFramebuffersOES(1, &defaultFramebuffer);
        defaultFramebuffer = 0;
    }
    if (colorRenderbuffer)
    {
        glDeleteRenderbuffersOES(1, &colorRenderbuffer);
        colorRenderbuffer = 0;
    }
}

- (void)setCurrentShader:(CShader*)shader
{
	if(shader == currentShader)
		return;
	
	currentShader = shader;
	[currentShader bindShader];
	[currentShader setProjectionMatrix:ortho];
}

-(void)setInkEffect:(int)effect andParam:(int)effectParam andShader:(CShader*)shader
{
	bool useBasic = YES;
	CShader* useShader = defaultShader;
	unsigned int rgbaCoeff;
	float red = 1.0f, green = 1.0f, blue = 1.0f, alpha = 1.0f;
	
	//Ignores shader effects
	if((effect & BOP_MASK)==BOP_EFFECTEX)
	{
		effect = BOP_BLEND;
		rgbaCoeff = effectParam;
		alpha = (rgbaCoeff >> 24)/255.0f;
	}
	//Extracts the RGB Coefficient
	else if((effect & BOP_RGBAFILTER) != 0)
	{
		effect = MAX(effect & BOP_MASK, BOP_BLEND);
		useBasic = NO;
		
		rgbaCoeff = effectParam;
		red = ((rgbaCoeff>>16) & 0xFF) / 255.0f;
		green = ((rgbaCoeff>>8) & 0xFF) / 255.0f;
		blue = (rgbaCoeff & 0xFF) / 255.0f;
		alpha = (rgbaCoeff >> 24)/255.0f;
	}
	//Uses the generic INK-effect
	else
	{
		effect &= BOP_MASK;
		if(effectParam == -1)
			alpha = 1.0f;
		else
			alpha = 1.0f - effectParam/128.0f;
	}

	// Use shader program
	if(shader != nil)
	{
		useShader = shader;
		effect = MAX(effect & BOP_MASK, BOP_BLEND);
	}
	else if(effect == 0 && useBasic == YES)
		useShader = basicShader;
	
	[self setCurrentShader:useShader];
	[currentShader setInkEffect:effect andParam:alpha];
	
	if(currentShader != basicShader)
		[currentShader setRGBCoeff:red andGreen:green andBlue:blue];
}

-(void)setInkEffect:(int)effect andParam:(int)effectParam
{
	[self setInkEffect:effect andParam:effectParam andShader:nil];
}

-(void)setProjectionMatrix:(int)x andY:(int)y andWidth:(int)width andHeight:(int)height
{
	float left = x;
	float right = x+width;
	float top = y;
	float bottom = y+height;
	
	float far = 1.0f;
	float near = -1.0f;
	
	float tx = - (right+left)/(right-left);
	float ty = - (top+bottom)/(top-bottom);
	float tz = - (far+near)/(far-near);
	
	float orthoMatrix[16] = {
		2/(right-left),		0,				0,				tx,
		0,					2/(top-bottom),	0,				ty,
		0,					0,				-2/(far-near),	tz,
		0,					0,				0,				1
	};
	
	memcpy(ortho, orthoMatrix, 16*sizeof(float));
	[currentShader setProjectionMatrix:ortho];
	glViewport(x, y, width, height);
}

- (void)setTexture:(ITexture*)texture
{
	[currentShader setTexture:texture];
}

- (void)setVertices:(GLfloat*)vertices
{
	[currentShader setVertices:vertices];
}

-(void)setTexCoords:(GLfloat*)texCoords
{
	[currentShader setTexCoords:texCoords];
}

-(void)setColors:(unsigned char*)colors
{
	[currentShader setColors:colors];
}

-(void)bindRenderBuffer
{
	[EAGLContext setCurrentContext:context];
	glBindFramebuffer(GL_FRAMEBUFFER, defaultFramebuffer);
}

- (BOOL)loadShaders
{
	basicShader = [[CShader alloc] initWithRenderer:self];
	[basicShader loadShader:@"basic" useTexCoord:YES useColors:NO];
	[basicShader fetchUniform:"texture" toLocation:UNIFORM_TEXTURE];
	[basicShader fetchUniform:"projectionMatrix" toLocation:UNIFORM_PROJECTIONMATRIX];
	
	defaultShader = [[CShader alloc] initWithRenderer:self];
	[defaultShader loadShader:@"default" useTexCoord:YES useColors:NO];
	[defaultShader fetchUniform:"texture" toLocation:UNIFORM_TEXTURE];
	[defaultShader fetchUniform:"projectionMatrix" toLocation:UNIFORM_PROJECTIONMATRIX];
	[defaultShader fetchUniform:"inkEffect" toLocation:UNIFORM_INKEFFECT];
	[defaultShader fetchUniform:"inkParam" toLocation:UNIFORM_INKPARAM];
	[defaultShader fetchUniform:"rgbCoeff" toLocation:UNIFORM_RGBCOEFFICIENT];
	
	gradientShader = [[CShader alloc] initWithRenderer:self];
	[gradientShader loadShader:@"gradient" useTexCoord:NO useColors:YES];
	[gradientShader fetchUniform:"projectionMatrix" toLocation:UNIFORM_PROJECTIONMATRIX];
	[gradientShader fetchUniform:"inkEffect" toLocation:UNIFORM_INKEFFECT];
	[gradientShader fetchUniform:"inkParam" toLocation:UNIFORM_INKPARAM];
	[gradientShader fetchUniform:"rgbCoeff" toLocation:UNIFORM_RGBCOEFFICIENT];
	
	defaultEllipseShader = [[CShader alloc] initWithRenderer:self];
	[defaultEllipseShader loadShader:@"defaultEllipse" useTexCoord:YES useColors:NO];
	[defaultEllipseShader fetchUniform:"texture" toLocation:UNIFORM_TEXTURE];
	[defaultEllipseShader fetchUniform:"projectionMatrix" toLocation:UNIFORM_PROJECTIONMATRIX];
	[defaultEllipseShader fetchUniform:"inkEffect" toLocation:UNIFORM_INKEFFECT];
	[defaultEllipseShader fetchUniform:"inkParam" toLocation:UNIFORM_INKPARAM];
	[defaultEllipseShader fetchUniform:"centerpos" toLocation:UNIFORM_ELLIPSE_CENTERPOS];
	[defaultEllipseShader fetchUniform:"radius" toLocation:UNIFORM_ELLIPSE_RADIUS];
	[defaultEllipseShader fetchUniform:"rgbCoeff" toLocation:UNIFORM_RGBCOEFFICIENT];
	
	gradientEllipseShader = [[CShader alloc] initWithRenderer:self];
	[gradientEllipseShader loadShader:@"gradientEllipse" useTexCoord:NO useColors:YES];
	[gradientEllipseShader fetchUniform:"projectionMatrix" toLocation:UNIFORM_PROJECTIONMATRIX];
	[gradientEllipseShader fetchUniform:"inkEffect" toLocation:UNIFORM_INKEFFECT];
	[gradientEllipseShader fetchUniform:"inkParam" toLocation:UNIFORM_INKPARAM];	
	[gradientEllipseShader fetchUniform:"centerpos" toLocation:UNIFORM_ELLIPSE_CENTERPOS];
	[gradientEllipseShader fetchUniform:"radius" toLocation:UNIFORM_ELLIPSE_RADIUS];
	[gradientEllipseShader fetchUniform:"rgbCoeff" toLocation:UNIFORM_RGBCOEFFICIENT];
	return TRUE;
}

-(void)renderGradientEllipse:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	GLfloat squareVertices[] = {
        x,		y,
		x+w,	y,
        x,		y+h,
		x+w,	y+h
    };
		
	//Update shader information
	[self setInkEffect:inkEffect andParam:inkEffectParam andShader:gradientEllipseShader];
	[currentShader setVertices:squareVertices];	
	[currentShader setEllipseCenterX:x+w/2 andY:y+h/2 withRadiusA:w/2 andRadiusB:h/2];
	[currentShader setColors:colors];
	
	// Draw
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)renderGradient:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	GLfloat squareVertices[] = {
        x,		y,
		x+w,	y,
        x,		y+h,
		x+w,	y+h
    };

	//Update shader information
	[self setInkEffect:inkEffect andParam:inkEffectParam andShader:gradientShader];
	[currentShader setVertices:squareVertices];
	[currentShader setColors:colors];
	
    // Draw
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)renderPatternEllipse:(ITexture*)image withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	//Limit the amount of repetitions to what only is visible
	int startX = x;
	int startY = y;
	int endX = x+w;
	int endY = y+h;
	
	int iw = [image getWidth];
	int ih = [image getHeight];
	
	if(startX < -iw)
		startX %= iw;
	
	if(startY < -ih)
		startY %= ih;
	
	if(endX > backingWidth)
		endX = (endX-backingWidth) % iw + backingWidth;
	
	if(endY > backingHeight)
		endY = (endY-backingHeight) % ih + backingHeight;
	
	//Clipping is not really needed here, but can improve performance on large mosaic tiles
	[self setClipWithX:startX andY:startY andWidth:endX andHeight:endY];
	[self uploadTexture:image];
	
	//Update shader information
	[self setInkEffect:inkEffect andParam:inkEffectParam andShader:defaultEllipseShader];
	[currentShader setTexture:image];
	[currentShader setTexCoords:[image getTextureCoordinates]];
	[currentShader setEllipseCenterX:x+w/2 andY:y+h/2 withRadiusA:w/2 andRadiusB:h/2];
	
	for(int cY=startY; cY<endY; cY+=ih)
		for(int cX=startX; cX<endX; cX+=iw)
			[self renderSimpleImage:cX andY:cY andWidth:iw andHeight:ih];
	
	[self resetClip];
}


-(void)renderLineWithXA:(int)xA andYA:(int)yA andXB:(int)xB andYB:(int)yB andColor:(int)color andThickness:(int)thickness
{	
	color = inverseOpaqueColor(color);
	GLfloat points[] = {xA,yA, xB,yB};
	int colors[] = {color, color};
	
	//Update shader information
	[self setInkEffect:0 andParam:0 andShader:gradientShader];
	[currentShader setVertices:points];
	[currentShader setColors:(unsigned char*)colors];
	
    // Draw
	glLineWidth(thickness);
    glDrawArrays(GL_LINES, 0, 2);
}


@end
