//
//  CRenderer.m
//  RuntimeIPhone
//
//  Created by Anders Riggelsen on 1/14/11.
//  Copyright 2011 Clickteam. All rights reserved.
//

#import "CRenderer.h"

#import "ITexture.h"
#import "CRenderToTexture.h"
#import "Maths.h"
#import "CServices.h"
#import "CShader.h"
#import "CRunView.h"
#import "CRunApp.h"

@implementation CRenderer

-(id)initWithView:(CRunView*)runView
{
	if(self == [super init])
	{
		view = runView;
		windowSize = CGSizeMake(view->appRect.size.width, view->appRect.size.height);
		topLeft = CGPointMake(0, 0);
		currentTextureID = -1;
		currentBlendEquationA = currentBlendEquationB = currentBlendFunctionA = currentBlendFunctionB = -1;
		cR = cG = cB = cA = 1.0f;
	}
	return self;
}

-(void)dealloc
{
    // Tear down context
    if ([EAGLContext currentContext] == context)
        [EAGLContext setCurrentContext:nil];
	
    [context release];
    context = nil;
    [super dealloc];
}

// Clear the frame, ready for rendering
- (void)clear:(float)red green:(float)green blue:(float)blue;
{
    glClearColor(red, green, blue, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
}

- (void)swapBuffers
{
    glBindRenderbuffer(GL_RENDERBUFFER, colorRenderbuffer);
    [context presentRenderbuffer:GL_RENDERBUFFER];
}

-(void)flush
{
	glFlush();
}

+(void)checkForError
{
	GLenum err = glGetError();
	if (GL_NO_ERROR != err)
		NSLog(@"Got OpenGL Error: %i", err);
}

//Renders the given image with the previously defined shaders and settings.
-(void)renderSimpleImage:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h
{
	GLfloat squareVertices[] = {
        x,		y,
		x+w,	y,
        x,		y+h,
		x+w,	y+h
    };
	[self setVertices:squareVertices];
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

//The most common image rendering method.
- (void)renderImage: (ITexture*)image withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{		
	if(w == 1 && h == 1)
	{
		[self renderPoint:image withX:x andY:y andInkEffect:inkEffect andInkEffectParam:inkEffectParam];
		return;
	}
	
	//Make sure that the image exists on the device (if it is already uploaded, this call is ignored)
	[self uploadTexture:image];
	
	GLfloat squareVertices[] = {
        x,		y,
		x+w,	y,
        x,		y+h,
		x+w,	y+h
    };
	
	// Use shader program
	[self setInkEffect:inkEffect andParam:inkEffectParam];
	
	//Update shader information
	[self setTexture:image];
	[self setVertices:squareVertices];
	[self setTexCoords:[image getTextureCoordinates]];
	
    // Draw
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)renderPoint:(ITexture*)image withX:(int)x andY:(int)y andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	[self uploadTexture:image];
	GLfloat vertex[] = {x,y};
	
	// Use shader program
	[self setInkEffect:inkEffect andParam:inkEffectParam];
	[self setTexture:image];
	[self setVertices:vertex];
	[self setTexCoords:[image getTextureCoordinates]];
	
	glDrawArrays(GL_POINTS, 0, 1);
}

//The most common image rendering method.
- (void)renderScaledRotatedImage:(ITexture*)image withAngle:(int)angle andScaleX:(float)sX andScaleY:(float)sY andHotSpotX:(int)hX andHotSpotY:(int)hY andX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{	
	//Avoid costly rotation maths
	if(angle == 0 && sX == 1.0 && sY == 1.0)
	{
		[self renderImage:image withX:x-hX andY:y-hY andWidth:w andHeight:h andInkEffect:inkEffect andInkEffectParam:inkEffectParam];
		return;
	}
	
	//Make sure that the image exists on the device (if it is already uploaded, this call is ignored)
	[self uploadTexture:image];
	
	//Optimization for scaled images (Generate mip-maps at the cost of extra memory)
	if(sX <= 0.5f && sY <= 0.5f)
		[image generateMipMaps];
	
	float radian = 3.1415926535*angle/180.0;
	float cosA = cos(radian);
	float sinA = sin(radian);
	
	//Scaled points
	float sp[] = {
		-hX*sX,		-hY*sY,
		(-hX+w)*sX,	-hY*sY,
		-hX*sX,		(-hY+h)*sY,
		(-hX+w)*sX,	(-hY+h)*sY
	};
	
	//Rotated points
	float rotatedPoints[] = {
		sp[0]*cosA+sp[1]*sinA+x,	-sp[0]*sinA+sp[1]*cosA+y,
		sp[2]*cosA+sp[3]*sinA+x,	-sp[2]*sinA+sp[3]*cosA+y,
		sp[4]*cosA+sp[5]*sinA+x,	-sp[4]*sinA+sp[5]*cosA+y,
		sp[6]*cosA+sp[7]*sinA+x,	-sp[6]*sinA+sp[7]*cosA+y
	};
	
	[self setInkEffect:inkEffect andParam:inkEffectParam];
	[self setTexture:image];
	[self setVertices:rotatedPoints];
	[self setTexCoords:[image getTextureCoordinates]];
	
    // Draw
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

//Renders a tiled picture with clipping.
-(void)renderPattern:(ITexture*)image withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	//Limit the amount of repetitions to what only is visible
	int startX = x;
	int startY = y;
	int endX = x+w;
	int endY = y+h;
	
	[self uploadTexture:image];
	
	int iw = [image getWidth];
	int ih = [image getHeight];
	int tw = [image getTextureWidth];
	int th = [image getTextureHeight];
	
	if(startX < -iw)
		startX %= iw;
	
	if(startY < -ih)
		startY %= ih;
	
	if(endX > currentWidth)
		endX = (endX-currentWidth) % iw + currentWidth;
	
	if(endY > currentHeight)
		endY = (endY-currentHeight) % ih + currentHeight;
	
	w = endX - startX;
	h = endY - startY;
	
	//Update shader information
	[self setInkEffect:inkEffect andParam:inkEffectParam];
	[self setTexture:image];
	
	//If tileable texture coordinates are possible
	if(iw == tw && ih == th)
	{
		GLfloat rx = w/(GLfloat)iw;
		GLfloat ry = h/(GLfloat)ih;
		
		GLfloat itc [8];
		memcpy(itc, [image getTextureCoordinates], sizeof(GLfloat)*8);
		itc[2] = rx;	//<w>,0
		itc[5] = ry;	//0,<h>
		itc[6] = rx;	//<w>,h
		itc[7] = ry;	//w,<h>
		
		//Allow the texture to repeat when reading outside the border
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		
		[self setTexCoords:itc];
		[self renderSimpleImage:startX andY:startY andWidth:w andHeight:h];
	}
	else
	{
		//Enables the OpenGL scissor test to restrict drawing inside the object boundaries
		[self setClipWithX:startX andY:startY andWidth:endX andHeight:endY];
		[self setTexCoords:[image getTextureCoordinates]];
		
		for(int cY=startY; cY<endY; cY+=ih)
			for(int cX=startX; cX<endX; cX+=iw)
				[self renderSimpleImage:cX andY:cY andWidth:iw andHeight:ih];
		
		[self resetClip];
		
	}
}

-(void)renderSolidColor:(int)color withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	color |= 0xFF000000;
	unsigned int colors[] = {color, color, color, color};
	[self renderGradient:(unsigned char *)colors withX:x andY:y andWidth:w andHeight:h andInkEffect:inkEffect andInkEffectParam:inkEffectParam];
}

- (void)setOriginX:(int)x andY:(int)y
{
	originX = x;
	originY = y;
}

//Blit wrappers for the transition system
- (void)renderBlitFull:(CRenderToTexture*)source
{
	[self renderStretch:source withXDst:0 andYDst:0 andWDst:[source getWidth] andHDst:[source getHeight] andXSrc:0 andYSrc:0 andWSrc:[source getWidth] andHSrc:[source getHeight]];
}

- (void)renderBlit:(CRenderToTexture*)source withXDst:(int)xDst andYDst:(int)yDst andXSrc:(int)xSrc andYSrc:(int)ySrc andWidth:(int)width andHeight:(int)height
{
	[self renderStretch:source withXDst:xDst andYDst:yDst andWDst:width andHDst:height andXSrc:xSrc andYSrc:ySrc andWSrc:width andHSrc:height];
}

- (void)renderFade:(CRenderToTexture*)source withCoef:(int)alpha
{
	[self renderStretch:source withXDst:0 andYDst:0 andWDst:[source getWidth] andHDst:[source getHeight] andXSrc:0 andYSrc:0 andWSrc:[source getWidth] andHSrc:[source getHeight] andInkEffect:1 andInkEffectParam:alpha/2];
}

- (void)renderStretch:(CRenderToTexture*)source withXDst:(int)xDst andYDst:(int)yDst andWDst:(int)wDst andHDst:(int)hDst andXSrc:(int)xSrc andYSrc:(int)ySrc andWSrc:(int)wSrc andHSrc:(int)hSrc
{
	[self renderStretch:source withXDst:xDst andYDst:yDst andWDst:wDst andHDst:hDst andXSrc:xSrc andYSrc:ySrc andWSrc:wSrc andHSrc:hSrc andInkEffect:0 andInkEffectParam:0];
}

- (void)renderStretch:(CRenderToTexture*)source withXDst:(int)xDst andYDst:(int)yDst andWDst:(int)wDst andHDst:(int)hDst andXSrc:(int)xSrc andYSrc:(int)ySrc andWSrc:(int)wSrc andHSrc:(int)hSrc andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	[self uploadTexture:(ITexture*)source];
	
	GLint currentbuffer;
	glGetIntegerv(GL_FRAMEBUFFER_BINDING, &currentbuffer);
	
	if(currentbuffer == defaultFramebuffer)
	{
		xDst += originX;
		yDst += originY;
	}
	
	GLfloat squareVertices[] = {
        xDst,		yDst,
		xDst+wDst,	yDst,
        xDst,		yDst+hDst,
		xDst+wDst,	yDst+hDst
    };
	
	GLfloat tWidth = [source getTextureWidth];
	GLfloat tHeight = [source getTextureHeight];
	int iHeight = [source getHeight];
	
	//Coordinates are flipped here
	GLfloat leftX = xSrc/tWidth;
	GLfloat rightX = (xSrc+wSrc)/tWidth;
	GLfloat topY = (iHeight-ySrc)/tHeight;
	GLfloat bottomY = (iHeight-(ySrc+hSrc))/tHeight;
	
	GLfloat texCoord [] = 
	{
		leftX,	topY,
		rightX,	topY,
		leftX,	bottomY,
		rightX, bottomY
	};
	
	[self setInkEffect:inkEffect andParam:inkEffectParam];
	
	[self setTexture:(ITexture*)source];
	[self setVertices:squareVertices];
	[self setTexCoords:texCoord];
	
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

- (void)useBlending:(bool)useBlending
{
	if(useBlending)
		glEnable(GL_BLEND);
	else
		glDisable(GL_BLEND);
}

-(void)uploadTexture:(ITexture*)texture
{
	if([texture getTextureID] != -1)
		return;
	
	textureUsage += [texture uploadTexture];
	
	if([usedTextures containsObject:texture] == NO)
		[usedTextures addObject:texture];
}

-(void)removeTexture:(ITexture*)texture
{
	textureUsage -= [texture deleteTexture];
	
	if([usedTextures containsObject:texture] == YES)
		[usedTextures removeObject:texture];	
}

-(void)updateViewport
{
    glViewport(0, 0, backingWidth, backingHeight);
}

-(void)cleanMemory
{
	NSEnumerator* enumerator = [usedTextures objectEnumerator];
	id value;
	while ((value = [enumerator nextObject]))
	{
		ITexture* texture = (ITexture*)value;
		textureUsage -= [texture deleteTexture];
	}
	[usedTextures removeAllObjects];
}

-(void)setClipWithX:(int)x andY:(int)y  andWidth:(int)w  andHeight:(int)h
{
	w = MIN(currentWidth,w);
	h = MIN(currentHeight,h);
	x = MAX(0,x);
	y = MAX(0,y);
	
	glEnable(GL_SCISSOR_TEST);
	glScissor(x, backingHeight-y-h, w, h);
}

-(void)resetClip
{
	glDisable(GL_SCISSOR_TEST);
}

-(void)setBlendEquation:(GLenum)equation
{
	if(currentBlendEquationA != equation)
	{
		currentBlendEquationA = equation;
		glBlendEquation(equation);
	}
}

-(void)setBlendEquationSeperate:(GLenum)equationA other:(GLenum)equationB
{
	if(currentBlendEquationA != equationA || equationB != currentBlendEquationB)
	{
		currentBlendEquationA = equationA;
		currentBlendEquationB = equationB;
		glBlendEquationSeparate(equationA, equationB);
	}
}

-(void)setBlendFunction:(GLenum)sFactor dFactor:(GLenum)dFactor
{
	if(currentBlendFunctionA != sFactor || currentBlendFunctionB != dFactor)
	{
		currentBlendFunctionA = sFactor;
		currentBlendFunctionB = dFactor;
		glBlendFunc(sFactor, dFactor);
	}
}

-(void)setBlendColorRed:(float)red green:(float)green blue:(float)blue alpha:(float)alpha
{
	if(cA != alpha || cR != red || cG != green || cB != blue)
	{
		glColor4f(red, green, blue, alpha);
		cR = red;
		cG = green;
		cB = blue;
		cA = alpha;
	}
}

-(void)bindRenderBuffer
{
	//Must be overwritten in subclass
}

- (void)setTexture:(ITexture*)texture
{
	//Must be overwritten in subclass
}

- (void)setVertices:(GLfloat*)vertices
{
	//Must be overwritten in subclass
}

-(void)setTexCoords:(GLfloat*)texCoords
{
	//Must be overwritten in subclass
}

-(void)setColors:(unsigned char*)colors
{
	//Must be overwritten in subclass
}

-(void)setInkEffect:(int)effect andParam:(int)effectParam
{
	//Must be overwritten in subclass
}

-(void)setProjectionMatrix:(int)x andY:(int)y andWidth:(int)width andHeight:(int)height
{
	//Must be overwritten in subclass
}

-(void)renderLineWithXA:(int)xA andYA:(int)yA andXB:(int)xB andYB:(int)yB andColor:(int)color andThickness:(int)thickness
{	
	//Must be overwritten in subclass
}

-(void)renderGradientEllipse:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	//Must be overwritten in subclass
}

//Renders a tiled picture with clipping.
-(void)renderPatternEllipse:(ITexture*)image withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	//Must be overwritten in subclass
}

-(void)renderGradient:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam
{
	//Must be overwritten in subclass
}

- (BOOL)resizeFromLayer:(CAEAGLLayer *)layer
{
	//Must be overwritten in subclass
    return YES;
}

-(void)destroyFrameBuffers
{
	//Must be overwritten in subclass
}

@end
