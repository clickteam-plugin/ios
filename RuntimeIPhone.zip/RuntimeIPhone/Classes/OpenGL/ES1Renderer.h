//
//  ES1Renderer.h
//  RuntimeIPhone
//
//  Created by Anders Riggelsen on 1/14/11.
//  Copyright 2011 Clickteam. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CRenderer.h"

@class CRunView;

@interface ES1Renderer : CRenderer
{
	unsigned char cColor [16];
}
-(id)initWithView:(CRunView*)runView;
-(void)dealloc;
-(void)destroyFrameBuffers;

-(void)bindRenderBuffer;
-(BOOL)resizeFromLayer:(CAEAGLLayer *)layer;

-(void)setTexture:(ITexture*)texture;
-(void)setVertices:(GLfloat*)vertices;
-(void)setTexCoords:(GLfloat*)texCoords;
-(void)setColorAlpha:(unsigned char)alpha;
-(void)setColors:(unsigned char*)colors;
-(void)setInkEffect:(int)effect andParam:(int)effectParam;
-(void)setProjectionMatrix:(int)x andY:(int)y andWidth:(int)width andHeight:(int)height;

-(void)renderGradient:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;

@end
