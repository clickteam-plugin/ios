//
//  ES2Renderer.h
//  OpenGLTest
//
//  Created by Anders Riggelsen on 4/19/10.
//

#import <QuartzCore/QuartzCore.h>

#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>

#import "CRenderer.h"

@class ITexture;
@class CRenderToTexture;
@class CShader;
@class CRunView;

@interface ES2Renderer : CRenderer
{
@public
	CShader* basicShader;	//No ink effects allowed for this one
	CShader* defaultShader;
	CShader* defaultEllipseShader;
	CShader* gradientShader;
	CShader* gradientEllipseShader;
	CShader* currentShader;
	float ortho [16];
}

-(id)initWithView:(CRunView*)runView;
-(BOOL)loadShaders;
-(BOOL)resizeFromLayer:(CAEAGLLayer *)layer;
-(void)setCurrentShader:(CShader*)shader;
-(void)bindRenderBuffer;

-(void)setInkEffect:(int)effect andParam:(int)effectParam;
-(void)setInkEffect:(int)effect andParam:(int)effectParam andShader:(CShader*)shader;

-(void)setTexture:(ITexture*)texture;
-(void)setVertices:(GLfloat*)vertices;
-(void)setTexCoords:(GLfloat*)texCoords;
-(void)setColors:(unsigned char*)colors;
-(void)setProjectionMatrix:(int)x andY:(int)y andWidth:(int)width andHeight:(int)height;

-(void)renderGradientEllipse:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderGradient:(unsigned char*)colors withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderPatternEllipse:(ITexture*)image withX:(int)x andY:(int)y andWidth:(int)w andHeight:(int)h andInkEffect:(int)inkEffect andInkEffectParam:(int)inkEffectParam;
-(void)renderLineWithXA:(int)xA andYA:(int)yA andXB:(int)xB andYB:(int)yB andColor:(int)color andThickness:(int)thickness;


-(void)dealloc;
-(void)destroyFrameBuffers;

@end

