//----------------------------------------------------------------------------------
//
// CIMAGE Une image
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>
#import "ITexture.h"

@class CFile;
@class CMask;
@class CImage;
@class CBitmap;
@class CRunApp;
@class CArrayList;

#define MAX_ROTATEDMASKS 10

struct ImageInfo
{
	BOOL isFound;
	short width;
	short height;
	short xSpot;
	short ySpot;
	short xAP;
	short yAP;
};
typedef struct ImageInfo ImageInfo;

@interface CImage : NSObject <ITexture>
{
@public 
	CRunApp* app;
	short handle;
    short width;
    short height;
    short xSpot;
    short ySpot;
    short xAP;
    short yAP;
    short useCount;
	int chunkSize;
	CArrayList* maskRotation;
	
	short format;
	short flags;
	short bytesPrPixel;
	int openGLmode;
	int openGLformat;
	BOOL coordsAreSwapped;
	
	unsigned int* data;
    CMask* mask;
    CMask* maskPlatform;
	
	GLuint textureId;
	int textureWidth;
	int	textureHeight;
	GLfloat textureCoordinates[8];
	BOOL bCanRelease;
	int offset;
	CFile* file;
	BOOL hasMipMaps; 
	
}
-(id)initWithApp:(CRunApp*)a;
-(id)initWithWidth:(int)sx andHeight:(int)sy;
-(void)dealloc;
-(void)cleanMemory;
-(void)loadHandle:(CFile*)file;
-(void)load:(CFile*)file;
-(CMask*)getMask:(int)nFlags withAngle:(int)angle andScaleX:(double)scaleX andScaleY:(double)scaleY;
-(void)copyImage:(CImage*)image;
-(CGImageRef)getCGImage;
-(UIImage*)getUIImage;
-(void)freeCGImage:(CGImageRef)cgImage;
-(void)loadBitmap:(CBitmap*)bitmap;
-(void)calculateTextureSize;

+(CImage*)createFullColorImage:(CImage*)image;
+(CImage*)loadUIImage:(UIImage*)image;
+(CImage*)loadBitmap:(CBitmap*)bitmap;
+(int)getFormatByteSize:(int)format;

-(int)getPixel:(int)x withY:(int)y;

//CImage extra to reupload it's image data attempting to reuse the current texture ID if possible
-(int)reUploadTexture;

// ITexture methods
-(int)uploadTexture;
-(int)deleteTexture;
-(int)getTextureID;
-(int)getWidth;
-(int)getHeight;
-(int)getTextureWidth;
-(int)getTextureHeight;
-(GLfloat*)getTextureCoordinates;

@end

//Inlined function for determining if a given pixel is transparent
//Giving the format to the function allows the compiler to optimize the inlined function even more
static inline bool pixelIsSolid(CImage* img, int x, int y)
{
	unsigned int pixel4;
	unsigned short pixel2;
	unsigned short* sData = (unsigned short*)img->data;
	int sWidth = img->width + (img->width % 2);
	switch (img->format)
	{
		case RGBA8888:
			pixel4 = img->data[x+ y*img->width];
			return ((pixel4 & 0xFF000000) != 0);
		case RGBA4444:
			pixel2 = sData[x+ y*sWidth];
			return ((pixel2 & 0x00F) != 0);
		case RGBA5551:
			pixel2 = sData[x+ y*sWidth];
			return ((pixel2 & 0x0001) != 0);			
		case RGB888:
		case RGB565:
		default:
			return true;
	}
}

