//
//  CRuniPhoneStore.m
//  RuntimeIPhone
//
//  Created by Anders Riggelsen on 1/25/11.
//  Copyright 2011 Clickteam. All rights reserved.
//

#import "CRuniOSStore.h"

#import "CActExtension.h"
#import "CCndExtension.h"

#import "CExtension.h"
#import "CPoint.h"
#import "CCreateObjectInfo.h"
#import "CFile.h"

#import "CRunApp.h"
#import "CValue.h"
#import "CExtension.h"
#import "CRun.h"
#import "CServices.h"
#import "NSExtensions.h"


#define	CND_CANPAYMENTSBEMADE		0
#define CND_ONREQUESTRESPONSE		1
#define CND_ONPAYMENTPURCHASED		2
#define CND_ONPAYMENTFAILED			3
#define CND_ONPAYMENTCANCELED		4
#define CND_ONPAYMENTRESTORED		5

#define CND_ONANYREQUESTRESPONSE	6
#define CND_ONANYPAYMENTPURCHASED	7
#define CND_ONANYPAYMENTFAILED		8
#define CND_ONANYPAYMENTCANCELED	9
#define CND_ONANYPAYMENTRESTORED	10

#define CND_ONINVALIDIDENTIFIER		11
#define CND_ONANYINVALIDIDENTIFIER	12


#define	ACT_REQUESTPRODUCTSLOT		0
#define ACT_REQUESTPAYMENTSLOT		1
#define ACT_RESTORETRANSACTIONS		2

#define	EXP_PRODUCTNAME				0
#define EXP_PRODUCTDESCRIPTION		1
#define EXP_PRODUCTPRICE			2
#define EXP_PRODUCTPRICELOCALE		3
#define EXP_PRODUCTIDENTIFIER		4

@implementation CRuniOSStore


-(int)getNumberOfConditions
{
	return 13;
}

-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version
{
	productIdentifier = [[NSString alloc] initWithString:@""];
	productName = [[NSString alloc] initWithString:@""];
	productDescription = [[NSString alloc] initWithString:@""];
	localizedPrice = [[NSString alloc] initWithString:@""];
	storeReceipt = [[NSString alloc] initWithString:@""];
	productPrice = 0;
	
	[[SKPaymentQueue defaultQueue] addTransactionObserver:self];
	
	formatter = [[NSNumberFormatter alloc] init];
	[formatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
	[formatter setNumberStyle:NSNumberFormatterCurrencyStyle];
		
	return YES;
}

-(void)destroyRunObject:(BOOL)bFast
{
	if(productIdentifier != nil)
		[productIdentifier release];
	if(productName != nil)
		[productName release];
	if(productDescription != nil)
		[productDescription release];
	if(localizedPrice != nil)
		[localizedPrice release];
	if(storeReceipt != nil)
		[storeReceipt release];
	
	[[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
	
	[formatter release];
}


// Conditions
// --------------------------------------------------
-(BOOL)condition:(int)num withCndExtension:(CCndExtension*)cnd
{
	switch (num)
	{
		case CND_CANPAYMENTSBEMADE:
			return [SKPaymentQueue canMakePayments];
		case CND_ONREQUESTRESPONSE:
		case CND_ONPAYMENTPURCHASED:
		case CND_ONPAYMENTFAILED:
		case CND_ONPAYMENTCANCELED:
		case CND_ONPAYMENTRESTORED:
		case CND_ONINVALIDIDENTIFIER:
			return [productIdentifier isEqualToString:[cnd getParamExpString:rh withNum:0]];
		case CND_ONANYREQUESTRESPONSE:
		case CND_ONANYPAYMENTPURCHASED:
		case CND_ONANYPAYMENTFAILED:
		case CND_ONANYPAYMENTCANCELED:
		case CND_ONANYPAYMENTRESTORED:
		case CND_ONANYINVALIDIDENTIFIER:
			return YES;
	}
	return NO;
}

// Actions
// -------------------------------------------------
-(void)action:(int)num withActExtension:(CActExtension*)act
{
	switch (num)
	{
		case ACT_REQUESTPRODUCTSLOT:
			[self act_RequestProductSlot:[act getParamExpString:rh withNum:0]];
			break;
		case ACT_REQUESTPAYMENTSLOT:
		{
			NSString* identifier = [act getParamExpString:rh withNum:0];
			int q = [act getParamExpression:rh withNum:1];
			[self act_RequestPaymentSlot:identifier andQuantity:q];
			break;
		}
        case ACT_RESTORETRANSACTIONS:
            [self act_RestoreTransactions];            
            break;
    }
}

-(void)act_RequestProductSlot:(NSString*)slot
{
	SKProductsRequest* request = [[SKProductsRequest alloc] initWithProductIdentifiers:[NSSet setWithObject:slot]];
	request.delegate = self;
	[request start];
}

-(void)act_RequestPaymentSlot:(NSString*)slot andQuantity:(int)quantity
{
	SKMutablePayment* payment = [SKMutablePayment paymentWithProductIdentifier:slot];
	payment.quantity = quantity;
	[[SKPaymentQueue defaultQueue] addPayment:payment];
}

-(void)act_RestoreTransactions
{
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}
// Expressions
// --------------------------------------------
-(CValue*)expression:(int)num
{
	switch (num)
	{
		case EXP_PRODUCTNAME:
			return [self exp_ProductName];
			break;
		case EXP_PRODUCTDESCRIPTION:
			return [self exp_ProductDescription];
			break;
		case EXP_PRODUCTPRICE:
			return [self exp_ProductPrice];
			break;
		case EXP_PRODUCTPRICELOCALE:
			return [self exp_ProductPriceLocale];
			break;
	}
	return [rh getTempValue:0];//won't happen
}


-(CValue*)exp_ProductName
{
	return [rh getTempString:productName];
}

-(CValue*)exp_ProductDescription
{
	return [rh getTempString:productDescription];
}


-(CValue*)exp_ProductPrice
{
	CValue* val = [rh getTempValue:0];
	[val forceDouble:productPrice];
	return val;
}

-(CValue*)exp_ProductPriceLocale
{
	return [rh getTempString:localizedPrice];
}

-(CValue*)exp_ProductIdentifier
{
	return [rh getTempString:productIdentifier];
}

-(CValue*)exp_StoreReciept
{
	return [rh getTempString:storeReceipt];
}

-(void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response
{
	for(NSString* invId in response.invalidProductIdentifiers)
	{
		[productIdentifier release];
		productIdentifier = [[NSString alloc] initWithString:invId];
		[ho generateEvent:CND_ONINVALIDIDENTIFIER withParam:0];
		[ho generateEvent:CND_ONANYINVALIDIDENTIFIER withParam:0];
	}

	for(SKProduct* product in response.products)
	{
		[productIdentifier release];
		[productName release];
		[productDescription release];
		[localizedPrice release];
		
		
		productName = [[NSString alloc] initWithString:product.localizedTitle];
		productDescription = [[NSString alloc] initWithString:product.localizedDescription];
		productPrice = [product.price doubleValue];
		[formatter setLocale:product.priceLocale];
		localizedPrice = [formatter stringFromNumber:product.price];
		
		[ho generateEvent:CND_ONREQUESTRESPONSE withParam:0];
		[ho generateEvent:CND_ONANYREQUESTRESPONSE withParam:0];
	}
}

-(void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
	for(SKPaymentTransaction* transaction in transactions)
	{
		switch (transaction.transactionState)
		{
			case SKPaymentTransactionStatePurchased:
				[productIdentifier release];
				productIdentifier = [[NSString alloc] initWithString:transaction.payment.productIdentifier];
				productQuantity = transaction.payment.quantity;
				[storeReceipt release];
				storeReceipt = [transaction.transactionReceipt base64encode];
				[ho generateEvent:CND_ONPAYMENTPURCHASED withParam:0];
				[ho generateEvent:CND_ONANYPAYMENTPURCHASED withParam:0];
				[[SKPaymentQueue defaultQueue] finishTransaction:transaction];
				break;
				
			case SKPaymentTransactionStateFailed:
				[productIdentifier release];
				productIdentifier = [[NSString alloc] initWithString:transaction.payment.productIdentifier];
				productQuantity = transaction.payment.quantity;
				
				if(transaction.error.code == SKErrorPaymentCancelled)
				{
					[ho generateEvent:CND_ONPAYMENTCANCELED withParam:0];
					[ho generateEvent:CND_ONANYPAYMENTCANCELED withParam:0];
				}
				else
				{
					[ho generateEvent:CND_ONPAYMENTFAILED withParam:0];
					[ho generateEvent:CND_ONANYPAYMENTFAILED withParam:0];
				}
				
				[[SKPaymentQueue defaultQueue] finishTransaction:transaction];
				break;
				
			case SKPaymentTransactionStateRestored:
				[productIdentifier release];
				productIdentifier = [[NSString alloc] initWithString:transaction.payment.productIdentifier];
				productQuantity = transaction.payment.quantity;
				
				[ho generateEvent:CND_ONPAYMENTRESTORED withParam:0];
				[ho generateEvent:CND_ONANYPAYMENTRESTORED withParam:0];
				[[SKPaymentQueue defaultQueue] finishTransaction:transaction];
				break;
				
			default:
				break;
		}
	}
}

-(void)paymentQueue:(SKPaymentQueue *)queue removedTransactions:(NSArray *)transactions
{}



@end
