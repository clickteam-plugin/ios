//----------------------------------------------------------------------------------
//
// CRUNACRTIVEBACKDROP
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

#define ABFLAG_VISIBLE 0x00000001

@interface CRunActiveBackdrop : CRunExtension
{
    int nImages;
    short* imageList;
    int flags;
    int currentImage;	
}
-(int)getNumberOfConditions;
-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version;
-(void)destroyRunObject:(BOOL)bFast;
-(void)displayRunObject:(CRenderer*)renderer;
-(void)getZoneInfos;
-(BOOL)condition:(int)num withCndExtension:(CCndExtension*)cnd;
-(BOOL)cndVisible;
-(void)action:(int)num withActExtension:(CActExtension*)act;
-(void)actHide;
-(void)actShow;
-(void)actSetImage:(CActExtension*)act;
-(void)actSetX:(CActExtension*)act;
-(void)actSetY:(CActExtension*)act;
-(CValue*)expression:(int)num;
-(CValue*)expGetImage;
-(CValue*)expGetX;
-(CValue*)expGetY;

@end
