//----------------------------------------------------------------------------------
//
// CRunMTTandom: MT random object
// fin 3rd feb 2010
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;

#define MTRAND_N  624
#define MTRAND_M  397
#define MTRAND_MATRIX_A  0x9908b0df  
#define TEMPERING_MASK_C  0xefc60000

@interface MTRandomMersenne : NSObject
{
	int mt[MTRAND_N]; // state 
	int mti; // mti==N+1 means mt[N] is not initialized
	int mag01[2];
}
-(int)nextIntEx:(int)n;
-(double)nextDouble:(double)min withParam1:(double)max; 
-(double)nextDoubleEx:(double)min withParam1:(double)max;
-(double)nextDouble;
-(double)nextDoubleEx;
-(void)setSeed:(int*)array length:(int)length;
-(void)setSeed:(int)seed ;

@end

@interface CRunMTRandom : CRunExtension
{
    MTRandomMersenne* rand;	
}

@end
