//----------------------------------------------------------------------------------
//
// CRuniPhoneButton
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;
@class CRenderer;

#define CND_BTNCLICK 0
#define CND_BTNENABLED 1
#define CND_BTNVISIBLE 2
#define ACT_BTNENABLE 0
#define ACT_BTNDISABLE 1
#define ACT_BTNSETTEXT 2
#define ACT_BTNSHOW 3
#define ACT_BTNHIDE 4
#define EXP_BTNGETTEXT 0

@interface CRuniOSButton : CRunExtension
{
	CFontInfo* fontInfo;
	int	fontColor;
	UIButton* button;
	NSString* text;
	int type;
	int vAlign;
	int hAlign;
	short images[4];
	int clickCount;
}
-(int)getNumberOfConditions;
-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version;
-(void)buttonClicked:(id)sender;
-(void)destroyRunObject:(BOOL)bFast;
-(BOOL)condition:(int)num withCndExtension:(CCndExtension*)cnd;
-(BOOL)cndClick;
-(void)action:(int)num withActExtension:(CActExtension*)act;
-(void)displayRunObject:(CRenderer*)renderer;
-(void)setText:(CActExtension*)act;

@end
