//----------------------------------------------------------------------------------
//
// CRunGameCenterLeaderboard
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"
#import "CRunGameCenterConnect.h"
#import "GameKit/GameKit.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;
@class CImage;
@class CESGameCenter;
@class CArrayList;
@class CRun;
@class CESGameCenter;
@class CTextSurface;

@interface CRunGameCenterLeaderboard : CRunExtension <GKLeaderboardViewControllerDelegate, ILeaderboard>
{
    CESGameCenter* gameCenter; 
    int flags;
    short timeScope;
    short NbScores;
    short NameSize;
    CFontInfo* Logfont;
    int colorref;
    NSString* category;
    int action;
    BOOL bScoresReceived;
    BOOL bUpdated;
    CTextSurface* textSurface;
    NSRange range;
    int scoreSentCount;
    int scoresReceivedCount;
    int titleReceivedCount;
    int errorCount;
    int scoreSet;
}
-(void)error;
-(void)scoreSent;
-(void)scoresReceived;
-(void)titleReceived;

@end
