//----------------------------------------------------------------------------------
//
// CRunkcedit
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;

@interface CRunkcedit :  CRunExtension <UITextFieldDelegate, UITextViewDelegate> 
{
	int backColor;
	int textColor;
	int gotoX;
	int gotoY;
	int flags;
	int gotoSpeed;
	CFontInfo* font;
	
	int gotoStartX;
	int gotoStartY;
	int gotoEndX;
	int gotoEndY;
	int gotoSavedX;
	int gotoSavedY;	
	double gotoPlusPosition;
	double gotoPosition;
	BOOL bGoto;
    BOOL bModified;
    BOOL bEditing;
    
	UITextField* textField;
    UITextView* textView;	    
}

@end
