//----------------------------------------------------------------------------------
//
// CRUNCALCRECT
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CCreateObjectInfo;
@class CFile;
@class CValue;
@class CBitmap;

#define ACT_SetFont 0
#define ACT_SetText 1
#define ACT_SetMaxWidth 2
#define ACT_CalcRect 3
#define EXP_GetWidth 0
#define EXP_GetHeight 1

@interface CRunCalcRect : CRunExtension
{
    NSString* text;
    NSString* fontName;
    int fontHeight;
    BOOL fontBold;
    BOOL fontItalic;
    BOOL fontUnderline;
    int maxWidth;
    int calcWidth;
    int calcHeight;	
}
-(void)dealloc;
-(int)getNumberOfConditions;
-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version;
-(void)action:(int)num withActExtension:(CActExtension*)act;
-(CValue*)expression:(int)num;
-(void)CalcRect;
-(CValue*)GetHeight;
-(CValue*)GetWidth;
-(void)SetFont:(NSString*)name withParam1:(int)height andParam2:(int)style;
-(void)SetMaxWidth:(int)width;
-(void)SetText:(NSString*)text;

@end
