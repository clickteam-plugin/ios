//----------------------------------------------------------------------------------
//
// CRunGameCenterLeaderboard
//
//----------------------------------------------------------------------------------
#import "CRunGameCenterAchievements.h"
#import "CRunCamera.h"
#import "CFile.h"
#import "CRunApp.h"
#import "CBitmap.h"
#import "CCreateObjectInfo.h"
#import "CValue.h"
#import "CExtension.h"
#import "CRun.h"
#import "CActExtension.h"
#import "CImageBank.h"
#import "CServices.h"
#import "CImage.h"
#import "CArrayList.h"
#import "CTextSurface.h"
#import "CFont.h"
#import "CFontInfo.h"

#define CND_ACHIEVEMENTSENT 0
#define CND_ACHIEVEMENTSRECEIVED 1
#define CND_ERROR 2
#define CND_DESCRIPTIONSRECEIVED 3
#define CND_LAST 4

#define ACT_SENDACHIEVEMENT 0
#define ACT_GETACHIEVEMENTS 1
#define ACT_DISPLAYDEFAULT 2
#define ACT_LAST 3

#define EXP_GETNACHIEVEMENTS 0
#define EXP_GETIDENTIFIER 1
#define EXP_GETTITLE 2
#define EXP_GETDESCRIPTION1 3
#define EXP_GETDESCRIPTION2 4
#define EXP_GETMAXIMUMPOINTS 5
#define EXP_GETPERCENT 6

#define ACTION_WAITFORGAMECENTER 0
#define ACTION_WAITFORAUTHENTICATION 1
#define ACTION_WAITFORCOMMAND 2
#define ACTION_WAITFORSENDACHIEVEMENT 3
#define ACTION_WAITFORRECEIVEDACHIEVEMENTS 4
#define ACTION_WAITFORRECEIVEDDESCRIPTIONS 4
#define FLAG_SENDACHIEVEMENT 0x0001
#define FLAG_GETACHIEVEMENTS 0x0002
#define FLAG_GETDESCRIPTIONS 0x0004
#define GCA_GETATSTART 0x0001

@implementation CRunGameCenterAchievements

-(int)getNumberOfConditions
{
	return CND_LAST;
}

-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version
{
    achievementSentCount=-1;
    achievementsReceivedCount=-1;
    descriptionsReceivedCount=-1;
    errorCount=-1;
    sendIdentifiers=[[CArrayList alloc] init];
    sendPercents=[[CArrayList alloc] init];
    
    int eFlags=[file readAInt];
    if (eFlags&GCA_GETATSTART)
    {
        flags=FLAG_GETACHIEVEMENTS;
    }
    flags|=FLAG_GETDESCRIPTIONS;
    return YES;
}

-(void)destroyRunObject:(BOOL)bFast
{
    if (gameCenter!=nil)
    {
        [gameCenter setAchievements:nil];        
    }
    [sendIdentifiers clearRelease];
    [sendIdentifiers release];
    [sendPercents release];
}

-(int)handleRunObject
{
    switch(action)
    {
        case ACTION_WAITFORGAMECENTER:
            gameCenter=(CESGameCenter*)[rh getStorage:IDENTIFIER];
            if (gameCenter!=nil)
            {
                [gameCenter setAchievements:self];
                action=ACTION_WAITFORAUTHENTICATION;
            }
            break;
        case ACTION_WAITFORAUTHENTICATION:
            if (gameCenter->localPlayer!=nil)
            {
                if (gameCenter->localPlayer.isAuthenticated)
                {
                    action=ACTION_WAITFORCOMMAND;
                }
            }
            break;
        case ACTION_WAITFORCOMMAND:
            if (flags&FLAG_GETDESCRIPTIONS)
            {
                flags&=~FLAG_GETDESCRIPTIONS;
                action=ACTION_WAITFORRECEIVEDDESCRIPTIONS;
                [gameCenter getDescriptions];
                break;
            }
            if (flags&FLAG_SENDACHIEVEMENT)
            {
                flags&=~FLAG_SENDACHIEVEMENT;
                int n;
                for (n=0; n<[sendIdentifiers size]; n++)
                {
                    [gameCenter sendAchievement:(NSString*)[sendIdentifiers get:n] percent:(int)[sendPercents get:n]];
                }
                [sendIdentifiers clearRelease];
                action=ACTION_WAITFORSENDACHIEVEMENT;
                break;
            }
            if (flags&FLAG_GETACHIEVEMENTS)
            {
                flags&=~FLAG_GETACHIEVEMENTS;
                action=ACTION_WAITFORRECEIVEDACHIEVEMENTS;
                [gameCenter getAchievements];
                break;
            }
            break;
    }
    return 0;
}
            

-(void)achievementSent
{
    achievementSentCount=[ho getEventCount];
    [ho pushEvent:CND_ACHIEVEMENTSENT withParam:0];
    action=ACTION_WAITFORCOMMAND;
}
-(void)descriptionsReceived
{
    action=ACTION_WAITFORCOMMAND;
    descriptionsReceivedCount=[ho getEventCount];
    [ho pushEvent:CND_DESCRIPTIONSRECEIVED withParam:0];    
}
-(void)achievementsReceived
{
    action=ACTION_WAITFORCOMMAND;
    achievementsReceivedCount=[ho getEventCount];
    [ho pushEvent:CND_ACHIEVEMENTSRECEIVED withParam:0];
}
-(void)error
{
    action=ACTION_WAITFORCOMMAND;
    errorCount=[ho getEventCount];
    [ho pushEvent:CND_ERROR withParam:0];
}

-(BOOL)achievementSentCnd
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == achievementSentCount)
	{
		return YES;
	}
	return NO;    
}
-(BOOL)achievementsReceivedCnd
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == achievementsReceivedCount)
	{
		return YES;
	}
	return NO;    
}
-(BOOL)descriptionsReceivedCnd
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == descriptionsReceivedCount)
	{
		return YES;
	}
	return NO;    
}
-(BOOL)errorCnd
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == errorCount)
	{
		return YES;
	}
	return NO;    
}
-(BOOL)condition:(int)num withCndExtension:(CCndExtension *)cnd
{
    switch(num)
    {
        case CND_ACHIEVEMENTSENT:
            return [self achievementSentCnd];
        case CND_ACHIEVEMENTSRECEIVED:
            return [self achievementsReceivedCnd];
        case CND_ERROR:
            return [self errorCnd];
        case CND_DESCRIPTIONSRECEIVED:
            return [self achievementsReceivedCnd];
    }
    return NO;
}


-(void)sendAchievement:(CActExtension*)act
{
    NSString* identifier=[act getParamExpString:rh withNum:0];
    int percent=[act getParamExpression:rh withNum:1];
    [sendIdentifiers add:[[NSString alloc] initWithString:identifier]];
    [sendPercents add:(void*)percent];
    flags|=FLAG_SENDACHIEVEMENT; 
}
-(void)getAchievements
{
    flags|=FLAG_GETACHIEVEMENTS;
}
-(void)displayDefault
{
    if (gameCenter!=nil)
    {
        if (gameCenter->localPlayer!=nil)
        {
            if (gameCenter->localPlayer.isAuthenticated)
            {
                GKAchievementViewController* achievementController=[[GKAchievementViewController alloc] init];
                if (achievementController!=nil)
                {                    
                    [ho->hoAdRunHeader pause];
                    achievementController.achievementDelegate=self;
                    [ho->hoAdRunHeader->rhApp->mainViewController presentModalViewController:achievementController animated:YES];
                }
                [achievementController release];
            }
        }        
    }
}
-(void)achievementViewControllerDidFinish:(GKAchievementViewController*)viewController
{
    [ho->hoAdRunHeader resume];
    [ho->hoAdRunHeader->rhApp->mainViewController dismissModalViewControllerAnimated:YES];
}

-(void)action:(int)num withActExtension:(CActExtension *)act
{
    switch (num)
    {
        case ACT_SENDACHIEVEMENT:
            [self sendAchievement:act];
            break;
        case ACT_GETACHIEVEMENTS:
            [self getAchievements];
            break;
        case ACT_DISPLAYDEFAULT:
            [self displayDefault];
            break;
    }
}


-(CValue*)getNAchievements
{
    if (gameCenter!=nil)
    {
        return [rh getTempValue:[gameCenter getNAchievements]];
    }
    return [rh getTempValue:0];
}
-(CValue*)getTitle
{
    CValue* ret=[rh getTempValue:0];
    [ret forceString:@""];
    NSString* identifier=[[ho getExpParam] getString];
    if (gameCenter!=nil)
    {
        [ret forceString:[gameCenter getATitle:identifier]];
    }
    return ret;
}
-(CValue*)getDescription1
{
    CValue* ret=[rh getTempValue:0];
    [ret forceString:@""];
    NSString* identifier=[[ho getExpParam] getString];
    if (gameCenter!=nil)
    {
        [ret forceString:[gameCenter getADescription1:identifier]];
    }
    return ret;
}
-(CValue*)getDescription2
{
    CValue* ret=[rh getTempValue:0];
    [ret forceString:@""];
    NSString* identifier=[[ho getExpParam] getString];
    if (gameCenter!=nil)
    {
        [ret forceString:[gameCenter getADescription2:identifier]];
    }
    return ret;
}
-(CValue*)getMaximumPoints
{
    CValue* ret=[rh getTempValue:0];
    NSString* identifier=[[ho getExpParam] getString];
    if (gameCenter!=nil)
    {
        [ret forceInt:[gameCenter getAMaximumPoints:identifier]];
    }
    return ret;
}
-(CValue*)getPercent
{
    CValue* ret=[rh getTempValue:0];
    NSString* identifier=[[ho getExpParam] getString];
    if (gameCenter!=nil)
    {
        [ret forceInt:[gameCenter getAPercent:identifier]];
    }
    return ret;
}

-(CValue*)expression:(int)num
{
    switch(num)
    {
        case EXP_GETNACHIEVEMENTS:
            return [self getNAchievements];
        case EXP_GETTITLE:
            return [self getTitle];
        case EXP_GETDESCRIPTION1:
            return [self getDescription1];
        case EXP_GETDESCRIPTION2:
            return [self getDescription2];
        case EXP_GETMAXIMUMPOINTS:
            return [self getMaximumPoints];
        case EXP_GETPERCENT:
            return [self getPercent];
    }
    return nil;
}


@end




