//----------------------------------------------------------------------------------
//
// CRuniOS
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;


@interface CRuniOS : CRunExtension 
{
    int reactivatedCount;
}

@end
