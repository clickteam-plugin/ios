//----------------------------------------------------------------------------------
//
// CRunStringTokenizer
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CArrayList;

@interface CStringTokeniser : NSObject
{
	CArrayList* tokens;
	int numToken;
	
}
-(id)init:(NSString*)text withParam:(NSString*)delimiter;
-(void)dealloc;
-(int)countTokens;
-(NSString*)nextToken;

@end

@interface CRunStringTokenizer : CRunExtension
{
	BOOL Initialised;
	CArrayList* Tokens;
	CArrayList* Tokens2D;	
}
-(int) getNumberOfConditions;
-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version;
-(void)destroyRunObject:(BOOL)bFast;
-(void)clearTokens2D;
-(void)action:(int)num withActExtension:(CActExtension*)act;
-(CValue*)expression:(int)num;

@end
