//----------------------------------------------------------------------------------
//
// CRunkcbutton
//
//----------------------------------------------------------------------------------
#import "CRunkcbutton.h"
#import "CFile.h"
#import "CRunApp.h"
#import "CBitmap.h"
#import "CCreateObjectInfo.h"
#import "CValue.h"
#import "CExtension.h"
#import "CRun.h"
#import "CActExtension.h"
#import "CImageBank.h"
#import "CServices.h"
#import <AudioToolbox/AudioToolbox.h>

#define CND_BOXCHECK 0
#define CND_CLICKED 1
#define CND_BOXUNCHECK 2
#define CND_VISIBLE 3
#define CND_ISENABLED 4
#define CND_ISRADIOENABLED 5
#define CND_LAST 6
#define ACT_CHANGETEXT 0
#define ACT_SHOW 1
#define ACT_HIDE 2
#define ACT_ENABLE 3
#define ACT_DISABLE 4
#define ACT_SETPOSITION 5
#define ACT_SETXSIZE 6
#define ACT_SETYSIZE 7
#define ACT_CHGRADIOTEXT 8
#define ACT_RADIOENABLE 9
#define ACT_RADIODISABLE 10
#define ACT_SELECTRADIO 11
#define ACT_SETXPOSITION 12
#define ACT_SETYPOSITION 13
#define ACT_CHECK 14
#define ACT_UNCHECK 15
#define ACT_SETCMDID 16
#define ACT_SETTOOLTIP 17
#define ACT_LAST 18
#define EXP_GETXSIZE 0
#define EXP_GETYSIZE 1
#define EXP_GETX 2
#define EXP_GETY 3
#define EXP_GETSELECT 4
#define EXP_GETTEXT 5
#define EXP_GETTOOLTIP 6
#define EXP_LAST 7
#define BTNTYPE_PUSHTEXT 0
#define BTNTYPE_CHECKBOX 1
#define BTNTYPE_RADIOBTN 2
#define BTNTYPE_PUSHBITMAP 3
#define BTNTYPE_PUSHTEXTBITMAP 4
#define ALIGN_ONELINELEFT 0
#define ALIGN_CENTER 1
#define ALIGN_CENTERINVERSE 2
#define ALIGN_ONELINERIGHT 3
#define BTN_HIDEONSTART 0x0001
#define BTN_DISABLEONSTART 0x0002
#define BTN_TEXTONLEFT 0x0004
#define BTN_TRANSP_BKD 0x0008
#define BTN_SYSCOLOR 0x0010

@implementation CRunkcbutton

-(int)getNumberOfConditions
{
	return CND_LAST;
}
-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version
{
    // Read in edPtr values
    ho->hoImgWidth = [file readAShort];
    ho->hoImgHeight = [file readAShort];
    buttonType = [file readAShort];
    buttonCount = [file readAShort];
    flags = [file readAInt];
    font = [file readLogFont];
    foreColour = [file readAColor];
    backColour = [file readAColor];
    if ((buttonType != BTNTYPE_PUSHBITMAP) && (buttonType != BTNTYPE_PUSHTEXTBITMAP) && (buttonType != BTNTYPE_PUSHTEXT))
    {
        return YES;
    }
    
    int i;
    for (i = 0; i < 3; i++)
    {
        buttonImages[i] = [file readAShort];
    }
    if ((buttonType == BTNTYPE_PUSHBITMAP) || (buttonType == BTNTYPE_PUSHTEXTBITMAP))
    {
        [ho loadImageList:buttonImages withLength:3];
    }
    if (buttonType==BTNTYPE_PUSHBITMAP)
    {
        ho->hoImgWidth = 1;
        ho->hoImgHeight = 1;
        for (i = 0; i < 3; i++)
        {
            if (buttonImages[i]!=-1)
            {
                CImage* image=[ho->hoAdRunHeader->rhApp->imageBank getImageFromHandle:buttonImages[i]];
                ho->hoImgWidth = max(ho->hoImgWidth, image->width);
                ho->hoImgHeight = max(ho->hoImgHeight, image->height);
            }
        }
    }
    [file readAShort]; // fourth word in img array
    [file readAInt]; // ebtnSecu
    alignImageText = [file readAShort];    
    text=[file readAString];
    
	button=[UIButton buttonWithType:1];
	button.backgroundColor = [UIColor clearColor];
	button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    if (buttonType!=BTNTYPE_PUSHBITMAP)
    {
        [button setTitle:text forState:UIControlStateNormal & UIControlStateHighlighted & UIControlStateSelected];
    }
	[button setTitleColor:getUIColor(foreColour) forState:UIControlStateNormal & UIControlStateHighlighted & UIControlStateSelected];
    
	[rh->rhApp positionUIElement:button withObject:ho];
    
	CImage* img;
	UIImage* uiImg;
	if (buttonImages[0]>=0)
	{
		img=[ho->hoAdRunHeader->rhApp->imageBank getImageFromHandle:buttonImages[0]];
		uiImg=[img getUIImage];
		[button setImage:uiImg forState:UIControlStateNormal];

		img=[ho->hoAdRunHeader->rhApp->imageBank getImageFromHandle:buttonImages[0]];
		uiImg=[img getUIImage];
		[button setImage:uiImg forState:UIControlStateDisabled];
	}
	if (buttonImages[1]>=0)
	{
		img=[ho->hoAdRunHeader->rhApp->imageBank getImageFromHandle:buttonImages[1]];
		uiImg=[img getUIImage];
		[button setImage:uiImg forState:UIControlStateHighlighted];
	}
	if (buttonImages[2]>=0)
	{
		img=[ho->hoAdRunHeader->rhApp->imageBank getImageFromHandle:buttonImages[2]];
		uiImg=[img getUIImage];
		[button setImage:uiImg forState:UIControlStateSelected];
	}
	
	[button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
	[ho->hoAdRunHeader->rhApp->runView addSubview:button];
    
    clickedEvent=-1;
	return YES;
}

-(void)destroyRunObject:(BOOL)bFast
{
	[button removeFromSuperview];
	[font release];
	[text release];
}

-(void)displayRunObject:(CRenderer*)renderer
{
	[rh->rhApp positionUIElement:button withObject:ho];
}

- (void)buttonClicked:(id)sender 
{
	[rh resume];
	if (rh->rh2PauseCompteur==0)
	{
		clickedEvent=[ho getEventCount];
		[ho pushEvent:CND_CLICKED withParam:0];
	}
}

// Conditions
// --------------------------------------------------
-(BOOL)cndClicked
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == clickedEvent)
	{
		return YES;
	}
	return NO;
}
-(BOOL)condition:(int)num withCndExtension:(CCndExtension*)cnd
{
	switch (num)
	{
		case CND_CLICKED:
			return [self cndClicked];
        case CND_VISIBLE:
            return !button.hidden;
        case CND_ISENABLED:
            return YES;
	}        
	return NO;
}

// Actions
// -------------------------------------------------
-(void)actChangeText:(CActExtension*)act
{
    [text release];
    text=[act getParamExpString:rh withNum:0];
    [button setTitle:text forState:UIControlStateNormal & UIControlStateHighlighted & UIControlStateSelected];
}
-(void)actSetPosition:(CActExtension*)act
{
    unsigned int pos=[act getParamPosition:rh withNum:0];
    ho->hoX=HIWORD(pos)-rh->rhWindowX;
    ho->hoY=LOWORD(pos)-rh->rhWindowY;
	[rh->rhApp positionUIElement:button withObject:ho];
}
-(void)actSetXPosition:(CActExtension*)act
{
    ho->hoX=[act getParamExpression:rh withNum:0]-rh->rhWindowX;
	[rh->rhApp positionUIElement:button withObject:ho];
}
-(void)actSetYPosition:(CActExtension*)act
{
    ho->hoY=[act getParamExpression:rh withNum:0]-rh->rhWindowY;
	[rh->rhApp positionUIElement:button withObject:ho];
}
-(void)actSetXSize:(CActExtension*)act
{
    ho->hoImgWidth=[act getParamExpression:rh withNum:0];
	[rh->rhApp positionUIElement:button withObject:ho];
}
-(void)actSetYSize:(CActExtension*)act
{
    ho->hoImgHeight=[act getParamExpression:rh withNum:0];
	[rh->rhApp positionUIElement:button withObject:ho];
}
-(void)action:(int)num withActExtension:(CActExtension*)act
{
	switch (num)
	{        
        case ACT_CHANGETEXT:
            [self actChangeText:act];
            break;
        case ACT_SHOW:
            button.hidden=NO;
            break;
        case ACT_HIDE:
            button.hidden=YES;
            break;
        case ACT_SETPOSITION:
            [self actSetPosition:act];
            break;
        case ACT_SETXSIZE:
            [self actSetXSize:act];
            break;
        case ACT_SETYSIZE:
            [self actSetYSize:act];
            break;
        case ACT_SETXPOSITION:
            [self actSetXPosition:act];
            break;
        case ACT_SETYPOSITION:
            [self actSetYPosition:act];
            break;
            
    }
}

// Expressions
// ------------------------------------------------------------
-(CValue*)expression:(int)num
{
    CValue* ret;
    switch(num)
    {
        case EXP_GETXSIZE:
            return [rh getTempValue:ho->hoImgWidth];
        case EXP_GETYSIZE:
            return [rh getTempValue:ho->hoImgHeight];
        case EXP_GETX:
            return [rh getTempValue:ho->hoX];
        case EXP_GETY:
            return [rh getTempValue:ho->hoY];
        case EXP_GETTEXT:
            ret=[rh getTempValue:0];
            [ret forceString:text];
            return ret;            
    }
    return nil;
}
@end
