//----------------------------------------------------------------------------------
//
// CRunkcbutton
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;
@class CImage;


@interface CRunCamera : CRunExtension <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    BOOL bAllowsEditing;
    int camFlags;
    UIImage* imageToSave;
    CImage* image;
}

@end
