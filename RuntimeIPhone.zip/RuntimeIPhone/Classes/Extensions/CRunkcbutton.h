//----------------------------------------------------------------------------------
//
// CRunkcbutton
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;


@interface CRunkcbutton : CRunExtension
{
    UIButton* button;

    short buttonImages[3];
    short buttonType;
    short buttonCount;
    int flags;
    short alignImageText;
    CFontInfo* font;
    int foreColour;
    int backColour;
    int clickedEvent; 
    NSString* text;
}

@end
