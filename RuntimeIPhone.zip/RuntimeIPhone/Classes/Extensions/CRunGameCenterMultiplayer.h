//----------------------------------------------------------------------------------
//
// CRunGameCenterLeaderboard
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"
#import "CRunGameCenterConnect.h"
#import "GameKit/GameKit.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;
@class CImage;
@class CESGameCenter;
@class CArrayList;
@class CRun;
@class CESGameCenter;
@class CTextSurface;

@interface CRunGameCenterMultiplayer : CRunExtension <IMultiplayer>
{
    CESGameCenter* gameCenter;
    int action;
    int flags;
    BOOL bOK;
    int minPlayers;
    int maxPlayers;
    int group;
    int matchStartedCount;
    int matchChangedCount;
    int playerConnectedCount;
    int playerDisconnectedCount;
    int dataReceivedCount;
    int errorCount;
}

@end
