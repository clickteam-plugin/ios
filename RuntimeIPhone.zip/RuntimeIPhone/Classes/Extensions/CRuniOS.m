//----------------------------------------------------------------------------------
//
// CRuniOS
//
//----------------------------------------------------------------------------------
#import "CRuniOS.h"
#import "CFile.h"
#import "CRunApp.h"
#import "CBitmap.h"
#import "CCreateObjectInfo.h"
#import "CValue.h"
#import "CExtension.h"
#import "CRun.h"
#import "CActExtension.h"
#import <AudioToolbox/AudioToolbox.h>
#import "CIAdViewController.h"
#import "CRunApp.h"

#define CND_ADOK 0
#define CND_REACTIVATED 1
#define CND_DEACTIVATED 2
#define CND_LAST 3
#define ACT_OPENURL 0
#define ACT_VIBRATE 1
#define ACT_AUTHORISEIAD 2

@implementation CRuniOS

-(int)getNumberOfConditions
{
	return CND_LAST;
}
-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version
{
    reactivatedCount=-1;
    ho->hoAdRunHeader->rhApp->iOSObject=ho;
    return YES;
}
-(int)handleRunObject
{
    return REFLAG_ONESHOT;
}
-(void)destroyRunObject:(BOOL)bFast
{
    ho->hoAdRunHeader->rhApp->iOSObject=nil;
}

// Conditions
// -------------------------------------------------
-(BOOL)reactivatedCnd
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == reactivatedCount)
	{
		return YES;
	}
	return NO;    
}

-(BOOL)condition:(int)num withCndExtension:(CCndExtension *)cnd
{
    switch(num)
    {
        case CND_ADOK:
            if (rh->rhApp->iAdViewController!=nil)
            {
                return rh->rhApp->iAdViewController->bAdOK;
            }
            return YES;
        case CND_REACTIVATED:
            return [self reactivatedCnd];
        case CND_DEACTIVATED:
            return YES;
    }
    return NO;
}
// Actions
// -------------------------------------------------

-(void)actOpenURL:(CActExtension*)act
{
    NSString* url=[act getParamExpString:rh withNum:0];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
}
-(void)actAuthoriseIAd:(CActExtension*)act
{
    BOOL bOn=[act getParamExpression:rh withNum:0];
    if (rh->rhApp->iAdViewController!=nil)
    {
        [rh->rhApp->iAdViewController setAdAuthorised:bOn];
    }
}
-(void)action:(int)num withActExtension:(CActExtension*)act
{
    switch(num)
    {
        case ACT_OPENURL:
            [self actOpenURL:act];
            break;
        case ACT_VIBRATE:
            AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
            break;
        case ACT_AUTHORISEIAD:
            [self actAuthoriseIAd:act];
            break;
    }
}
@end
