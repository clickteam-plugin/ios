//----------------------------------------------------------------------------------
//
// CRuniPhoneMultipleEdit
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;

#define FLAG_TVGOTOON 0x0001
#define FLAG_TVVISIBLE 0x0002
#define FLAG_TVSCROLL 0x0004
#define FLAG_TVEDITABLE 0x0008

#define CND_TVENTEREDIT 0
#define CND_TVQUITEDIT 1
#define CND_TVISVISIBLE 2
#define CND_TVEDITABLE 3
#define ACT_TVBACKCOLOR 0
#define ACT_TVSHOW 1
#define ACT_TVHIDE 2
#define ACT_TVEDITABLE 3
#define ACT_TVNOTEDITABLE 4
#define ACT_TVSETTEXT 5
#define EXP_TVGETTEXT 0

@interface CRuniOSMultipleEdit : CRunExtension <UITextViewDelegate> 
{
	int backColor;
	int textColor;
	int keyboard;
	int ret;
	int align;
	int gotoX;
	int gotoY;
	short flags;
	int gotoSpeed;
	CFontInfo* font;
	NSString* text;
	
	int gotoStartX;
	int gotoStartY;
	int gotoEndX;
	int gotoEndY;
	int gotoSavedX;
	int gotoSavedY;	
	double gotoPlusPosition;
	double gotoPosition;
	BOOL bGoto;
	
	int enterEditCount;
	int quitEditCount;
	BOOL bEditing;
	UITextView* textView;	
}
-(void)actBackColor:(int)color;
-(BOOL)cndEnterEdit;
-(BOOL)cndQuitEdit;

@end
