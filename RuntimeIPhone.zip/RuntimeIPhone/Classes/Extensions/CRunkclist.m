//
//  CRunkclist.m
//  RuntimeIPhone
//
//  Created by Anders Riggelsen on 1/10/11.
//  Copyright 2011 Clickteam. All rights reserved.
//

#import "CRunExtension.h"
#import "CExtension.h"
#import "CRun.h"
#import "CFile.h"
#import "CCreateObjectInfo.h"
#import "CBitmap.h"
#import "CMask.h"
#import "CActExtension.h"
#import "CCndExtension.h"
#import "CFontInfo.h"
#import "CRect.h"
#import "CImage.h"
#import "CValue.h"
#import "CRunkclist.h"
#import "CFile.h"
#import "CRunApp.h"
#import "CServices.h"
#import "CArrayList.h"
#import "CRunView.h"

@implementation CRunkclist

// Flags
#define LIST_FREEFLAG 0x0001
#define LIST_VSCROLLBAR 0x0002
#define LIST_SORT 0x0004
#define LIST_BORDER 0x0008
#define LIST_HIDEONSTART 0x0010
#define LIST_SYSCOLOR 0x0020
#define LIST_3DLOOK 0x0040
#define LIST_SCROLLTONEWLINE 0x0080
#define LIST_JUSTCREATED 0x8000
// Condition identifiers
#define CND_VISIBLE 0
#define CND_ENABLE 1
#define CND_DOUBLECLICKED 2
#define CND_SELECTIONCHANGED 3
#define CND_HAVEFOCUS 4
#define CND_LAST 5
// Action identifiers
#define ACT_LOADLIST 0
#define ACT_LOADDRIVESLIST 1
#define ACT_LOADDIRECTORYLIST 2
#define ACT_LOADFILESLIST 3
#define ACT_SAVELIST 4
#define ACT_RESET 5
#define ACT_ADDLINE 6
#define ACT_INSERTLINE 7
#define ACT_DELLINE 8
#define ACT_SETCURRENTLINE 9
#define ACT_SHOW 10
#define ACT_HIDE 11
#define ACT_ACTIVATE 12
#define ACT_ENABLE 13
#define ACT_DISABLE 14
#define ACT_SETPOSITION 15
#define ACT_SETXPOSITION 16
#define ACT_SETYPOSITION 17
#define ACT_SETSIZE 18
#define ACT_SETXSIZE 19
#define ACT_SETYSIZE 20
#define ACT_DESACTIVATE 21
#define ACT_SCROLLTOTOP 22
#define ACT_SCROLLTOLINE 23
#define ACT_SCROLLTOEND 24
#define ACT_SETCOLOR 25
#define ACT_SETBKDCOLOR 26
#define ACT_LOADFONTSLIST 27
#define ACT_LOADFONTSIZESLIST 28
#define ACT_SETLINEDATA 29
#define ACT_CHANGELINE 30
#define ACT_LAST 31
// Expression identifiers
#define EXP_GETSELECTINDEX 0
#define EXP_GETSELECTTEXT 1
#define EXP_GETSELECTDIRECTORY 2
#define EXP_GETSELECTDRIVE 3
#define EXP_GETLINETEXT 4
#define EXP_GETLINEDIRECTORY 5
#define EXP_GETLINEDRIVE 6
#define EXP_GETNBLINE 7
#define EXP_GETXPOSITION 8
#define EXP_GETYPOSITION 9
#define EXP_GETXSIZE 10
#define EXP_GETYSIZE 11
#define EXP_GETCOLOR 12
#define EXP_GETBKDCOLOR 13
#define EXP_FINDSTRING 14
#define EXP_FINDSTRINGEXACT 15
#define EXP_GETLASTINDEX 16
#define EXP_GETLINEDATA 17
#define EXP_LAST 18



-(int)getNumberOfConditions
{
	return CND_LAST;
}

-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version
{
	list = [[CArrayList alloc] init];
	
	selectionChangedIgnore = NO;
	ho->hoImgWidth = [file readAShort];
	ho->hoImgHeight = [file readAShort];
	oldWidth=ho->hoImgWidth;
	oldHeight=ho->hoImgHeight;
	
	// This is a 16-bit logfont structure
	listFontInfo = [file readLogFont16];
	
	listFontFore = [file readAColor];
	[file readAStringWithSize:40];

	[file skipBytes:16*4];
	listFontBack = [file readAColor];
	flags = [file readAInt];
	
	int lineNumbers = [file readAShort];
	
	// If TRUE, indexes are 1-based. So the index offset is -1 when true
	// (subtract one from value provided) and 0 when false (no modification)
	indexOffset = ([file readAInt] == 1) ? -1 : 0;
	
	// Skip three longs (lSecu)
	[file skipBytes:4*3];
	
	// Creates the list
	sort = ((flags & LIST_SORT) !=0 );
	scrollToNewLine = ((flags & LIST_SCROLLTONEWLINE) !=0 );
	hideOnStart = ((flags&LIST_HIDEONSTART)!=0);
	
	// Insert the strings
	BOOL selectLine = NO;
	while (lineNumbers > 0)
	{
		NSString* line = [file readAString];
		[self actAddLine:line];
		lineNumbers--;
		selectLine = YES;
	}
	
	doubleClickedEvent=-1;
	selectionChangedEvent=-1;
	lastIndex=0;
	runView = rh->rhApp->runView;

	pickerView = [[UIPickerView alloc] init];
	pickerView.backgroundColor = [UIColor colorWithRed:getR(listFontBack) green:getG(listFontBack) blue:getB(listFontBack) alpha:1.0];
	CGSize ps = [pickerView sizeThatFits:CGSizeZero];
	pickerView.frame = CGRectMake(ho->hoX - rh->rhWindowX, ho->hoY - rh->rhWindowY, ps.width-1, ps.height);
	pickerView.hidden = hideOnStart;
	pickerView.showsSelectionIndicator = YES;
	pickerView.dataSource = self;
	pickerView.delegate = self;
	[runView addSubview:pickerView];
	return false;
}

-(int)handleRunObject;
{
	return REFLAG_ONESHOT;
}

-(void)destroyRunObject:(BOOL)bFast;
{
	pickerView.delegate = nil;
	pickerView.dataSource = nil;
	[pickerView removeFromSuperview];
	[pickerView release];
	
	[list clearRelease];
	[list release];
}

-(void)displayRunObject:(CRenderer*)renderer
{
	CGSize ps = [pickerView sizeThatFits:CGSizeZero];
	
	ho->hoX = 0;
	ho->hoImgWidth = ps.width;
	ho->hoImgHeight = ps.height;
	
	[rh->rhApp positionUIElement:pickerView withObject:ho];
}



-(BOOL)condition:(int)num withCndExtension:(CCndExtension*)cnd
{
	switch (num)
	{
		case CND_VISIBLE:
			return isVisible;
		case CND_ENABLE:
			return isEnabled;
		case CND_DOUBLECLICKED:
			return false;
		case CND_SELECTIONCHANGED:
			return [self cndSelectionChanged];
		case CND_HAVEFOCUS:
			return hasFocus;
	}
	return false;
}


-(BOOL)cndSelectionChanged
{
	// This is a true event, so was pushed
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
		return YES;

	// Event occured this event loop
	if (selectionChangedEvent == [ho getEventCount])
		return YES;
	return NO;
}



-(void)action:(int)num withActExtension:(CActExtension*)act
{
	switch (num)
	{
		case ACT_LOADLIST:
            [self actLoadList:act];
            break;
		case ACT_SAVELIST:
            [self actSaveList:act];
            break;
		case ACT_LOADDRIVESLIST:
		case ACT_LOADDIRECTORYLIST:
		case ACT_LOADFILESLIST:
		case ACT_ACTIVATE:
		case ACT_ENABLE:
		case ACT_DISABLE:
		case ACT_DESACTIVATE:
		case ACT_SETCOLOR:
		case ACT_SETBKDCOLOR:
			break;
			
		case ACT_RESET:
			[self actReset];
			break;
		case ACT_ADDLINE:
			[self actAddLine:[act getParamExpString:rh withNum:0]];
			break;
		case ACT_INSERTLINE:
		{
			int index = [act getParamExpression:rh withNum:0];
			NSString* string = [act getParamExpString:rh withNum:1];
			[self actInsertLine:string atIndex:index];
			break;
		}
		case ACT_DELLINE:
			[self actDelLine:[act getParamExpression:rh withNum:0]];
			break;
		case ACT_SETCURRENTLINE:
			[self actSetCurrentLine:[act getParamExpression:rh withNum:0]];
			break;
		case ACT_SHOW:
			pickerView.hidden = NO;
			break;
		case ACT_HIDE:
			pickerView.hidden = YES;
			break;
		case ACT_SETPOSITION:
			ho->hoX = [act getParamExpression:rh withNum:0];
			ho->hoY = [act getParamExpression:rh withNum:1];
			break;
		case ACT_SETXPOSITION:
			ho->hoX = [act getParamExpression:rh withNum:0];
			break;
		case ACT_SETYPOSITION:
			ho->hoY = [act getParamExpression:rh withNum:0];
			break;
		case ACT_SETSIZE:
			ho->hoImgWidth = [act getParamExpression:rh withNum:0];
			ho->hoImgHeight = [act getParamExpression:rh withNum:0];
			break;
		case ACT_SETXSIZE:
			ho->hoImgWidth = [act getParamExpression:rh withNum:0];
			break;
		case ACT_SETYSIZE:
			ho->hoImgHeight = [act getParamExpression:rh withNum:0];
			break;
		case ACT_SCROLLTOTOP:
			[pickerView selectRow:0 inComponent:0 animated:YES];
			break;
		case ACT_SCROLLTOLINE:
			[pickerView selectRow:[act getParamExpression:rh withNum:0] inComponent:0 animated:YES];
			break;
		case ACT_SCROLLTOEND:
			[pickerView selectRow:[list size]-1 inComponent:0 animated:YES];
			break;
		case ACT_LOADFONTSLIST:
			break;
		case ACT_LOADFONTSIZESLIST:
			break;
		case ACT_SETLINEDATA:
		{
			int index = [act getParamExpression:rh withNum:0];
			int data = [act getParamExpression:rh withNum:1];
			[self actSetLineData:data forLine:index];
			break;
		}
		case ACT_CHANGELINE:
		{
			int index = [act getParamExpression:rh withNum:0];
			NSString* string = [act getParamExpString:rh withNum:1];
			[self actChangeLine:index toString:string];
			break;
		}
	}
}
-(NSString*)cleanPCPath:(NSString*)srce
{
	NSRange searchRange;
	searchRange.location=0;
	searchRange.length=[srce length];
	NSRange index=[srce rangeOfString:@"\\" options:NSBackwardsSearch range:searchRange];
	if (index.location!=NSNotFound)
	{
		NSString* temp=[srce substringFromIndex:index.location+1];
		return temp;
	}
	return srce;
}

-(void)actLoadList:(CActExtension*)act
{
    NSString* fileName=[act getParamFilename:rh withNum:0];
    fileName=[self cleanPCPath:fileName];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *appFile = [documentsDirectory stringByAppendingPathComponent:fileName];
    NSError* errorPtr;
    NSData *myData = [[[NSData alloc] initWithContentsOfFile:appFile options:NSMappedRead error:&errorPtr] autorelease];
    if ([myData length]==0)
    {
        NSString* name=fileName;
        NSString* extension=@"txt";
        NSRange range=[fileName rangeOfString:@"."];
        if (range.location!=NSNotFound)
        {
            name=[fileName substringToIndex:range.location];
            extension=[fileName substringFromIndex:range.location+1];
        }
        appFile=[[NSBundle mainBundle] pathForResource:name ofType:extension];
        @try 
        {
            myData = [[[NSData alloc] initWithContentsOfFile:appFile options:NSMappedRead error:&errorPtr] autorelease];
        }
        @catch (NSException *exception) 
        {
            return;
        }
    }
    if ([myData length]!=0)
    {
        [list clearRelease];
        [pickerView reloadComponent:0];
        currentLine = 0;

        CFile* file=[[CFile alloc] initWithNSDataNoRelease:myData];
        while([file IsEOF]==NO)
        {
            NSString* string=[file readAStringEOL];
            CListItem* item = [[CListItem alloc] initWithString:string andData:0];
            [list add:(void*)item];
            lastIndex = [list size]-1;
            [string release];
        };
        [file release];
        [pickerView reloadComponent:0];
    }
}

-(void)actSaveList:(CActExtension*)act
{
    NSString* fileName=[act getParamFilename:rh withNum:0];
    fileName=[self cleanPCPath:fileName];
    
    int n;
    int length=0;  
    NSString* s;
    for (n=0; n<[list size]; n++)
    {
        s=((CListItem*)[list get:n])->string;
        length+=[s length]+1;
    }
    char* buffer=(char*)malloc(length*2);
    char* ptr=buffer;
    for (n=0; n<[list size]; n++)
    {
        s=((CListItem*)[list get:n])->string;
        [s getCString:ptr maxLength:[s length]*2+1 encoding:NSWindowsCP1251StringEncoding];
        ptr+=strlen(ptr);
        *(ptr++)=10;
    }
    length=ptr-buffer;
    
    NSData* data=[[NSData alloc] initWithBytes:buffer length:length];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *appFile = [documentsDirectory stringByAppendingPathComponent:fileName];
    [data writeToFile:appFile atomically:NO];
    [data release];
    free(buffer);
}

-(void)actReset
{
	[list clearRelease];
	currentLine = 0;
	[pickerView reloadComponent:0];
}

-(void)actAddLine:(NSString*)string
{
	CListItem* item = [[CListItem alloc] initWithString:string andData:0];
	[list add:(void*)item];
	lastIndex = [list size]-1;
	
	if(sort)
		[list sortCListItems];
	
	[pickerView reloadComponent:0];
}

-(void)actInsertLine:(NSString*)string atIndex:(int)index
{
	index = clamp(index + indexOffset, 0, [list size]);
	CListItem* item = [[CListItem alloc] initWithString:string andData:0];
	[list addIndex:index object:(void*)item];
	lastIndex=index;
	
	if(sort)
		[list sortCListItems];
	
	[pickerView reloadComponent:0];
}

-(void)actChangeLine:(int)index toString:(NSString*)string
{
	index += indexOffset;
	if (index >= 0 && index < [list size]-1)
	{
		CListItem* item = [list get:index];
		[item->string release];
		item->string = [[NSString alloc] initWithString:string];
	}
	
	if(sort)
		[list sortCListItems];
	
	[pickerView reloadComponent:0];
}

-(void)actDelLine:(int)index
{
	index += indexOffset;
	if (index < 0 || index >= [list size])
		return;
	[list removeIndexRelease:index];
	[pickerView reloadComponent:0];
}

-(void)actSetCurrentLine:(int)index
{
	index = clamp(index+indexOffset, 0, [list size]);
	currentLine = index;
	[pickerView selectRow:index inComponent:0 animated:NO];
}


-(void)actSetLineData:(int)data forLine:(int)index
{
	index += indexOffset;
	if (index >= 0 && index <= [list size]-1)
	{
		CListItem* item = [list get:index];
		item->data = data;
	}
}



-(CValue*)expression:(int)num
{
	switch (num)
	{
		case EXP_GETSELECTINDEX:
		{
			int selection = currentLine;
			if(selection >= 0)
				selection -= indexOffset;
			return [rh getTempValue:selection];
		}
		case EXP_GETSELECTTEXT:
		{
			if(currentLine < 0 || currentLine >= [list size])
				return [rh getTempString:@""];
			
			CListItem* item = [list get:currentLine];
			return [rh getTempString:item->string];
		}
		case EXP_GETNBLINE:
			return [rh getTempValue:[list size]];
		case EXP_GETLINETEXT:
			return [self expGetLineText:[[ho getExpParam] getInt]];
		case EXP_GETXPOSITION:
			return [rh getTempValue:ho->hoX];
		case EXP_GETYPOSITION:
			return [rh getTempValue:ho->hoY];
		case EXP_GETXSIZE:
			return [rh getTempValue:ho->hoImgWidth];
		case EXP_GETYSIZE:
			return [rh getTempValue:ho->hoImgHeight];
		case EXP_GETCOLOR:
			return [rh getTempValue:listFontFore];
		case EXP_GETBKDCOLOR:
			return [rh getTempValue:listFontBack];
		case EXP_FINDSTRING:
		{
			NSString* searchString = [[ho getExpParam] getString];
			int startIndex = [[ho getExpParam] getInt];
			return [self expFindString:searchString startingAt:startIndex];
		}
		case EXP_FINDSTRINGEXACT:
		{
			NSString* searchString = [[ho getExpParam] getString];
			int startIndex = [[ho getExpParam] getInt];
			return [self expFindStringExact:searchString startingAt:startIndex];
		}
		case EXP_GETLASTINDEX:
			return [rh getTempValue:lastIndex];
		case EXP_GETLINEDATA:
			return [self expGetLineData:[[ho getExpParam] getInt]];
			
		case EXP_GETSELECTDIRECTORY:
		case EXP_GETSELECTDRIVE:
		case EXP_GETLINEDIRECTORY:
		case EXP_GETLINEDRIVE:
			break;
	}
	return [rh getTempString:@""];
}


-(CValue*)expGetLineText:(int)index
{
	index += indexOffset;
	if(index < 0 || index >= [list size])
		return [rh getTempString:@""];
	
	CListItem* item = [list get:index];
	return [rh getTempString:item->string];
}

-(CValue*)expFindString:(NSString*)string startingAt:(int)startIndex
{
	if (startIndex > -1)
		startIndex += indexOffset;
	if ((startIndex < 0) || (startIndex >= [list size]))
		startIndex = 0;
	int ret = [list findString:string startingAt:startIndex];
	if (ret>=0)
		ret-=indexOffset;
	return [rh getTempValue:ret];	 
}

-(CValue*)expFindStringExact:(NSString*)string startingAt:(int)startIndex
{
	if (startIndex > -1)
		startIndex += indexOffset;
	if ((startIndex < 0) || (startIndex >= [list size]))
		startIndex = 0;
	int ret = [list findStringExact:string startingAt:startIndex];
	if (ret>=0)
		ret-=indexOffset;
	return [rh getTempValue:ret];
}

-(CValue*)expGetLineData:(int)index
{
	if(currentLine < 0 || currentLine >= [list size])
		return [rh getTempValue:0];
	
	CListItem* item = [list get:currentLine];
	return [rh getTempValue:item->data];
}


//PickerView delegates
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView*)pickerView
{
	return 1;
}

-(void)pickerView:(UIPickerView*)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	currentLine = row;
	[ho pushEvent:CND_SELECTIONCHANGED withParam:0];
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return (NSInteger)[list size];
}

-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	CListItem* item = (CListItem*)[list get:row];
	
	//Prevent reading any nulls (should not happen)
	if (item == nil || (item != nil && item->string == nil))
		return [[NSString stringWithString:@""] retain];
	
	return [[NSString stringWithString:item->string] retain];
}


@end

