//----------------------------------------------------------------------------------
//
// CRUNACCELEROMETER iPhone accelerometers
//
//----------------------------------------------------------------------------------
#import "CRunAccelerometer.h"
#import "CFile.h"
#import "CRunApp.h"
#import "CBitmap.h"
#import "CCreateObjectInfo.h"
#import "CValue.h"
#import "CExtension.h"
#import "CRun.h"
#import "CCndExtension.h"

@implementation CRunAccelerometer

-(int)getNumberOfConditions
{
	return 1;
}

-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version
{
	[ho->hoAdRunHeader->rhApp startAccelerometer];
	orientationCount=-1;

	UIDevice* device=[UIDevice currentDevice];
	oldOrientation=device.orientation;
	return YES;
}

-(void)destroyRunObject:(BOOL)bFast
{
	[ho->hoAdRunHeader->rhApp endAccelerometer];
}

-(int)handleRunObject
{
	UIDevice* device=[UIDevice currentDevice];
	int orientation=device.orientation;
	if (orientation!=oldOrientation)
	{
		oldOrientation=orientation;
		orientationCount=[ho getEventCount];
		[ho pushEvent:CND_ORIENTATIONCHANGED withParam:0];
	}
	return 0;
}
// Conditions
// -----------------------------------------------
-(BOOL)condition:(int)num withCndExtension:(CCndExtension*)cnd
{
	if (num==CND_ORIENTATIONCHANGED)
	{
		return [self orientationChanged];
	}
	return NO;
}
-(BOOL)orientationChanged
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == orientationCount)
	{
		return YES;
	}
	return NO;
}
// Expressions
// --------------------------------------------
-(CValue*)expression:(int)num
{
	double ret=0.0;
	
	switch (num)
	{
		case EXP_XDIRECT:
			ret=ho->hoAdRunHeader->rhApp->accX;
			break;
		case EXP_YDIRECT:
			ret=ho->hoAdRunHeader->rhApp->accY;
			break;
		case EXP_ZDIRECT:
			ret=ho->hoAdRunHeader->rhApp->accZ;
			break;
		case EXP_XGRAVITY:
			ret=ho->hoAdRunHeader->rhApp->filteredAccX;
			break;
		case EXP_YGRAVITY:
			ret=ho->hoAdRunHeader->rhApp->filteredAccY;
			break;
		case EXP_ZGRAVITY:
			ret=ho->hoAdRunHeader->rhApp->filteredAccZ;
			break;
		case EXP_XINSTANT:
			ret=ho->hoAdRunHeader->rhApp->instantAccX;
			break;
		case EXP_YINSTANT:
			ret=ho->hoAdRunHeader->rhApp->instantAccY;
			break;
		case EXP_ZINSTANT:
			ret=ho->hoAdRunHeader->rhApp->instantAccZ;
			break;
		case EXP_ORIENTATION:
		{
			UIDevice* device=[UIDevice currentDevice];
			return [rh getTempValue:device.orientation];
		}			
	}
	CValue* v=[rh getTempValue:0];
	[v forceDouble:ret];
	return v;
}


@end
