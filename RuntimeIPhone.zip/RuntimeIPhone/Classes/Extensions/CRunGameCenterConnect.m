//----------------------------------------------------------------------------------
//
// CRunGameCenterConnect
//
//----------------------------------------------------------------------------------
#import "CRunGameCenterConnect.h"
#import "CRunCamera.h"
#import "CFile.h"
#import "CRunApp.h"
#import "CBitmap.h"
#import "CCreateObjectInfo.h"
#import "CValue.h"
#import "CExtension.h"
#import "CRun.h"
#import "CActExtension.h"
#import "CImageBank.h"
#import "CServices.h"
#import "CImage.h"
#import "CArrayList.h"

#define CND_LOCALPLAYERCON 0
#define CND_LOCALPLAYEROK 1
#define CND_FRIENDSLOADED 2
#define CND_INVITATIONSSENT 3
#define CND_LAST 4
#define ACT_AUTHENTICATE 0
#define ACT_LOADFRIENDS 1
#define ACT_RESETINVITATIONS 2
#define ACT_ADDINVITATION 3
#define ACT_SENDINVITATIONS 4
#define ACT_LAST 2
#define EXP_LPALIAS 0
#define EXP_LPID 1
#define EXP_NUMOFFRIENDS 2
#define EXP_FRIENDALIAS 3
#define EXP_FRIENDID 4
#define EXP_LAST 5


@implementation CESGameCenter

-(id)init:(id<IConnect>)c rh:(CRun*)rh
{
    connect=c;
    rhPtr=rh;
    
    // Checks if the API is available
    BOOL localPlayerClassAvailable=(NSClassFromString(@"GKLocalPlayer"))!=nil;
    NSString* reqSysVer=@"4.1";
    NSString* curSysVer=[[UIDevice currentDevice] systemVersion];
    BOOL osVersionSupported=([curSysVer compare:reqSysVer options:NSNumericSearch]!=NSOrderedAscending);    
    bAPIAvailable=(localPlayerClassAvailable&&osVersionSupported);
    
    localPlayer=nil;
    if (bAPIAvailable)
    {
        localPlayer=[GKLocalPlayer localPlayer];
    }
    
    friendsAlias=nil;
    friendsID=nil;
    nEntries=0;
    playerIndex=-1;
    
    return self;
}
-(void)dealloc
{
    if (friendsAlias!=nil)
    {
        [friendsAlias clearRelease];
        [friendsAlias release];
    }
    if (friendsID!=nil)
    {
        [friendsID clearRelease];
        [friendsID release];
    }
    if (lbScores!=nil)
    {
        [lbScores release];
    }
    if (lbNames!=nil)
    {
        [lbNames clearRelease];
        [lbNames release];
    }
    if (achievements!=nil)
    {
        [achievements clearRelease];
        [achievements release];
    }
    if (playerData!=nil)
    {
        [playerData release];
    }
    if (match!=nil)
    {
        [match release];
    }
    [super dealloc];
}
-(void)setConnect:(id<IConnect>)c
{
    connect=c;
}
-(void)setLeaderboard:(id<ILeaderboard>)c
{
    leader=c;
}
-(void)setAchievements:(id<IAchievements>)c
{
    achievementsClass=c;
}
-(void)setMultiplayer:(id<IMultiplayer>)m
{
    multiplayer=m;
    if (m!=nil)
    {
        [GKMatchmaker sharedMatchmaker].inviteHandler=^(GKInvite* acceptedInvite, NSArray* playersToInvite)
        {
            if (acceptedInvite)
            {
                GKMatchmakerViewController* mmvc=[[[GKMatchmakerViewController alloc] initWithInvite:acceptedInvite] autorelease];
                mmvc.matchmakerDelegate=self;
                [rhPtr->rhApp->mainViewController presentModalViewController:mmvc animated:YES];
            }
        };
    }
}
-(void)authenticate
{
    if (localPlayer!=nil)
    {
        if (!localPlayer.isAuthenticated)
        {
            [localPlayer authenticateWithCompletionHandler:^(NSError* error)
             {
                 if (localPlayer.isAuthenticated)
                 {
                     if (connect!=nil)
                     {
                         [connect authenticated];
                     }
                 }
             }
             ];
        }
    }
}
-(void)loadFriends
{
    if (friendsAlias!=nil)
    {
        [friendsAlias clearRelease];
        [friendsAlias release];
        friendsAlias=nil;
    }
    if (friendsID!=nil)
    {
        [friendsID clearRelease];
        [friendsID release];
        friendsID=nil;
    }
    if (localPlayer!=nil)
    {
        if (localPlayer.isAuthenticated)
        {
            [localPlayer loadFriendsWithCompletionHandler:^(NSArray* friends, NSError* error)
             {
                 if (friends!=nil)
                 {
                     int n;
                     for (n=0; n<[friends count]; n++)
                     {
                         GKPlayer* player=(GKPlayer*)[friends objectAtIndex:n];
                         [friendsAlias add:[[NSString alloc] initWithString:player.alias]];
                         [friendsID add:[[NSString alloc] initWithString:player.playerID]];
                     }
                     if (connect!=nil)
                     {
                         [connect friendsOK];
                     }
                 }
             }
             ];
        }
    }
}
-(void)sendScore:(int)score category:(NSString*)category
{
    GKScore* scoreReporter=[[[GKScore alloc] initWithCategory:category] autorelease];
    scoreReporter.value=score;
    
    [scoreReporter reportScoreWithCompletionHandler:^(NSError* error)
     {
         if (error==nil)
         {
             if (leader!=nil)
             {
                 [leader scoreSent];
             }
         }   
         else
         {
             if (leader!=nil)
             {
                 [leader error];
             }
         }
     }
     ];
}

-(void)getScores:(NSString*)category timeScope:(int)timeScope range:(NSRange)range
{
    GKLeaderboard* leaderboardRequest=[[GKLeaderboard alloc] init];        
    if (leaderboardRequest!=nil)
    {
        leaderboardRequest.playerScope=GKLeaderboardPlayerScopeGlobal;
        switch(timeScope)
        {
            case 0:
                leaderboardRequest.timeScope=GKLeaderboardTimeScopeToday;
                break;
            case 1:
                leaderboardRequest.timeScope=GKLeaderboardTimeScopeWeek;
                break;
            default:
                leaderboardRequest.timeScope=GKLeaderboardTimeScopeAllTime;
                break;    
        }
//        leaderboardRequest.range.location=range->location;
//        leaderboardRequest.range.length=range->length;
        [leaderboardRequest loadScoresWithCompletionHandler:^(NSArray* scores, NSError* error)
         {
            if (error==nil)
            {
                if (lbScores==nil)
                {
                    lbScores=[[CArrayList alloc] init];
                }
                else
                {
                    [lbScores clear];
                }
                if (lbNames==nil)
                {
                    lbNames=[[CArrayList alloc] init];
                }
                else
                {
                    [lbNames clearRelease];
                }
                
                int n;
                ids=[[NSMutableArray alloc] init];
                for (n=0; n<[scores count]; n++)
                {
                    GKScore* score=(GKScore*)[scores objectAtIndex:n];
                    [lbScores add:(void*)(int)score.value];
                    [ids addObject:[[NSString alloc] initWithString:score.playerID]];
                }           
                
                nEntries=leaderboardRequest.maxRange;
                
                if (leader!=nil)
                {
                    [leader scoresReceived];
                }
            }
            else
            {
                if (leader!=nil)
                {
                    [leader error];
                }
            }             
         }
         ];
    }
}

-(void)getNames
{
    [GKPlayer loadPlayersForIdentifiers:ids withCompletionHandler:^(NSArray* players, NSError* error)
     {
         int nn;
         if (error==nil)
         {
             for (nn=0; nn<[players count]; nn++)
             {
                 GKPlayer* player=(GKPlayer*)[players objectAtIndex:nn];
                 [lbNames add:[[NSString alloc] initWithString:player.alias]];
             }
             if (leader!=nil)
             {
                 [leader namesReceived];
             }
         }
         else
         {
             if (leader!=nil)
             {
                 [leader error];
             }
         }         
         for (nn=0; nn<[ids count]; nn++)
         {
             NSString* s=(NSString*)[ids objectAtIndex:nn];
             [s release];
         }
         [ids release];
     }
     ];
}

-(NSString*)getLeaderboardName:(int)index
{
    if (lbNames!=nil)
    {
        if (index>=0 && index<[lbNames size])
        {
            return (NSString*)[lbNames get:index];
        }
    }
    return @"";
}
-(int)getLeaderboardScore:(int)index
{
    if (lbScores!=nil)
    {
        if (index>=0 && index<[lbScores size])
        {
            return (int)[lbScores get:index];
        }
    }
    return 0;        
}
-(int)getLeaderboardNEntries
{
    return nEntries;
}
                
-(void)getTitle:(NSString*)category
{
    [GKLeaderboard loadCategoriesWithCompletionHandler:^(NSArray *categories, NSArray *titles, NSError *error) 
    {
        if (error==nil)
        {
            if (title!=nil)
            {
                [title release];
            }
            int n;
            for (n=0; n<[categories count]; n++)
            {
                NSString* c=(NSString*)[categories objectAtIndex:n];
                if ([category compare:c]==0)
                {
                    title=[[NSString alloc] initWithString:(NSString*)[titles objectAtIndex:n]];
                    break;
                }
            }           
            if (leader!=nil)
            {
                [leader titleReceived];
            }
        }   
        else
        {
            if (leader!=nil)
            {
                [leader error];
            }
        }   
    }
    ];
}
-(NSString*)getLeaderboardTitle
{
    if (title!=nil)
    {
        return title;
    }
    return @"";
}

-(void)sendAchievement:(NSString*)identifer percent:(int)percent
{
    GKAchievement* achievement=[[[GKAchievement alloc] initWithIdentifier:identifer] autorelease];
    if (achievement)
    {
        achievement.percentComplete=percent;
        [achievement reportAchievementWithCompletionHandler:^(NSError* error)
         {
             if (achievementsClass!=nil)
             {
                 if (error==nil)
                 {
                     [achievementsClass achievementSent];
                 }
                 else
                 {
                     [achievementsClass error];
                 }
             }
         }
         ];
    }
}

-(void)getAchievements
{
    [GKAchievement loadAchievementsWithCompletionHandler:^(NSArray *array, NSError *error) 
    {
        if (error==nil)
        {
            if (achievements!=nil)
            {
                int n;
                for (n=0; n<[array count]; n++)
                {
                    GKAchievement* achievement=(GKAchievement*)[array objectAtIndex:n];
                
                    int nn;
                    for (nn=0; nn<[achievements size]; nn++)
                    {
                        CAchievement* ach=(CAchievement*)[achievements get:nn];
                        if ([ach->identifier compare:achievement.identifier]==0)
                        {           
                            ach->percent=achievement.percentComplete;
                        }
                    }
                }
            }
            if (achievementsClass!=nil)
            {
                [achievementsClass achievementsReceived];
            }
        }
        else
        {
            if (achievementsClass!=nil)
            {
                [achievementsClass error];
            }
        }
    }
     ];
}
-(void)getDescriptions
{
    [GKAchievementDescription loadAchievementDescriptionsWithCompletionHandler:^(NSArray *array, NSError *error) 
    {
        if (error==nil)
        {
            if (achievements==nil)
            {
                achievements=[[CArrayList alloc] init];
            }
            else
            {
                [achievements clearRelease];
            }
            int n;
            for (n=0; n<[array count]; n++)
            {
                GKAchievementDescription* description=(GKAchievementDescription*)[array objectAtIndex:n];
            
                CAchievement* achievement=[[CAchievement alloc] init];
                achievement->identifier=[[NSString alloc] initWithString:description.identifier];
                achievement->title=[[NSString alloc] initWithString:description.title];
                achievement->description1=[[NSString alloc] initWithString:description.unachievedDescription];
                achievement->description2=[[NSString alloc] initWithString:description.achievedDescription];
                achievement->maximumPoints=description.maximumPoints;
                [achievements add:achievement];
            }                        
            if (achievementsClass!=nil)
            {
                [achievementsClass descriptionsReceived];
            }
        }
        else
        {
            if (achievementsClass!=nil)
            {
                [achievementsClass error];
            }
        }
    }
     ];
}
-(NSString*)getATitle:(NSString*)identifier
{
    if (achievements!=nil)
    {
        int n;
        for (n=0; n<[achievements size]; n++)
        {
            CAchievement* ach=(CAchievement*)[achievements get:n];
            if ([identifier compare:ach->identifier]==0)
            {                
                return ach->title;
            }
        }
    }
    return @"";
}
-(NSString*)getADescription1:(NSString*)identifier
{
    if (achievements!=nil)
    {
        int n;
        for (n=0; n<[achievements size]; n++)
        {
            CAchievement* ach=(CAchievement*)[achievements get:n];
            if ([identifier compare:ach->identifier]==0)
            {                
                return ach->description1;
            }
        }
    }
    return @"";
}
-(NSString*)getADescription2:(NSString*)identifier
{
    if (achievements!=nil)
    {
        int n;
        for (n=0; n<[achievements size]; n++)
        {
            CAchievement* ach=(CAchievement*)[achievements get:n];
            if ([identifier compare:ach->identifier]==0)
            {                
                return ach->description2;
            }
        }
    }
    return @"";
}
-(int)getAPercent:(NSString*)identifier
{
    if (achievements!=nil)
    {
        int n;
        for (n=0; n<[achievements size]; n++)
        {
            CAchievement* ach=(CAchievement*)[achievements get:n];
            if ([identifier compare:ach->identifier]==0)
            {                
                return ach->percent;
            }
        }
    }
    return 0;
}
-(int)getAMaximumPoints:(NSString*)identifier
{
    if (achievements!=nil)
    {
        int n;
        for (n=0; n<[achievements size]; n++)
        {
            CAchievement* ach=(CAchievement*)[achievements get:n];
            if ([identifier compare:ach->identifier]==0)
            {                
                return ach->maximumPoints;
            }
        }
    }
    return 0;
}
-(int)getNAchievements
{
    if (achievements!=nil)
    {
        return [achievements size];
    }
    return 0;
}

// MULTIPLAYER
//////////////////////////////////////////////////////////////////
-(void)setMultiplayerData:(int)min max:(int)max group:(int)g
{
    minPlayers=min;
    maxPlayers=max;
    group=g;
}
-(void)freePlayers
{
    if (matchPlayersAlias!=nil)
    {
        [matchPlayersAlias clearRelease];
    }
    else
    {
        matchPlayersAlias=[[CArrayList alloc] init];
    }
    if (matchPlayersIDs!=nil)
    {
        [matchPlayersIDs clearRelease];
    }
    else
    {
        matchPlayersIDs=[[CArrayList alloc] init];                                        
    }
}
-(void)displayMatch
{
    GKMatchRequest* request=[[[GKMatchRequest alloc] init] autorelease];
    request.minPlayers=minPlayers;
    request.maxPlayers=maxPlayers;
    request.playerGroup=group;
    [self freePlayers];
    
    GKMatchmakerViewController* mmvc=[[[GKMatchmakerViewController alloc] initWithMatchRequest:request] autorelease];
    mmvc.matchmakerDelegate=self;
    [rhPtr->rhApp->mainViewController presentModalViewController:mmvc animated:YES];
    [rhPtr pause];
}
-(void)matchmakerViewController:(GKMatchmakerViewController *)viewController didFindMatch:(GKMatch *)m
{
    [rhPtr resume];
    [rhPtr->rhApp->mainViewController dismissModalViewControllerAnimated:YES];
    match=m;
    [match retain];
    match.delegate=self;
    nPlayers=maxPlayers-match.expectedPlayerCount;
    if (match.expectedPlayerCount==0)
    {
        bStartMatch=YES;
        [self findNames:match.playerIDs];
    }
}
-(void)matchmakerViewControllerWasCancelled:(GKMatchmakerViewController *)viewController
{
    match=nil;
    [rhPtr resume];
    [rhPtr->rhApp->mainViewController dismissModalViewControllerAnimated:YES];
}
-(void)matchmakerViewController:(GKMatchmakerViewController *)viewController didFailWithError:(NSError *)error
{
    match=nil;
    [rhPtr resume];
    [rhPtr->rhApp->mainViewController dismissModalViewControllerAnimated:YES];
    if (multiplayer!=nil)
    {
        [multiplayer error];
    }
}

-(void)findMatch
{
    [self freePlayers];
    
    GKMatchRequest* request=[[[GKMatchRequest alloc] init] autorelease];
    request.minPlayers=minPlayers;
    request.maxPlayers=maxPlayers;
    request.playerGroup=group;
    [[GKMatchmaker sharedMatchmaker] findMatchForRequest:request withCompletionHandler:^(GKMatch *m, NSError *error) 
    {
        if (error==nil && match!=nil)
        {
            match=m;
            [match retain];
            match.delegate=self;
            bStartMatch=YES;
            [self findNames:match.playerIDs];
        }
    }
     ];
}
-(void)findNames:(NSArray*)matchIds
{
    if (matchIds!=nil)
    {
        [GKPlayer loadPlayersForIdentifiers:matchIds withCompletionHandler:^(NSArray* players, NSError* error)
         {
             int nn;
             if (error==nil)
             {
                 [self freePlayers];
                 for (nn=0; nn<[players count]; nn++)
                 {
                     GKPlayer* player=(GKPlayer*)[players objectAtIndex:nn];
                     [matchPlayersAlias add:[[NSString alloc] initWithString:player.alias]];
                     [matchPlayersIDs add:[[NSString alloc] initWithString:(NSString*)[matchIds objectAtIndex:nn]]];
                 }
                 if (multiplayer!=nil)
                 {
                     if (bPlayerConnected)
                     {      
                         bPlayerConnected=NO;
                         [multiplayer playerConnected];
                     }  
                     if (bStartMatch)
                     {
                         bStartMatch=NO;
                         [multiplayer matchStarted];
                     }
                 }
             }
         }
         ];
    }
}

-(void)addPlayers
{
    if (match!=nil)
    {
        if (matchPlayersAlias!=nil)
        {
            [matchPlayersAlias clearRelease];
        }
        else
        {
            matchPlayersAlias=[[CArrayList alloc] init];
        }
        if (matchPlayersIDs!=nil)
        {
            [matchPlayersIDs clearRelease];
        }
        else
        {
            matchPlayersIDs=[[CArrayList alloc] init];                                        
        }

        GKMatchRequest* request=[[[GKMatchRequest alloc] init] autorelease];
        request.minPlayers=minPlayers;
        request.maxPlayers=maxPlayers;
        request.playerGroup=group;
        [[GKMatchmaker sharedMatchmaker] addPlayersToMatch:match matchRequest:request completionHandler:^(NSError * error)
        {
             if (error==nil)
             {
                 if (match.expectedPlayerCount==0)
                 {
                     bStartMatch=YES;
                     [self findNames:match.playerIDs];
                 }
             }
         }
         ];        
    }
}

-(int)getNPlayers
{
    if (matchPlayersIDs!=nil)
    {
        return [matchPlayersIDs size];
    }
    return 0;
}
-(NSString*)getPlayerAlias:(int)index
{
    if (matchPlayersAlias!=nil)
    {
        return (NSString*)[matchPlayersAlias get:index];
    }
    return @"";
}

-(void)match:(GKMatch*)m didReceiveData:(NSData*)data fromPlayer:(NSString*)playerID
{
    int n;
    if (matchPlayersIDs!=nil)
    {
        for (n=0; n<[matchPlayersIDs size]; n++)
        {
            if ([playerID compare:(NSString*)[matchPlayersIDs get:n]]==0)
            {
                playerIndex=n;
                playerData=[[NSString alloc] initWithCharacters:(unichar*)[data bytes] length:[data length]/2];
                if (multiplayer!=nil)
                {
                    [multiplayer dataReceived];
                }
                break;
            }
        }
    }
}

-(void)match:(GKMatch*)m player:(NSString*)playerID didChangeState:(GKPlayerConnectionState)state
{
    int n;
    if (matchPlayersIDs!=nil)
    {
        if (state==GKPlayerStateConnected)
        {
            [self findNames:m.playerIDs];
            bPlayerConnected=YES;
        }
        else
        {
            for (n=0; n<[matchPlayersIDs size]; n++)
            {
                if ([playerID compare:(NSString*)[matchPlayersIDs get:n]]==0)
                {
                    playerIndex=n;
                    if (state==GKPlayerStateDisconnected)
                    {
                        if (multiplayer!=nil)
                        {
                            [multiplayer playerDisconnected];
                        }
                        [self findNames:m.playerIDs];
                    }
                    break;
                }
            }
        }
    }
}

-(void)match:(GKMatch*)m didFailWithError:(NSError *)error
{
    if (multiplayer!=nil)
    {
        [multiplayer error];
    }
}

-(void)match:(GKMatch*)m connectionWithPlayerFailed:(NSString *)playerID withError:(NSError *)error
{
    if (multiplayer!=nil)
    {
        [multiplayer error];
    }
}

-(NSData*)getDataFromString:(NSString*)s
{
    int l=[s length];
    unichar* buffer=(unichar*)malloc(l);
    NSRange range;
    range.location=0;
    range.length=l;
    [s getCharacters:buffer range:range];
    NSMutableData* data=[NSMutableData dataWithLength:l*2];
    range.length=l*2;
    [data replaceBytesInRange:range withBytes:buffer];
    return data;
}

-(void)sendAllPlayers:(NSString*)string dataMode:(GKMatchSendDataMode)mode
{
    NSError* pError;
    if (match!=nil)
    {
        NSData* data=[self getDataFromString:string];
        [match sendDataToAllPlayers:data withDataMode:mode error:&pError];
        if (pError!=nil)
        {
            if (multiplayer!=nil)
            {
                [multiplayer error];
            }
        }
    }
}
-(void)sendPlayer:(int)index data:(NSString*)string dataMode:(GKMatchSendDataMode)mode
{
    if (match!=nil)
    {
        if (matchPlayersIDs!=nil)
        {
            NSError* pError;
            NSString* playerID=(NSString*)[matchPlayersIDs get:index];
            NSArray* array=[NSArray arrayWithObject:playerID];
            NSData* data=[self getDataFromString:string];
            [match sendData:data toPlayers:array withDataMode:mode error:&pError];
            if (pError!=nil)
            {
                if (multiplayer!=nil)
                {
                    [multiplayer error];
                }
            }
        }    
    }
}
-(NSString*)getData
{
    if (playerData!=nil)
    {
        return playerData;
    }
    return @"";
}
-(int)getPlayerIndex
{
    return playerIndex;
}
    
@end

@implementation CRunGameCenterConnect

-(int)getNumberOfConditions
{
	return CND_LAST;
}

-(BOOL)createRunObject:(CFile*)file withCOB:(CCreateObjectInfo*)cob andVersion:(int)version
{
    // Read EditData
    [file skipBytes:4];
    [file skipBytes:4];
    flags=[file readAInt];
    localPlayerCount=-1;
    friendsCount=-1;
    invitationsSentCount=-1;
    invitations=nil;

    gameCenter=(CESGameCenter*)[ho->hoAdRunHeader getStorage:IDENTIFIER];
    if (gameCenter==nil)
    {
        gameCenter=[[CESGameCenter alloc] init:self rh:ho->hoAdRunHeader];
        [ho->hoAdRunHeader addStorage:gameCenter withID:IDENTIFIER];
    }
    else
    {
        [gameCenter setConnect:self];
    }
    
    if (flags&GCFLAG_AUTHENTICATE)
    {
        [gameCenter authenticate];
    }
    return TRUE;
}

-(void)destroyRunObject:(BOOL)bFast
{
    [gameCenter setConnect:nil];
    if (invitations!=nil)
    {
        [invitations release];
    }
}
             
             

// Conditions 
//////////////////////////////////////////////////////////////////
-(void)authenticated
{
    localPlayerCount=[ho getEventCount];
    [ho pushEvent:CND_LOCALPLAYERCON withParam:0];    
}
-(void)friendsOK
{
    friendsCount=[ho getEventCount];
    [ho pushEvent:CND_FRIENDSLOADED withParam:0];    
}
-(BOOL)invitationsSent
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == invitationsSentCount)
	{
		return YES;
	}
	return NO;    
}
-(BOOL)friendsLoaded
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == friendsCount)
	{
		return YES;
	}
	return NO;    
}
-(BOOL)localPlayerCon
{
	if ((ho->hoFlags & HOF_TRUEEVENT) != 0)
	{
		return YES;
	}
	if ([ho getEventCount] == localPlayerCount)
	{
		return YES;
	}
	return NO;    
}
-(BOOL)localPlayerOK
{
    if (gameCenter->localPlayer!=nil)
    {
        return gameCenter->localPlayer.isAuthenticated;
    }
    return NO;
}
-(BOOL)condition:(int)num withCndExtension:(CCndExtension *)cnd
{
    switch(num)
    {
        case CND_LOCALPLAYERCON:
            return [self localPlayerCon];
        case CND_LOCALPLAYEROK:
            return [self localPlayerOK];
        case CND_FRIENDSLOADED:
            return [self friendsLoaded];
        case CND_INVITATIONSSENT:
            return [self invitationsSent];
    }
    return NO;
}

// Actions
/////////////////////////////////////////////////////////////////
-(void)resetInvitations
{
    if (invitations!=nil)
    {
        [invitations removeAllObjects];
    }
}
-(void)addInvitation:(CActExtension*)act
{
    int num=[act getParamExpression:rh withNum:0];
    if (invitations==nil)
    {
        invitations=[[NSMutableArray alloc] init];
    }
    if (gameCenter->localPlayer!=nil)
    {
        if (gameCenter->localPlayer.isAuthenticated)
        {
            if (gameCenter->friendsID!=nil)
            {
                if (num>=0 && num<[gameCenter->friendsID size])
                {
                    [invitations addObject:[gameCenter->friendsID get:num]];
                }
            }
        }
    }
}
-(void)sendInvitations
{
    NSString* reqSysVer=@"4.2";
    NSString* curSysVer=[[UIDevice currentDevice] systemVersion];
    BOOL osVersionSupported=([curSysVer compare:reqSysVer options:NSNumericSearch]!=NSOrderedAscending);    
    if (osVersionSupported==NO)
    {
        return;
    }
    if (invitations==nil)
    {
        return;
    }
    if ([invitations count]==0)
    {
        return;
    }
    
    if (gameCenter->localPlayer.isAuthenticated)
    {
        GKFriendRequestComposeViewController* friendRequestController=[[GKFriendRequestComposeViewController alloc] init];
        friendRequestController.composeViewDelegate=self;
        [ho->hoAdRunHeader pause];
        [ho->hoAdRunHeader->rhApp->mainViewController presentModalViewController:friendRequestController animated:YES];
        [friendRequestController release];
    }
}
-(void)friendRequestComposeViewControllerDidFinish:(GKFriendRequestComposeViewController*)controller
{
    [ho->hoAdRunHeader->rhApp->mainViewController dismissModalViewControllerAnimated:YES];
    [ho->hoAdRunHeader resume];
    invitationsSentCount=[ho getEventCount];
    [ho pushEvent:CND_INVITATIONSSENT withParam:0];    
}

-(void)action:(int)num withActExtension:(CActExtension *)act
{
    switch (num)
    {
        case ACT_AUTHENTICATE:
            [gameCenter authenticate];
            break;
        case ACT_LOADFRIENDS:
            [gameCenter loadFriends];
            break;
        case ACT_RESETINVITATIONS:
            [self resetInvitations];
            break;
        case ACT_ADDINVITATION:
            [self addInvitation:act];
            break;
        case ACT_SENDINVITATIONS:
            [self sendInvitations];
            break;
    }
}

// Expressions
//////////////////////////////////////////////////////////////////
-(CValue*)getAlias
{
    CValue* ret=[rh getTempValue:0];
    [ret forceString:@""];
    if (gameCenter->localPlayer!=nil)
    {
        if (gameCenter->localPlayer.isAuthenticated)
        {
            [ret forceString:gameCenter->localPlayer.alias];
        }
    }
    return ret;
}
-(CValue*)getID
{
    CValue* ret=[rh getTempValue:0];
    [ret forceString:@""];
    if (gameCenter->localPlayer!=nil)
    {
        if (gameCenter->localPlayer.isAuthenticated)
        {
            [ret forceString:gameCenter->localPlayer.playerID];
        }
    }
    return ret;
}
-(CValue*)getFriendsCount
{
    CValue* ret=[rh getTempValue:0];
    if (gameCenter->localPlayer!=nil)
    {
        if (gameCenter->localPlayer.isAuthenticated)
        {
            if (gameCenter->friendsAlias!=nil)
            {
                [ret forceInt:[gameCenter->friendsAlias size]];
            }
        }
    }
    return ret;
}
-(CValue*)getFriendAlias
{
    CValue* ret=[rh getTempValue:0];
    [ret forceString:@""];
    int index=[[ho getExpParam] getInt];
    if (index>=0)
    {
        if (gameCenter->localPlayer!=nil)
        {
            if (gameCenter->localPlayer.isAuthenticated)
            {
                if (gameCenter->friendsAlias!=nil)
                {
                    NSString* alias=(NSString*)[gameCenter->friendsAlias get:index];
                    if (alias!=nil)
                    {
                        [ret forceString:alias];
                    }
                }
            }
        }
    }
    return ret;
}
-(CValue*)getFriendID
{
    CValue* ret=[rh getTempValue:0];
    [ret forceString:@""];
    int index=[[ho getExpParam] getInt];
    if (index>=0)
    {
        if (gameCenter->localPlayer!=nil)
        {
            if (gameCenter->localPlayer.isAuthenticated)
            {
                if (gameCenter->friendsAlias!=nil)
                {
                    NSString* ID=(NSString*)[gameCenter->friendsID get:index];
                    if (ID!=nil)
                    {
                        [ret forceString:ID];
                    }
                }
            }
        }
    }
    return ret;
}
-(CValue*)expression:(int)num
{
    switch(num)
    {
        case EXP_LPALIAS:
            return [self getAlias];
        case EXP_LPID:
            return [self getID];
        case EXP_NUMOFFRIENDS:
            return [self getFriendsCount];
        case EXP_FRIENDALIAS:
            return [self getFriendAlias];
        case EXP_FRIENDID:
            return [self getFriendID];
    }
    return nil;
}
@end

@implementation CAchievement

-(void)dealloc
{
    [title release];
    [identifier release];
    [description1 release];
    [description2 release];
    [super dealloc];
}

@end

