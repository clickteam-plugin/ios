//----------------------------------------------------------------------------------
//
// CRuniPhoneSingleEdit
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;

#define FLAG_TFGOTOON 0x0001
#define FLAG_TFVISIBLE 0x0002

#define CND_TFENABLED 0
#define CND_TFENTEREDIT 1
#define CND_TFQUITEDIT 2
#define CND_TFISVISIBLE 3
#define ACT_TFENABLE 0
#define ACT_TFDISABLE 1
#define ACT_TFBACKCOLOR 2
#define ACT_TFSHOW 3
#define ACT_TFHIDE 4
#define ACT_TFSETTEXT 5
#define EXP_TFGETTEXT 0

@interface CRuniOSSingleEdit : CRunExtension <UITextFieldDelegate>
{
	int border;
	int backColor;
	int textColor;
	int keyboard;
	int correction;
	int clear;
	int ret;
	int align;
	int gotoX;
	int gotoY;
	short flags;
	int gotoSpeed;
	CFontInfo* font;
	NSString* placeHolder;
	NSString* text;
	
	int gotoStartX;
	int gotoStartY;
	int gotoEndX;
	int gotoEndY;
	int gotoSavedX;
	int gotoSavedY;	
	double gotoPlusPosition;
	double gotoPosition;
	BOOL bGoto;

	int enterEditCount;
	int quitEditCount;
	UITextField* textField;
}
-(void)actBackColor:(int)color;
-(BOOL)cndEnterEdit;
-(BOOL)cndQuitEdit;

@end
