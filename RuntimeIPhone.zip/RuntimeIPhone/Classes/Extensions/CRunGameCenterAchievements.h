//----------------------------------------------------------------------------------
//
// CRunGameCenterAchievements
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunExtension.h"
#import "CRunGameCenterConnect.h"
#import "GameKit/GameKit.h"

@class CFile;
@class CCreateObjectInfo;
@class CValue;
@class CCndExtension;
@class CFontInfo;
@class CBitmap;
@class CImage;
@class CESGameCenter;
@class CArrayList;
@class CRun;
@class CESGameCenter;
@class CTextSurface;

@interface CRunGameCenterAchievements : CRunExtension <IAchievements, GKAchievementViewControllerDelegate>
{
    CESGameCenter* gameCenter; 
    int achievementSentCount;
    int achievementsReceivedCount;
    int descriptionsReceivedCount;
    int errorCount;
    CArrayList* sendIdentifiers;
    CArrayList* sendPercents;
    int flags;
    int action;
}

@end
