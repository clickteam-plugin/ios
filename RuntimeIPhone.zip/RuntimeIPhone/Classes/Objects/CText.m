//----------------------------------------------------------------------------------
//
// CText : Objet string
//
//----------------------------------------------------------------------------------
#import "CText.h"
#import "CRun.h"
#import "CRSpr.h"
#import "CObjectCommon.h"
#import "CMask.h"
#import "CSprite.h"
#import "CImageBank.h"
#import "CCreateObjectInfo.h"
#import "CValue.h"
#import "CDefTexts.h"
#import "CRunApp.h"
#import "CFontBank.h"
#import "CRect.h"
#import "CFontInfo.h"
#import "CRCom.h"
#import "CDefText.h"
#import "CServices.h"
#import "CBitmap.h"
#import "CRenderer.h"
#import "CTextSurface.h"

@implementation CText

-(id)init
{
	self=[super init];
	return self;
}
-(void)dealloc
{
	if (rsTextBuffer!=nil)
	{
		[rsTextBuffer release];
	}
	[textSurface release];
	[super dealloc];
}

-(void)initObject:(CObjectCommon*)ocPtr withCOB:(CCreateObjectInfo*)cob
{
	rsFlag = 0;										// ???? adlo->loFlags;
	CDefTexts* txt = (CDefTexts*) ocPtr->ocObject;
	hoImgWidth = txt->otCx;
	hoImgHeight = txt->otCy;
	rsBoxCx = txt->otCx;
	rsBoxCy = txt->otCy;
	
	// Recuperer la couleur et le nombre de phrases
	rsMaxi = txt->otNumberOfText;
	rsTextColor=0;
	if (txt->otNumberOfText>0)
	{
		rsTextColor = txt->otTexts[0]->tsColor;
	}
	rsHidden = (unsigned char) cob->cobFlags;					// A Toujours?
	rsTextBuffer = nil;
	rsFont = -1;
	rsMini = 0;
	if ((rsHidden & COF_FIRSTTEXT) != 0)
	{
		if (txt->otNumberOfText>0)
		{
			rsTextBuffer = [[NSString alloc] initWithString:txt->otTexts[0]->tsText];
		}
		else
		{
			rsTextBuffer=[[NSString alloc] init];
		}
	}
	
	textSurface = [[CTextSurface alloc] initWidthWidth:hoImgWidth andHeight:hoImgHeight];
}

-(void)handle
{
	[ros handle];
	if (roc->rcChanged)
	{
		roc->rcChanged = NO;
		[self modif];
	}
}

-(void)modif
{
	[ros modifRoutine];
}

-(void)display
{
	[ros displayRoutine];
}

-(void)getZoneInfos
{
	CDefTexts* txt = (CDefTexts*) hoCommon->ocObject;
	short flags = txt->otTexts[0]->tsFlags;
	
	// Rectangle
	CRect rc;
	rc.left = hoX - hoAdRunHeader->rhWindowX;
	rc.top = hoY - hoAdRunHeader->rhWindowY;
	rc.right = rc.left + rsBoxCx;
	rc.bottom = rc.top + rsBoxCy;
	hoImgWidth = (short) (rc.right - rc.left);
	hoImgHeight = (short) (rc.bottom - rc.top);
	hoImgXSpot = 0;
	hoImgYSpot = 0;
	
	// Get font
	short nFont = rsFont;
	if (nFont == -1)
	{
		if (txt->otNumberOfText>0)
		{
			nFont = txt->otTexts[0]->tsFont;
		}
	}
	CFont* font = [hoAdRunHeader->rhApp->fontBank getFontFromHandle:nFont];
	
	// Calcul dimensions exacte zone
	NSString* s;
	if (rsMini >= 0)
	{
		s = txt->otTexts[rsMini]->tsText;
	}
	else
	{
		s = rsTextBuffer;
		if (s == nil)
		{
			s = @"";
		}
	}
	
	/////////////////////////////////////
	// Vertical alignment & multi-line ? do not compute size, because DrawText doesn't support v.align for multi-line texts
	
	// Allow only the following flags
	short dtflags = (short) (flags & (DT_LEFT | DT_CENTER | DT_RIGHT | DT_TOP | DT_BOTTOM | DT_VCENTER | DT_SINGLELINE));
	int ht = 0;
//	if ((dtflags & (DT_BOTTOM | DT_VCENTER)) == 0 || (dtflags & DT_SINGLELINE) != 0)
	{
		// Force the following flags
		int x2 = rc.right;
		ht = [CServices drawText:nil withString:s andFlags:(short)(dtflags|DT_CALCRECT) andRect:rc andColor:rsTextColor andFont:font andEffect:0 andEffectParam:0];
		rc.right = x2;	// keep zone width
	}
	
	/////////////////////////////////////
	if (ht != 0)
	{
		deltaY=0;
		if (dtflags&DT_BOTTOM)
		{
			deltaY=hoImgHeight-ht;
		}
		else if (dtflags&DT_VCENTER)
		{			
			deltaY=hoImgHeight/2-ht/2;
		}
		else 
		{			
			hoImgWidth = (short) (rc.right - rc.left);
			hoImgHeight = (short) (rc.bottom - rc.top);
		}
	}
}

-(void)draw:(CRenderer*)renderer
{
	int effect = ros->rsEffect;
	int effectParam = ros->rsEffectParam;
	CDefTexts* txt = (CDefTexts*) hoCommon->ocObject;
	short flags = txt->otTexts[0]->tsFlags;
	
	// Get font
	short nFont = rsFont;
	if (nFont == -1)
	{
		if (txt->otNumberOfText>0)
		{
			nFont = txt->otTexts[0]->tsFont;
		}
	}
	CFont* font = [hoAdRunHeader->rhApp->fontBank getFontFromHandle:nFont];
	
	// Affichage
	NSString* s = nil;
	if (rsMini >= 0)
	{
		s = txt->otTexts[rsMini]->tsText;
	}
	else
	{
		s = rsTextBuffer;
		if (s == nil)
		{
			s = @"";
		}
	}
	
	// Allow only the following flags
	short dtflags = (short) (flags & (DT_LEFT | DT_CENTER | DT_RIGHT | DT_TOP | DT_BOTTOM | DT_VCENTER | DT_SINGLELINE));
	// Adjust rectangle
	CRect rc;
	rc.left = hoX - hoAdRunHeader->rhWindowX;
	rc.top = hoY - hoAdRunHeader->rhWindowY;
	rc.right = rc.left + rsBoxCx;
	rc.bottom = rc.top + rsBoxCy;
	
	[textSurface setText:s withFlags:dtflags&(~(DT_VCENTER|DT_BOTTOM)) andColor:rsTextColor andFont:font];
	[textSurface draw:renderer withX:rc.left andY:rc.top+deltaY andEffect:effect andEffectParam:effectParam];
	
	/*int ht=[CServices drawText:bitmap withString:s andFlags:dtflags andRect:rc andColor:rsTextColor andFont:font andEffect:effect andEffectParam:effectParam];
	if (ht != 0)
	{
		hoImgWidth = (short) (rc.right - rc.left);
		hoImgHeight = (short) (rc.bottom - rc.top);
	}*/
	
	
}

-(CMask*)getCollisionMask:(int)flags
{
	return nil;
}

-(CFontInfo*)getFont
{
	short nFont = rsFont;
	if (nFont == -1)
	{
		CDefTexts* txt = (CDefTexts*) hoCommon->ocObject;
		nFont = txt->otTexts[0]->tsFont;
	}
	return [hoAdRunHeader->rhApp->fontBank getFontInfoFromHandle:nFont];
}

-(void)setFont:(CFontInfo*)info withRect:(CRect)pRc
{
	rsFont = [hoAdRunHeader->rhApp->fontBank addFont:info];
	if (!CRectAreEqual(pRc, CRectNil()))
	{
		hoImgWidth = rsBoxCx = pRc.right - pRc.left;
		hoImgHeight = rsBoxCy = pRc.bottom - pRc.top;
	}
	[self modif];
	roc->rcChanged = YES;
}

-(int)getFontColor
{
	return rsTextColor;
}

-(void)setFontColor:(int)rgb
{
	rsTextColor = rgb;
	[self modif];
	roc->rcChanged = YES;
}

-(BOOL)txtChange:(int)num
{
	if (num < -1)
	{
		num = -1;							// -1==chaine stockee...
	}
	if (num >= rsMaxi)
	{
		num = rsMaxi - 1;
	}
	if (num == rsMini)
	{
		return NO;
	}
	
	rsMini = num;
	
	// -------------------------------
	// Recopie le texte dans la chaine
	// -------------------------------
	if (num >= 0)
	{
		CDefTexts* txt = (CDefTexts*) hoCommon->ocObject;
		[self txtSetString:txt->otTexts[rsMini]->tsText];
	}
	
	// Reafficher ou pas?
	// ------------------
	if ((ros->rsFlags & RSFLAG_HIDDEN) != 0)
	{
		return NO;
	}
	return YES;
}

-(void)txtSetString:(NSString*)s
{
	if (rsTextBuffer!=nil)
	{
		[rsTextBuffer release];
	}
	rsTextBuffer = [[NSString alloc] initWithString:s];
}

// IDrawable
-(void)spriteDraw:(CRenderer*)renderer withSprite:(CSprite*)spr andImageBank:(CImageBank*)bank andX:(int)x andY:(int)y
{
	[self draw:renderer];
}

-(void)spriteKill:(CSprite*)spr
{
	[spr->sprExtraInfo release];
}
-(CMask*)spriteGetMask
{
	return nil;
}


@end
