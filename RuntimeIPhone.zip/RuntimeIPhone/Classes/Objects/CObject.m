//----------------------------------------------------------------------------------
//
// COBJECT : Classe de base d'un objet'
//
//----------------------------------------------------------------------------------
#import "CObject.h"
#import "CRun.h"
#import "CRCom.h"
#import "CRAni.h"
#import "CRMvt.h"
#import "CRVal.h"
#import "CRSpr.h"
#import "CObjInfo.h"
#import "CArrayList.h"
#import "CObjectCommon.h"
#import "CRect.h"
#import "CImage.h"
#import "CMask.h"
#import "CSprite.h"
#import "CImageBank.h"
#import "CRunApp.h"
#import "CBitmap.h"

@implementation CObject

-(void)dealloc
{
	if (hoPrevNoRepeat!=nil)
	{
		[hoPrevNoRepeat release];
	}
	if (hoBaseNoRepeat!=nil)
	{
		[hoBaseNoRepeat release];
	}
	if (roc!=nil)
	{
		[roc release];
		roc = nil;
	}
	if (rom!=nil)
	{
		[rom release];
		rom = nil;
	}
	if (rov!=nil)
	{
		[rov release];
		rov = nil;
	}
	if (ros!=nil)
	{
		[ros release];
		ros = nil;
	}
	if (roa!=nil)
	{
		[roa release];
		roa = nil;
	}
	[super dealloc];
}
-(void)setScale:(float)fScaleX withScaleY:(float)fScaleY andFlag:(BOOL)bResample
{
	BOOL bOldResample = NO;
	if ((ros->rsFlags & RSFLAG_SCALE_RESAMPLE) != 0)
	{
		bOldResample = YES;
	}
	
	if (roc->rcScaleX != fScaleX || roc->rcScaleY != fScaleY || bOldResample != bResample)
	{
		roc->rcScaleX = fScaleX;
		roc->rcScaleY = fScaleY;
		ros->rsFlags &= ~RSFLAG_SCALE_RESAMPLE;
		if (bResample)
		{
			ros->rsFlags |= RSFLAG_SCALE_RESAMPLE;
		}
		roc->rcChanged = YES;
		
		ImageInfo ifo = [hoAdRunHeader->rhApp->imageBank getImageInfoEx:roc->rcImage withAngle:roc->rcAngle andScaleX:roc->rcScaleX andScaleY:roc->rcScaleY];
		hoImgWidth=ifo.width;
		hoImgHeight=ifo.height;
		hoImgXSpot=ifo.xSpot;
		hoImgYSpot=ifo.ySpot;
	}
}

-(int)fixedValue
{
	return (hoCreationId << 16) + (((int)hoNumber) & 0xFFFF);
}

-(void)initObject:(CObjectCommon*)ocPtr withCOB:(CCreateObjectInfo*)cob
{
}

-(void)handle
{
}

-(void)modif
{
}

-(void)display
{
}

-(BOOL)kill:(BOOL)bFast
{
	return NO;
}

-(void)getZoneInfos
{
}

-(void)saveBack:(CBitmap*)bitmap
{
}

-(void)restoreBack:(CBitmap*)bitmap
{
}

-(void)killBack
{
}

-(void)draw:(CRenderer*)bitmap
{
}

-(CMask*)getCollisionMask:(int)flags
{
	return nil;
}

// IDrawable
-(void)spriteDraw:(CRenderer*)renderer withSprite:(CSprite*)spr andImageBank:(CImageBank*)bank andX:(int)x andY:(int)y
{
}
-(void)spriteKill:(CSprite*)spr
{
}

-(CMask*)spriteGetMask
{
	return nil;
}

@end
