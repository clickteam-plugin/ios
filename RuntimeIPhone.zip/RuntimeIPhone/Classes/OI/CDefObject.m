//----------------------------------------------------------------------------------
//
// CDEFOBJECT : Classe abstraite de definition d'un objet'
//
//----------------------------------------------------------------------------------

#import "CDefObject.h"

@implementation CDefObject
	
-(void)load:(CFile*)file
{
}
-(void)enumElements:(id)enumImages withFont:(id)enumFonts
{
}

@end
