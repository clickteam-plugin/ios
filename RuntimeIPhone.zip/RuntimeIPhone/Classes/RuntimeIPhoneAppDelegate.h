//
//  RuntimeIPhoneAppDelegate.h
//  RuntimeIPhone
//
//  Created by Francois Lionet on 08/10/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CRunView;
@class CRunApp;
@class CIAdViewController;
@class MainViewController;
@class CRunViewController;

@interface RuntimeIPhoneAppDelegate : NSObject <UIApplicationDelegate> 
{
	CRunApp* runApp;
    UIWindow* window;
	CRunViewController* runViewController;
	MainViewController* mainViewController;
	CIAdViewController* iAdViewController;
	NSString* appPath;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

