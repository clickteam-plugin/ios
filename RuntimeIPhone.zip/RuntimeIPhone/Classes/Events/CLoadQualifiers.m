//----------------------------------------------------------------------------------
//
// CLOADQUALIFIERS : chargement des qualifiers
//
//----------------------------------------------------------------------------------
#import "CLoadQualifiers.h"

@implementation CLoadQualifiers

@end
