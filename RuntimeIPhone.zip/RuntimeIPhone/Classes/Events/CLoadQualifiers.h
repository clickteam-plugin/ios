//----------------------------------------------------------------------------------
//
// CLOADQUALIFIERS : chargement des qualifiers
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>


@interface CLoadQualifiers : NSObject 
{
@public
	short qOi;
    short qType;	
}

@end
