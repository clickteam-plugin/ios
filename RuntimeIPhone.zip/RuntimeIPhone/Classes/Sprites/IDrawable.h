//----------------------------------------------------------------------------------
//
// IDRAWABLE : Interface pour les sprites owner draw
//
//----------------------------------------------------------------------------------

@class CSprite;
@class CImageBank;
@class CMask;
@class CBitmap;
@class CRenderer;

@protocol IDrawable	

-(void)spriteDraw:(CRenderer*)renderer withSprite:(CSprite*)spr andImageBank:(CImageBank*)bank andX:(int)x andY:(int)y;
-(void)spriteKill:(CSprite*)spr;
-(CMask*)spriteGetMask;

@end
