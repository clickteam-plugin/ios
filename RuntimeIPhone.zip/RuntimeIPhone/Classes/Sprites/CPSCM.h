//----------------------------------------------------------------------------------
//
// Tchote class poru les masques
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>

@class CMask;

@interface CPSCM : NSObject 
{
@public 
	int flags;
	CMask* mask;
}

@end
