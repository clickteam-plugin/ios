//
//  RuntimeIPhoneAppDelegate.m
//  RuntimeIPhone
//
//  Created by Francois Lionet on 08/10/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "RuntimeIPhoneAppDelegate.h"
#import "Services/CFile.h"	
#import "CRunApp.h"
#import "CRun.h"
#import "CIAdViewController.h"
#import "MainViewController.h"
#import "CRunViewController.h"
#import "CRunView.h"
#import "CALPlayer.h"
#import "CRun.h"
#import "CSoundPlayer.h"

@implementation RuntimeIPhoneAppDelegate

@synthesize window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary*)dictionary 
{   
	appPath=[[NSBundle mainBundle] pathForResource: @"Application" ofType:@"cci"];
	runApp=[[CRunApp alloc] initWithPath:appPath];
	[runApp load];
	
	[UIApplication sharedApplication].statusBarHidden = (runApp->bStatusBar==NO);
	
	// Set up the window and content view
    window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	
	mainViewController = [[MainViewController alloc] initWithRunApp:runApp];
	runViewController=[[CRunViewController alloc] initWithApp:runApp];
	
	MainView* mainView = (MainView*)[mainViewController view];
	CRunView* runView = (CRunView*)[runViewController view];
	
	[mainView addSubview:runView];	
	[window addSubview:(UIView*)mainView];
	[window layoutIfNeeded];
	[window makeKeyAndVisible];
	
	iAdViewController=nil;
	if (runApp->hdr2Options&AH2OPT_ENABLEIAD)
		iAdViewController=[[CIAdViewController alloc] initWithApp:runApp andView:mainView];

	[runApp setIAdViewController:iAdViewController];
	[runApp setMainViewController:mainViewController];
	[runView initApplication:runApp];
	[runView setNeedsDisplay];
	return YES;
}

-(void)applicationDidReceiveMemoryWarning:(UIApplication*)application
{
	[runApp cleanMemory];
}
- (void)dealloc 
{
	[appPath release];
	[runApp release];
	[runViewController release];
	[mainViewController release];
    [window release];
    [super dealloc];
}
-(void)applicationWillResignActive:(UIApplication *)application
{
	if (runApp->run!=nil)
	{
        if (runApp->iOSObject!=nil)
        {
            [runApp->run callEventExtension:runApp->iOSObject withCode:2 andParam:0];
        }
        [runApp->run doRunLoop];
		[runApp->runView drawNoUpdate];
		[runApp->run pause];
	}
	[runViewController->runView pauseTimer];
}
-(void)applicationDidBecomeActive:(UIApplication *)application
{
	if (runApp->run!=nil)
	{
		[runApp->run resume];
        [runApp->ALPlayer resetSources];
        if (runApp->iOSObject!=nil)
        {
            [runApp->run callEventExtension:runApp->iOSObject withCode:1 andParam:0];
        }
	}
	[runViewController->runView resumeTimer];
}
-(void)applicationWillTerminate:(UIApplication *)application
{
	if (runApp->run!=nil)
	{
		[runApp->run killRunLoop:0 keepSounds:NO];
	}
	[runApp endApplication];
	[runApp release];
	runApp=nil;
}
@end
