//----------------------------------------------------------------------------------
//
// CRUNMVTINANDOUT : Movement inandout!
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunMvtExtension.h"

#define MOVESTATUS_PREPAREOUT 0
#define MOVESTATUS_MOVEOUT 1
#define MOVESTATUS_WAITOUT 2
#define MOVESTATUS_PREPAREIN 3
#define MOVESTATUS_MOVEIN 4
#define MOVESTATUS_WAITIN 5
#define MOVESTATUS_POSITIONIN 6
#define MOVESTATUS_POSITIONOUT 7
#define ACTION_POSITIONIN 0
#define ACTION_POSITIONOUT 1
#define ACTION_MOVEIN 2
#define ACTION_MOVEOUT 3
#define MFLAG_OUTATSTART 0x00000001
#define MFLAG_MOVEATSTART 0x00000002
#define MFLAG_STOPPED 0x00000004
#define MOVETYPE_LINEAR 0
#define MOVETYPE_SMOOTH 1

@interface CRunMvtinandout : CRunMvtExtension
{
	int m_direction;
	int m_speed;
	int m_flags;
	int	m_moveStatus;
	double	m_angle;
	double	m_maxPente;
	long m_moveTimerStart;
	long m_stopTimer;
	int	m_type;
	int	m_startX;
	int	m_startY;
	int	m_destX;
	int	m_destY;	
}
-(void)initialize:(CFile*)file;
-(BOOL)move;
-(void)stop:(BOOL)bCurrent;
-(void)start;
-(double)actionEntry:(int)action;
-(int)getSpeed;

@end
