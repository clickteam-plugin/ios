//----------------------------------------------------------------------------------
//
// CMOVEDEFSTATIC : donnÈes du mouvement statique
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CMoveDef.h"

@interface CMoveDefStatic : CMoveDef
{

}

@end
