//----------------------------------------------------------------------------------
//
// CRUNMVTINVADERS
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunMvtExtension.h"
#import "CExtStorage.h"

#define IDENTIFIER 2

@interface CRunMvtclickteam_invaders : CRunMvtExtension
{

}
-(void)initialize:(CFile*)file;
-(void)kill;
-(BOOL)move;
-(void)setPosition:(int)x withY:(int)y;
-(void)setXPosition:(int)x;
-(void)stop:(BOOL)bCurrent;
-(void)reverse;
-(void)start;
-(void)setSpeed:(int)speed;
-(double)actionEntry:(int)action;

@end

@class CArrayList;

@interface CRunMvtInvaderData : CExtStorage 
{
@public
	int count;
    int tillSpeedIncrease;
    int dx;
    int dy;
    int cdx;
    int cdy;
    int speed;
    int frames;
    int initialSpeed;
    int minX;
    int maxX;
    BOOL isMoving;
    BOOL autoSpeed;
    CArrayList* myList;		
}
-(id)init;
-(void)dealloc;

@end
