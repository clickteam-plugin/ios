//----------------------------------------------------------------------------------
//
// CRUNMVTSIMPLEELLIPSE
//
//----------------------------------------------------------------------------------
#import <Foundation/Foundation.h>
#import "CRunMvtExtension.h"

#define MFLAGEL_MOVEATSTART 1

@interface CRunMvtclickteam_simple_ellipse : CRunMvtExtension
{
	int m_dwCX;
    int m_dwCY;
    int m_dwRadiusX;
    int m_dwRadiusY;
    int m_dwStartAngle;
    int m_dwFlags;
    int m_dwAngVel;
    int m_dwOffset;
    BOOL r_Stopped;
    int r_CX;
    int r_CY;
    int r_radiusX;
    int r_radiusY;
    double r_AngVel;
    double r_Offset;
    double r_CurrentAngle;
	
}
-(void)initialize:(CFile*)file;
-(BOOL)move;
-(void)reset;
-(void)setPosition:(int)x withY:(int)y;
-(void)setXPosition:(int)x;
-(void)setYPosition:(int)y;
-(void)stop:(BOOL)bCurrent;
-(void)reverse;
-(void)start;
-(void)setSpeed:(int)speed;
-(double)actionEntry:(int)action;
-(int)getSpeed;

@end
