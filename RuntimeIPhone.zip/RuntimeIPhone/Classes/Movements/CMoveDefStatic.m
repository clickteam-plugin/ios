//----------------------------------------------------------------------------------
//
// CMOVEDEFSTATIC : donnÈes du mouvement statique
//
//----------------------------------------------------------------------------------
#import "CMoveDefStatic.h"

@implementation CMoveDefStatic

@end
